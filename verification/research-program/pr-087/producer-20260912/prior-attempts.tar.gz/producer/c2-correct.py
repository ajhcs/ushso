import pathlib,json,hashlib
s=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation/stage-c2');p=s/'verification/wp5/v1.1.0/tools/common.mjs';x=p.read_text();policy=json.loads((s/'verification/wp5/v1.1.0/receipts/current-subject-policy.json').read_text())
x=x.replace("policy.origin_hash === digest(policy.origin) && policy.origin_input_pins_hash === digest(policy.origin_input_pins)",f"policy.origin_hash === '{policy['origin_hash']}' && policy.origin_input_pins_hash === '{policy['origin_input_pins_hash']}' &&\n    policy.origin_hash === digest(policy.origin) && policy.origin_input_pins_hash === digest(policy.origin_input_pins)")
x=x.replace("requireCondition(boundaries.some((b) => b.lock_entry), 'UNEXPLAINED_PACKAGE_BOUNDARY');","const parent = boundaries.findLast((b) => b.lock_entry);\n        requireCondition(parent && !packagePath.slice(parent.lock_path.length).includes('/node_modules/') &&\n          metadata.name === undefined && metadata.version === undefined, 'UNEXPLAINED_PACKAGE_BOUNDARY');")
x=x.replace("      const result = nextResolve(specifier,context);", """      if (!/^(?:file:|\\.?\\.?\\/|\\/)/.test(specifier) && !specifier.includes(':')) {
        // Native resolution follows package symlinks. Inspect each possible
        // node_modules spelling first, including scoped names, while still
        // preserving the native resolver's result and package export rules.
        const name = specifier.startsWith('@') ? specifier.split('/').slice(0,2).join('/') : specifier.split('/')[0];
        let directory = context.parentURL?.startsWith('file:') ? path.dirname(fileURLToPath(context.parentURL)) : root;
        while (within(directory, root)) {
          const candidate = path.join(directory,'node_modules',name);
          let current = candidate;
          while (within(current,root)) {
            try { if (fs.lstatSync(current).isSymbolicLink()) fail('MODULE_SYMLINK'); }
            catch(error) { if (error.code!=='ENOENT' && error.code!=='ENOTDIR') throw error; }
            if (current===root) break; current=path.dirname(current);
          }
          if (directory===root) break; directory=path.dirname(directory);
        }
      }
      const result = nextResolve(specifier,context);""")
x=x.replace("      if (!(typeof result.source", "      if (![undefined,null,'module','commonjs','json'].includes(result.format) ||\n        ![undefined,null,'module','commonjs','json'].includes(context.format)) fail('MODULE_FORMAT_UNSUPPORTED');\n      if (!(typeof result.source")
a=x.index('export function parseNativeTap(');b=x.index('export function assertUnapproved',a)
x=x[:a]+r'''export function parseNativeTap(text, required = []) {
  requireCondition(typeof text === 'string' && text.startsWith('TAP version 13\n') && text.endsWith('\n'), 'TAP_ENVELOPE_INVALID');
  requireCondition(!/^(?:\s*not ok\b|Bail out!)/m.test(text) && !/#\s*(?:SKIP|TODO)\b/i.test(text), 'TAP_NONPASS');
  const root={depth:0,completed:[],pending:null,plan:null}, scopes=new Map([[0,root]]), records=[], totals=new Map();
  let diagnostic=null, last=null, ended=false;
  for (const line of text.split('\n').slice(1,-1)) {
    if (line==='') continue;
    requireCondition(!ended,'TAP_MALFORMED');
    if (diagnostic) {
      if (line===' '.repeat(diagnostic.indent)+'...') { diagnostic=null;continue; }
      const field=new RegExp('^ {'+diagnostic.indent+"}(duration_ms|type): (.+)$").exec(line);
      requireCondition(field && !diagnostic.fields.has(field[1]),'TAP_MALFORMED');diagnostic.fields.add(field[1]);
      if(field[1]==='type') { requireCondition(["'test'","'suite'"].includes(field[2]),'TAP_MALFORMED');diagnostic.record.type=field[2].slice(1,-1); }
      else requireCondition(/^[0-9]+(?:\.[0-9]+)?$/.test(field[2]),'TAP_MALFORMED');
      continue;
    }
    const diag=/^( *)---$/.exec(line);
    if(diag) { requireCondition(last && diag[1].length===last.depth*4+2 && !last.diagnostic,'TAP_MALFORMED');last.diagnostic=true;diagnostic={record:last,indent:diag[1].length,fields:new Set()};continue; }
    const counter=/^# (tests|suites|pass|fail|cancelled|skipped|todo) ([0-9]+)$/.exec(line);
    if(counter) { requireCondition(root.plan!==null && !totals.has(counter[1]),'TAP_DUPLICATE_COUNTER');totals.set(counter[1],Number(counter[2]));continue; }
    if(/^# duration_ms [0-9]+(?:\.[0-9]+)?$/.test(line)) { requireCondition(root.plan!==null,'TAP_MALFORMED');ended=true;continue; }
    const item=/^( *)(?:# Subtest: (.+)|ok ([1-9][0-9]*) - (.+)|1\.\.([0-9]+))$/.exec(line);
    requireCondition(item && item[1].length%4===0,'TAP_MALFORMED');
    const depth=item[1].length/4;
    let scope=scopes.get(depth);
    if(!scope) {
      const parent=scopes.get(depth-1)?.pending;
      requireCondition(parent && item[2]!==undefined,'TAP_MALFORMED');
      scope={depth,completed:[],pending:null,plan:null,parent};scopes.set(depth,scope);parent.children=scope;
    }
    if(item[2]!==undefined) {
      requireCondition(scope.plan===null && scope.pending===null,'TAP_MALFORMED');
      scope.pending={name:item[2],depth,type:'test',children:null};
    } else if(item[3]!==undefined) {
      requireCondition(scope.pending && Number(item[3])===scope.completed.length+1 && scope.pending.name===item[4],'TAP_SEQUENCE');
      const record=scope.pending;
      if(record.children) { requireCondition(record.children.plan===record.children.completed.length && record.children.pending===null,'TAP_CASE_INVENTORY');scopes.delete(depth+1); }
      scope.completed.push(record);records.push(record);scope.pending=null;last=record;
    } else {
      requireCondition(scope.pending===null && scope.plan===null,'TAP_DUPLICATE_PLAN');scope.plan=Number(item[5]);
      requireCondition(scope.plan===scope.completed.length,'TAP_CASE_INVENTORY');
    }
  }
  const tests=records.filter(r=>r.type==='test'), leaves=tests.filter(r=>!r.children), names=tests.map(r=>r.name);
  requireCondition(!diagnostic && ended && root.plan===root.completed.length && root.plan>0 && leaves.length>0 &&
    new Set(names).size===names.length,'TAP_CASE_INVENTORY');
  requireCondition(totals.get('tests')===tests.length && totals.get('suites')===records.length-tests.length && totals.get('pass')===tests.length &&
    ['fail','cancelled','skipped','todo'].every(k=>totals.get(k)===0),'TAP_TERMINAL_COUNTERS');
  requireCondition(leaves.every(r=>!/(?:^|\/)[^ ]*\.test\.(?:mjs|cjs|js)$/.test(r.name)),'TAP_WRAPPER_ONLY');
  requireCondition(required.every(n=>names.includes(n)),'TAP_MANDATORY_CASE_MISSING');
  return { names, count:tests.length, leaf_count:leaves.length, leaf_names:leaves.map(r=>r.name), suites:records.length-tests.length };
}
''' +x[b:]
p.write_text(x)
files=[s/'package-lock.json']+sorted((s/'verification/wp5/v1.1.0').rglob('*'));(s/'manifest.json').write_text(json.dumps({'files':[{'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files if p.is_file()]},indent=2)+'\n')
