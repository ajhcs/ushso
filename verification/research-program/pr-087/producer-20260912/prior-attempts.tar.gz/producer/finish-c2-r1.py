import subprocess
r='/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation/'
subprocess.run(['python3',r+'apply-test.py','09f9bb5bffe44e8695dd9738c6df56527460360f','stage-c2-r1','c2-r1-attempt2'],check=True)
subprocess.run(['python3',r+'final-c2-r1.py'],check=True)
