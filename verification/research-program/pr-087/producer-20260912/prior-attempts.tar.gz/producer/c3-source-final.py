import pathlib,json,hashlib,subprocess,os,datetime
w=pathlib.Path.cwd();r=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation');run=r/'c3-source-final';run.mkdir(exist_ok=False)
subprocess.run(['worktree-bootstrap','verify',os.environ['WORKTREE_BOOTSTRAP_TASK'],'--repo','.','--require-writer'],check=True)
h='33b3146dec73984087b49724cc18e690310b0b1d';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==h;assert not subprocess.check_output(['git','status','--porcelain'],text=True)
manifest=json.loads((r/'stage-c2-r1/manifest.json').read_text())
for name,argv,expected in [('current-root-wp5',['node','scripts/run-contract-suites.mjs','--suite','wp5'],0),('historical-wp5-stale',['node','verification/wp5/v1.0.0/tools/validate-wp5.mjs'],1),('wp11-historical-stale',['node','verification/wp11/v1.3.0/tools/verify.mjs','--validate'],1),('wp11-current-unknown-lock',['node','scripts/verify-wp11-attestation.mjs'],1)]:
 d=run/name;d.mkdir();env=os.environ.copy();env['TMPDIR']=str(d)
 for k in ['NODE_OPTIONS','NODE_PATH','NODE_TEST_CONTEXT','WP5_PROBE_POLICY','USHSO_WP5_RUN_SPEC']:env.pop(k,None)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
 with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:p=subprocess.run(argv,stdout=out,stderr=err,env=env)
 ended=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
 receipt={'head':h,'argv':argv,'started_at':started,'completed_at':ended,'exit_code':p.returncode,'expected_exit_code':expected,'stdout_sha256':hashlib.sha256((d/'stdout.log').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((d/'stderr.log').read_bytes()).hexdigest()}
 (d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if p.returncode!=expected:print((d/'stdout.log').read_text()[-3000:]);print((d/'stderr.log').read_text()[-3000:]);raise SystemExit(1)
 if expected:print((d/'stderr.log').read_text()[-1800:],flush=True)
for f in manifest['files']:assert hashlib.sha256((w/f['path']).read_bytes()).hexdigest()==f['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
