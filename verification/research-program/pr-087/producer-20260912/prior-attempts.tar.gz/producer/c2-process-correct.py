import pathlib,json,hashlib
s=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation/stage-c2');p=s/'verification/wp5/v1.1.0/tools/common.mjs';x=p.read_text();x=x.replace("  const root = path.resolve(spec.root); assertManifest(spec.files);", "  const limits = {...spec.module_limits};\n  for(const key of ['maximum_packages','maximum_module_files','maximum_total_module_bytes','maximum_module_file_bytes','maximum_package_depth'])\n    requireCondition(Number.isSafeInteger(limits[key]) && limits[key]>0,'MODULE_LIMIT_INVALID');\n  const root = path.resolve(spec.root); assertManifest(spec.files);")
x=x.replace("  const limits = spec.module_limits;\n",'')
a=x.index('export async function runBoundedChild(');b=x.index('async function compareCurrentControls',a)
x=x[:a]+'''export async function runBoundedChild(argv, { cwd, env, maximumMilliseconds, maximumOutputBytes }) {
  requireCondition(Number.isSafeInteger(maximumMilliseconds) && maximumMilliseconds>0 && Number.isSafeInteger(maximumOutputBytes) && maximumOutputBytes>0,'CHILD_LIMIT_INVALID');
  requireCondition(process.platform!=='win32','POSIX_PROCESS_GROUP_REQUIRED');
  return new Promise((resolve,reject) => {
    // A fresh POSIX group keeps ordinary child helpers within this command's
    // lifetime. This is cleanup/accounting, not confinement of hostile code.
    const child=spawn(process.execPath,argv,{cwd,env,detached:true,stdio:['ignore','pipe','pipe']});
    const chunks={stdout:[],stderr:[]};let bytes=0,reason=null,settled=false,cleanupTimer;
    let exitCode=null,exitSignal=null;
    const terminateGroup=()=>{
      if(!child.pid) return;
      try { process.kill(-child.pid,'SIGKILL'); }
      catch(error) { if(error.code!=='ESRCH') reason??='CHILD_GROUP_CLEANUP_FAILED'; }
    };
    const finish=(code,signal)=>{
      if(settled)return;settled=true;clearTimeout(timer);clearTimeout(cleanupTimer);
      resolve({argv,pid:child.pid,code,signal,reason,stdout:Buffer.concat(chunks.stdout).toString('utf8'),stderr:Buffer.concat(chunks.stderr).toString('utf8'),bytes});
    };
    const stop=(code)=>{
      reason??=code;terminateGroup();
      // Even an unsupported escaped pipe owner cannot make receipt settlement
      // unbounded. Such a result remains a failure with partial output.
      cleanupTimer??=setTimeout(()=>{
        reason='CHILD_CLEANUP_TIMEOUT';child.stdout.destroy();child.stderr.destroy();child.unref();
        finish(exitCode,exitSignal);
      },250);
    };
    const timer=setTimeout(()=>stop('CHILD_DEADLINE'),maximumMilliseconds);
    for(const stream of ['stdout','stderr']) child[stream].on('data',(chunk)=>{
      bytes+=chunk.length;
      if(bytes>maximumOutputBytes) stop('CHILD_OUTPUT_LIMIT');
      else chunks[stream].push(chunk);
    });
    child.once('error',(error)=>{
      if(settled)return;settled=true;clearTimeout(timer);clearTimeout(cleanupTimer);terminateGroup();
      child.stdout.destroy();child.stderr.destroy();reject(error);
    });
    child.once('exit',(code,signal)=>{
      exitCode=code;exitSignal=signal;
      // An otherwise successful parent must not leave its helpers alive.
      try { process.kill(-child.pid,0);stop('CHILD_DESCENDANTS_REMAIN'); }
      catch(error) { if(error.code!=='ESRCH') stop('CHILD_GROUP_CLEANUP_FAILED'); }
    });
    child.once('close',(code,signal)=>finish(code,signal));
  });
}

''' +x[b:]
p.write_text(x)
p=s/'verification/wp5/v1.1.0/tests/current-technical.test.mjs';x=p.read_text().replace("    const guard=createModuleGuard({...spec,module_limits:{...moduleLimits,...limits}});\n    assert.throws(()=>{load(guard", "    assert.throws(()=>{const guard=createModuleGuard({...spec,module_limits:{...moduleLimits,...limits}});load(guard")
x=x.replace("/LIMIT|DEPENDENCY_PACKAGE_BOUNDARY/", "/LIMIT|DEPENDENCY_PACKAGE_BOUNDARY/")
x += '''
test('missing and nonpositive or noninteger module limits reject before any module load',(t)=>{
  const f=fixture(t),spec=f.spec();
  for(const key of Object.keys(moduleLimits))for(const value of [undefined,0,-1,1.5,NaN,Infinity]){
    assert.throws(()=>createModuleGuard({...spec,module_limits:{...moduleLimits,[key]:value}}),/MODULE_LIMIT_INVALID/);
  }
});
test('deadline terminates task-owned descendants and drains inherited pipes within the bound',async(t)=>{
  const f=fixture(t);const marker=path.join(f.parent,'descendant.pid');
  f.put('app/parent.mjs',`import {spawn} from 'node:child_process';import fs from 'node:fs';const c=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{stdio:['ignore','inherit','inherit']});fs.writeFileSync(${JSON.stringify(marker)},String(c.pid));setInterval(()=>{},1000);`);
  const start=Date.now(),result=await runBoundedChild([path.join(f.root,'app/parent.mjs')],{...childOptions(f.root),maximumMilliseconds:300});
  assert.equal(result.reason,'CHILD_DEADLINE');assert.equal(result.signal,'SIGKILL');assert.ok(Date.now()-start<1500);
  const pid=Number(fs.readFileSync(marker,'utf8'));
  // A killed orphan may briefly remain as a reparented zombie. It must never
  // remain an executing process or keep an output pipe open.
  try { const status=fs.readFileSync(`/proc/${pid}/stat`,'utf8');assert.equal(status.slice(status.lastIndexOf(')')+2).split(' ')[0],'Z'); }
  catch(error){if(error.code!=='ENOENT')throw error;}
});
'''
p.write_text(x)
p=s/'verification/wp5/v1.1.0/README.md';x=p.read_text().replace('Child commands have deadlines, output limits, mandatory named controls and terminal module receipts.', 'Child commands use fresh POSIX process groups, deadlines, output limits, mandatory named controls and terminal module receipts. Timeout kills the command group; a 250 ms cleanup ceiling fails explicitly if streams cannot settle. These cleanup controls do not confine hostile descendants.');p.write_text(x)
files=[s/'package-lock.json']+sorted((s/'verification/wp5/v1.1.0').rglob('*'));(s/'manifest.json').write_text(json.dumps({'files':[{'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files if p.is_file()]},indent=2)+'\\n')
