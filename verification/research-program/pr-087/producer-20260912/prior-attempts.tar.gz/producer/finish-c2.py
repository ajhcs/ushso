import subprocess
r='/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation/'
subprocess.run(['python3',r+'apply-test.py','eb446d9da8ad6243f927a82dc5ca07710efc1a7e','stage-c2','c2-attempt5'],check=True)
subprocess.run(['python3',r+'final-c2-corrected.py'],check=True)
