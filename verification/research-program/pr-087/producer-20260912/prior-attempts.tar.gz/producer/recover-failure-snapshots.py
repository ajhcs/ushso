from pathlib import Path
import json,hashlib,subprocess
r=Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation');w=Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/.ushso-pr010-component-assembly-20260912-worktrees/ushso-pr087-current-wp5-20260912')
rel='verification/wp5/v1.1.0/tests/current-technical.test.mjs';current=(w/rel).read_text();premin=current.replace("{runtime:{node:process.version+'-different'}}","{runtime:{node:'v22.15.0'}}")
x=premin[:premin.index("\ntest('missing and nonpositive")]
x=x.replace("\n  fs.mkdirSync(path.join(f.root,'app/empty'));assert.throws(()=>inventory(f.root,{...f.sourceSpec,recursive_roots:['linked/empty']}),/SYMLINK_FORBIDDEN/);",'')
x=x.replace("import test,{describe,it} from 'node:test';import assert", "import test from 'node:test';import assert")
x=x.replace("await t.test('child two',()=>{});});describe('new suite',()=>{it('suite leaf',()=>{});});`);", "await t.test('child two',()=>{});});`);")
x=x.replace("assert.equal(parsed.count,5);assert.equal(parsed.leaf_count,4);assert.equal(parsed.suites,1);", "assert.equal(parsed.count,4);")
x=x.replace("    assert.throws(()=>{const guard=createModuleGuard({...spec,module_limits:{...moduleLimits,...limits}});load(guard", "    const guard=createModuleGuard({...spec,module_limits:{...moduleLimits,...limits}});\n    assert.throws(()=>{load(guard")
for directory,body in [('c2-attempt1',x),('c2-runtime-final',premin)]:
 expected=next(f['sha256'] for f in json.loads((r/directory/'input-manifest.json').read_text())['files'] if f['path']==rel)
 actual=hashlib.sha256(body.encode()).hexdigest();print(directory,expected,actual);assert actual==expected;(r/directory/'current-technical.snapshot.mjs').write_text(body)
common='verification/wp5/v1.1.0/tools/common.mjs';body=subprocess.check_output(['git','show','eb446d9:'+common],cwd=w)
expected=next(f['sha256'] for f in json.loads((r/'c2-attempt1/input-manifest.json').read_text())['files'] if f['path']==common);assert hashlib.sha256(body).hexdigest()==expected;(r/'c2-attempt1/common.snapshot.mjs').write_bytes(body)
