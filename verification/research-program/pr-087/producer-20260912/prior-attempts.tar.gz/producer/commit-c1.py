import pathlib,json,hashlib,subprocess,os
w=pathlib.Path.cwd();r=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation')
subprocess.run(['worktree-bootstrap','verify',os.environ['WORKTREE_BOOTSTRAP_TASK'],'--repo','.','--require-writer'],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='735268b80c6cafabfb559882c2d3e82e0ec74c4e'
m=json.loads((r/'stage-c1/manifest.json').read_text());assert len(m['files'])==17
for f in m['files']:assert hashlib.sha256((w/f['path']).read_bytes()).hexdigest()==f['sha256']
old=json.loads(subprocess.check_output(['git','show','HEAD:package-lock.json']));new=json.loads((w/'package-lock.json').read_text())
for key in ['verification/wp5/v1.1.0','node_modules/@ushso/verification-wp5-v1-1']:assert key not in old['packages'];new['packages'].pop(key)
assert old==new
run=r/'c1-root-discovery';run.mkdir(exist_ok=False)
env=os.environ.copy();env['TMPDIR']=str(run)
for k in ['NODE_OPTIONS','NODE_PATH','NODE_TEST_CONTEXT','WP5_PROBE_POLICY']:env.pop(k,None)
argv=['node','scripts/run-contract-suites.mjs','--suite','wp5']
with (run/'stdout.log').open('wb') as out,(run/'stderr.log').open('wb') as err:p=subprocess.run(argv,stdout=out,stderr=err,env=env)
(run/'receipt.json').write_text(json.dumps({'argv':argv,'exit_code':p.returncode},indent=2)+'\n')
print((run/'stdout.log').read_text()[-6000:]);print((run/'stderr.log').read_text()[-2000:]);assert p.returncode==0
subprocess.run(['git','add','--']+[f['path'] for f in m['files']],check=True)
assert sorted(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines())==sorted(f['path'] for f in m['files'])
subprocess.run(['git','commit','-m','feat(wp5): add current technical verification package (C0871)'],check=True)
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'source_manifest':m,'focused_tests':'c1-attempt1/receipt.json','root_discovery':'c1-root-discovery/receipt.json'}
(r/'c1-commit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='source_manifest'}))
