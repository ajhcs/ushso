import pathlib,json,hashlib,shutil
r=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation')
w=pathlib.Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/.ushso-pr010-component-assembly-20260912-worktrees/ushso-pr087-current-wp5-20260912')
s=r/'stage-c1';pkg=s/'verification/wp5/v1.1.0';pkg.mkdir(parents=True,exist_ok=True)
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
hashv=lambda x:hashlib.sha256(canon(x)).hexdigest()
def put(rel,data):
 p=pkg/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n' if not isinstance(data,str) else data)
a=w/'verification/research-program/bootstrap/pr087-current-technical-adoption-20260912'
o=w/'verification/research-program/pr-087/controller-dispatch-20260912'
pins=json.loads((a/'frozen-v1-source-pins.json').read_text())
origin=json.loads((o/'component-origin.json').read_text());inputs=json.loads((o/'component-input-pins.json').read_text())
files=['README.md','evidence-ledger.json','package.json','receipts/activation-status.json','receipts/delivery-wave-fixtures.json','receipts/fixture-matrix.json','receipts/legacy-lane-parity.json','receipts/r2-capture-protocol.json','receipts/request-capture-reconciliation.json','receipts/zero-payload-proof.json','tests/wp5-verification.test.mjs','tools/common.mjs','tools/validate-wp5.mjs','receipts/v1.0-package-pins.json','receipts/current-subject-policy.json','tests/current-technical.test.mjs']
put('receipts/v1.0-package-pins.json',pins)
put('receipts/current-subject-policy.json',{'format':'ushso.wp5-current-subject-policy.v1','design':json.loads((a/'current-subject-policy.json').read_text()),'origin':origin,'origin_hash':hashv(origin),'origin_input_pins':inputs,'origin_input_pins_hash':hashv(inputs),'package_files':['verification/wp5/v1.1.0/'+x for x in files]})
for rel in ['evidence-ledger.json']+['receipts/'+x+'.json' for x in ['activation-status','delivery-wave-fixtures','fixture-matrix','legacy-lane-parity','r2-capture-protocol','request-capture-reconciliation','zero-payload-proof']]:
 row=next(x for x in pins['files'] if x['path']=='verification/wp5/v1.0.0/'+rel)
 put(rel,{'format':'ushso.wp5-historical-reference.v1','evidence_kind':'historical_reference_only','current_result':None,'approval':None,'original':row,'meaning':'Original receipt remains immutable historical evidence. Current technical controls execute afresh; this reference transfers no approval and supplies no current PASS.'})
put('package.json',{'name':'@ushso/verification-wp5-v1-1','version':'1.1.0','private':True,'type':'module','engines':{'node':'>=22.15.0'},'scripts':{'test':'node --test tests/*.test.mjs','validate':'node tools/validate-wp5.mjs'}})
common=(s/'common.mjs').read_text().replace("requireCondition(pins.files.length === 13",f"requireCondition(digest(pins) === '{hashv(pins)}', 'HISTORICAL_PINS_ALTERED');\n  requireCondition(pins.files.length === 13")
put('tools/common.mjs',common)
put('tools/validate-wp5.mjs',"import { verifyCurrent } from './common.mjs';\nprocess.stdout.write(JSON.stringify(await verifyCurrent(), null, 2) + '\\n');\n")
put('tests/wp5-verification.test.mjs',"""import test from 'node:test';
import assert from 'node:assert/strict';
import { verifyCurrent, verifyHistorical, assertUnapproved } from '../tools/common.mjs';
test('frozen WP5 files remain historical references without current approval', () => {
  const history = verifyHistorical();
  assert.equal(history.files.length,13);
  assert.equal(history.origin.component_merge_sha,'e268652c5e92876a3540809595636c4795ebec6f');
});
test('all actual current connector controls execute on a newly measured unapproved subject', async () => {
  const result=await verifyCurrent();
  assertUnapproved(result);
  assert.equal(result.status,'PASS');
  assert.equal(result.execution.commands.filter((c)=>c.kind==='test').reduce((n,c)=>n+c.controls.count,0)>=48,true);
  assert.equal(result.subject.sha256.length,64);
  assert.ok(result.subject.value.modules.length>0);
  assert.ok(result.subject.value.packages.length>0);
});
""")
put('tests/current-technical.test.mjs',"""import test from 'node:test';
import assert from 'node:assert/strict';
import { digest, relativePath, semanticSubject, assertSubject } from '../tools/common.mjs';
test('current source changes produce distinct unapproved semantic identities', () => {
  const base={policy:{version:1},files:[{path:'a',sha256:'a'.repeat(64),bytes:1}],modules:[],packages:[],runtime:{node:process.version},fingerprint:'x',configuredPackageManager:'npm@11.19.1'};
  const first=semanticSubject(base),second=semanticSubject({...base,files:[{...base.files[0],sha256:'b'.repeat(64)}]});
  assert.notEqual(first.sha256,second.sha256);
  const result={evidence_kind:'current_technical_only',approval:null,historical_approval_transferred:false,current_approval_issued:false,release_qualified:false,live_collection:false,managed_persistence:false,production_changed:false,subject:first};
  assertSubject(result,first);
  assert.throws(()=>assertSubject(result,second),/CURRENT_SUBJECT_MISMATCH/);
  assert.throws(()=>assertSubject({...result,approval:'historical'},first),/CURRENT_APPROVAL_FORBIDDEN/);
  assert.equal(digest({b:1,a:2}),digest({a:2,b:1}));
});
test('manifest paths reject traversal, absolute paths and ambiguous components', () => {
  for(const invalid of ['../a','/a','a/../b','a//b','a/./b','a\\\\b','']) assert.throws(()=>relativePath(invalid),/INVALID_RELATIVE_PATH/);
  assert.equal(relativePath('a/b.json'),'a/b.json');
});
""")
put('README.md',"""# WP5 current technical verification — v1.1.0

This package runs current connector controls and emits their measured semantic subject. Every result is `current_technical_only`, with no approval, release qualification or activation. The thirteen v1.0.0 files remain unchanged historical evidence, including their original stale-fingerprint rejection. The eight reference receipts here never supply a current PASS.

Run `npm test --prefix verification/wp5/v1.1.0` and `npm run validate --prefix verification/wp5/v1.1.0` from the repository root using the committed lock and Node >=22.15.0. Both entrypoints execute all discovered connector tests, the full unchanged connector validator and current matrix, delivery, reconciliation and legacy-parity comparisons. The unchanged root runner selects this latest complete package.

The adopted policy declares bounded repository/data inventory, actual ESM/CJS/JSON loads and applicable installed package metadata/lock entries. A builtin-only preload registers synchronous Node module hooks before application imports; returned source must equal the file bytes. Child commands have deadlines, output limits, mandatory named controls and terminal module receipts. Inputs are checked again afterward. This is semantic input accounting, not a sandbox: arbitrary data reads, eval and hostile children still require source review.

M010 and its source/fixture pins establish historical origin. Present inputs are measured anew; legitimate later changes yield a different unapproved subject. The deterministic subject includes file/module/package bytes, policy, runtime and configured package manager. Execution timestamps, commands and output hashes are separate; direct Node runs report npm execution as unobserved. Generated receipts stay outside these sixteen files. Failed child diagnostics are retained in the task-owned temporary directory named by the error.

The isolated PR010 component origin is not research integration. Root independently reviews and qualifies the final PR010 + PR087 + PR086 composition through the full gate and hosted CI. Historical approval, live collection, managed persistence and production activation remain disabled.
""")
lock=json.loads((w/'package-lock.json').read_text());lock['packages']['verification/wp5/v1.1.0']={'name':'@ushso/verification-wp5-v1-1','version':'1.1.0','engines':{'node':'>=22.15.0'}};lock['packages']['node_modules/@ushso/verification-wp5-v1-1']={'resolved':'verification/wp5/v1.1.0','link':True}
(s/'package-lock.json').write_text(json.dumps(lock,indent=2,ensure_ascii=False)+'\n')
manifest=[]
for p in [s/'package-lock.json']+sorted(pkg.rglob('*')):
 if p.is_file(): manifest.append({'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(s/'manifest.json').write_text(json.dumps({'files':manifest},indent=2)+'\n')
print(json.dumps({'files':len(manifest),'stage':str(s),'historical_pins_digest':hashv(pins)}))
