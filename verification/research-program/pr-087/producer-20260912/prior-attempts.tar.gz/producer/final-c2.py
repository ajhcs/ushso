import pathlib,json,hashlib,subprocess,os,datetime,shutil
w=pathlib.Path.cwd();r=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation');run=r/'c2-runtime-final';run.mkdir(exist_ok=False)
subprocess.run(['worktree-bootstrap','verify',os.environ['WORKTREE_BOOTSTRAP_TASK'],'--repo','.','--require-writer'],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='eb446d9da8ad6243f927a82dc5ca07710efc1a7e'
m=json.loads((r/'stage-c2/manifest.json').read_text());
for f in m['files']:assert hashlib.sha256((w/f['path']).read_bytes()).hexdigest()==f['sha256']
(run/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
node22='/mnt/d/tmp/plumbob/ushso-implementation-plan-20260907/toolchains/node-v22.15.0-linux-x64/bin/node';node24=shutil.which('node')
commands=[('node22-tests',[node22,'--test','verification/wp5/v1.1.0/tests/wp5-verification.test.mjs','verification/wp5/v1.1.0/tests/current-technical.test.mjs']),('node22-validate',[node22,'verification/wp5/v1.1.0/tools/validate-wp5.mjs']),('node24-validate',[node24,'verification/wp5/v1.1.0/tools/validate-wp5.mjs'])]
receipts=[]
for name,argv in commands:
 d=run/name;d.mkdir();env=os.environ.copy();env['TMPDIR']=str(d)
 for k in ['NODE_OPTIONS','NODE_PATH','NODE_TEST_CONTEXT','WP5_PROBE_POLICY','USHSO_WP5_RUN_SPEC']:env.pop(k,None)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:p=subprocess.run(argv,env=env,stdout=out,stderr=err)
 receipt={'argv':argv,'exit_code':p.returncode,'started_at':started,'executable_sha256':hashlib.sha256(pathlib.Path(argv[0]).read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256((d/'stdout.log').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((d/'stderr.log').read_bytes()).hexdigest()}
 (d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');receipts.append(receipt);print(json.dumps(receipt),flush=True)
 if p.returncode:print((d/'stdout.log').read_text()[-8000:]);print((d/'stderr.log').read_text()[-8000:]);raise SystemExit(p.returncode)
 if 'validate' in name:
  observed=json.loads((d/'stdout.log').read_text());assert observed['status']=='PASS' and observed['evidence_kind']=='current_technical_only' and observed['approval'] is None
  assert observed['subject']['value']['runtime']['node']==('v22.15.0' if '22' in name else 'v24.14.0')
  print(json.dumps({'name':name,'subject':observed['subject']['sha256'],'files':len(observed['subject']['value']['files']),'modules':len(observed['subject']['value']['modules']),'packages':len(observed['subject']['value']['packages'])}),flush=True)
for f in m['files']:assert hashlib.sha256((w/f['path']).read_bytes()).hexdigest()==f['sha256']
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();assert sorted(changed)==sorted(['verification/wp5/v1.1.0/README.md','verification/wp5/v1.1.0/tests/current-technical.test.mjs','verification/wp5/v1.1.0/tools/common.mjs'])
subprocess.run(['git','add','--']+changed,check=True);subprocess.run(['git','commit','-m','test(wp5): enforce bounded current semantic inputs (C0872)'],check=True)
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'source_manifest':m,'commands':receipts,'original_failures':['c2-attempt1','c2-attempt2','c2-attempt3'],'final_focused':'c2-attempt4/receipt.json'}
(r/'c2-commit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['source_manifest','commands']}))
