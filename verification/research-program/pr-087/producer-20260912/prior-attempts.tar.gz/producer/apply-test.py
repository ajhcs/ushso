import os,pathlib,json,hashlib,subprocess,sys,datetime
w=pathlib.Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/.ushso-pr010-component-assembly-20260912-worktrees/ushso-pr087-current-wp5-20260912')
r=pathlib.Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-implementation')
assert pathlib.Path.cwd()==w
subprocess.run(['worktree-bootstrap','verify',os.environ['WORKTREE_BOOTSTRAP_TASK'],'--repo','.','--require-writer'],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==sys.argv[1]
stage=r/sys.argv[2];manifest=json.loads((stage/'manifest.json').read_text())
allowed={f'verification/wp5/v1.1.0/{x}' for x in ['README.md','evidence-ledger.json','package.json','receipts/activation-status.json','receipts/delivery-wave-fixtures.json','receipts/fixture-matrix.json','receipts/legacy-lane-parity.json','receipts/r2-capture-protocol.json','receipts/request-capture-reconciliation.json','receipts/zero-payload-proof.json','tests/wp5-verification.test.mjs','tools/common.mjs','tools/validate-wp5.mjs','receipts/v1.0-package-pins.json','receipts/current-subject-policy.json','tests/current-technical.test.mjs']}|{'package-lock.json'}
for f in manifest['files']:
 assert f['path'] in allowed
 b=(stage/f['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'] and len(b)==f['bytes']
for f in manifest['files']:
 p=w/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((stage/f['path']).read_bytes())
run=r/sys.argv[3];run.mkdir(exist_ok=False)
(run/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
argv=['node','/mnt/d/cache/plumbob/npm/_npx/ae109337638209d1/node_modules/npm/bin/npm-cli.js','test','--prefix','verification/wp5/v1.1.0']
env=os.environ.copy()
for k in ['NODE_OPTIONS','NODE_PATH','NODE_TEST_CONTEXT','WP5_PROBE_POLICY']:env.pop(k,None)
env['TMPDIR']=str(run)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (run/'stdout.log').open('wb') as out,(run/'stderr.log').open('wb') as err:p=subprocess.run(argv,env=env,stdout=out,stderr=err)
receipt={'argv':argv,'exit_code':p.returncode,'started_at':started,'head':sys.argv[1],'stage_manifest_sha256':hashlib.sha256((stage/'manifest.json').read_bytes()).hexdigest()}
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print((run/'stdout.log').read_text()[-14000:]);print((run/'stderr.log').read_text()[-4000:]);sys.exit(p.returncode)
