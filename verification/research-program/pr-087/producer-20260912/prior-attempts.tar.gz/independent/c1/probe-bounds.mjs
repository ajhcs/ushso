import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
const dir = '/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr087-source-review/c1';
const source = path.join(dir, 'source/verification/wp5/v1.1.0/tools/common.mjs');
const { createModuleGuard, sha256, runBoundedChild } = await import(pathToFileURL(source).href);
const root = path.join(dir, 'bounded-fixture');
fs.mkdirSync(path.join(root, 'verification/wp5/v1.1.0/tools'), { recursive: true });
fs.copyFileSync(source, path.join(root, 'verification/wp5/v1.1.0/tools/common.mjs'));
for (const name of ['one.mjs','two.mjs']) fs.writeFileSync(path.join(root,name), 'export default 1;\n');
const names = ['one.mjs','two.mjs','verification/wp5/v1.1.0/tools/common.mjs'];
const files = names.map((p) => { const b=fs.readFileSync(path.join(root,p)); return {path:p,sha256:sha256(b),bytes:b.length}; });
const limits = { maximum_packages:256, maximum_module_files:1, maximum_total_module_bytes:67108864, maximum_module_file_bytes:16777216, maximum_package_depth:16 };
const records = [];
for (const malformed of [false,true]) {
  const chosen={...limits}; if(malformed) delete chosen.maximum_module_files;
  const guard=createModuleGuard({root,files,lock:{packages:{}},module_limits:chosen});
  let code=null;
  try { for(const name of ['one.mjs','two.mjs']) guard.hooks.load(pathToFileURL(path.join(root,name)).href,{format:'module'},()=>({format:'module',source:fs.readFileSync(path.join(root,name))})); } catch(error) { code=error.code??error.message; }
  records.push({case:malformed?'missing-module-limit':'valid-one-module-limit',code,loaded:code?null:guard.finish().modules.length});
}
// Benign grandchild lives for only0.8 seconds; inherited pipes demonstrate close timing.
const child = "const {spawn}=require('node:child_process');spawn(process.execPath,['-e','setTimeout(()=>{},800)'],{stdio:['ignore',1,2]});setTimeout(()=>{},2000);";
const began=performance.now();
const result=await runBoundedChild(['-e',child],{cwd:root,env:{...process.env},maximumMilliseconds:100,maximumOutputBytes:4096});
records.push({case:'deadline-with-short-lived-inherited-pipe',elapsed_ms:performance.now()-began,limit_ms:100,result});
fs.writeFileSync(path.join(dir,'bounded-probe-results.json'),JSON.stringify({source_sha256:sha256(fs.readFileSync(source)),scope:'Pure exported helper probes using an exact immutableC1 snapshot and task-only files. No live worktree source imported or modified; no full controls or gate run.',records},null,2)+'\n');
console.log(JSON.stringify(records));
