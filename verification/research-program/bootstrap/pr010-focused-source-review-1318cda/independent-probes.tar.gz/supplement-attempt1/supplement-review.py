from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil,selectors
R=Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr010-root-durability-review');O=R/'supplement-attempt1';O.mkdir(exist_ok=False)
pins=json.loads((R/'attempt-2-continuation/pins.json').read_bytes());repo=Path(pins['repo']);env=os.environ.copy();env['USHSO_ROOT_REVIEW_PINS']=str(R/'attempt-2-continuation/pins.json')
shutil.copyfile(R/'driver.mjs',O/'driver.mjs');shutil.copyfile(Path(__file__),O/'supplement-review.py')
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
results=[];commands=[]
def invoke(name,cfg=None,expect=0,args=None):
 d=O/name;d.mkdir(exist_ok=True)
 if args is None:
  cfg.setdefault('state',str(d/'state'));cfg.setdefault('observer',str(d/'deliveries.jsonl'));cfg.setdefault('events',str(d/'events.jsonl'));args=['node',str(O/'driver.mjs'),json.dumps(cfg,separators=(',',':'))]
 c=subprocess.run(args,cwd=repo,env=env,capture_output=True,timeout=30);n=len(commands)+1;(d/f'{n}.stdout.log').write_bytes(c.stdout);(d/f'{n}.stderr.log').write_bytes(c.stderr)
 commands.append({'name':name,'argv':args,'exit_code':c.returncode,'expected':expect,'stdout_sha256':sha(c.stdout),'stderr_sha256':sha(c.stderr)});save(O/'commands.json',commands)
 assert c.returncode==expect,(name,c.returncode,c.stdout.decode(),c.stderr.decode());lines=[x for x in c.stdout.decode().splitlines() if x.startswith('{')];assert len(lines)==1,(name,lines);return cfg,json.loads(lines[0])
def snapshot(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
def copied(name):
 d=O/name;d.mkdir();shutil.copytree(R/'attempt-1/complete/state',d/'state');return {'action':'run','state':str(d/'state'),'observer':str(d/'deliveries.jsonl'),'events':str(d/'events.jsonl')}
def prop(x,key):assert x['t']=='object';return next(v for k,v in x['v'] if k==key)
def rows(p):return [(f,json.loads(f.read_bytes())) for f in sorted((Path(p)/'journal').glob('*.json'))]
def chain(p,rs):
 previous=None
 for f,x in rs:
  x['previous_record_sha256']=previous;x['result_digest']=sha(canonical(x['result']));b=canonical(x);f.write_bytes(b);previous=sha(b)
 # Independent recomputation of every retained sequence, result digest and hash link.
 previous=None
 for i,(f,x) in enumerate(rows(p),1):
  b=f.read_bytes();assert x['sequence']==i and f.name==f'{i:08d}.json' and x['previous_record_sha256']==previous and sha(canonical(x['result']))==x['result_digest'];previous=sha(b)
def passed(name,**detail):results.append({'name':name,'status':'PASS',**detail});save(O/'results.json',results)
try:
 # Actual competing OS processes, no manual lock cleanup.
 d=O/'process-lock';d.mkdir();cfg={'action':'hold','state':str(d/'state'),'observer':str(d/'deliveries.jsonl'),'events':str(d/'events.jsonl')};args=['node',str(O/'driver.mjs'),json.dumps(cfg)]
 with (d/'holder.stderr.log').open('wb') as err:
  holder=subprocess.Popen(args,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=err)
  try:
   sel=selectors.DefaultSelector();sel.register(holder.stdout,selectors.EVENT_READ);assert sel.select(10),'holder readiness deadline';line=holder.stdout.readline();sel.close();(d/'holder.stdout.log').write_bytes(line);ready=json.loads(line);assert ready['ready'] and ready['pid']==holder.pid
   before=snapshot(d/'state');_,blocked=invoke('process-lock',{**cfg,'action':'run'},2);assert blocked['code']=='WRITER_BUSY';assert snapshot(d/'state')==before and not (d/'deliveries.jsonl').exists()
  finally:
   if holder.poll() is None:holder.kill()
   holder.wait(timeout=10)
  assert holder.returncode==-9
 save(d/'holder-command.json',{'argv':args,'pid':holder.pid,'exit_code':holder.returncode,'signal':'SIGKILL','reaped':True})
 _,fresh=invoke('process-lock',{**cfg,'action':'run'});assert fresh['result']['status']=='complete_fixture';assert len((d/'deliveries.jsonl').read_text().splitlines())==2
 passed('real_process_lock_and_kernel_release',competing_code='WRITER_BUSY',actual_SIGKILLs=1,manual_lock_deletion=False)
 # Independent semantic corruptions maintain the complete low-level hash chain.
 for mode,code in [('cross-child','CROSS_CHILD_REPLAY'),('map-shape','REDUCER_REPLAY_MISMATCH'),('wrapper-receipt','RECEIPT_TAMPERED'),('false-terminal','ATTEMPT_RESULT_MISMATCH')]:
  cfg=copied(mode);rs=rows(cfg['state'])
  if mode=='cross-child':
   x=next(x for f,x in rs if x['kind']=='connector_operation');prop(x['payload'],'execution_id')['v']='run_'+'f'*32
  elif mode=='map-shape':
   x=next(x for f,x in rs if x['kind']=='connector_operation');prop(prop(x['result'],'projection'),'checkpoints')['t']='object'
  elif mode=='wrapper-receipt':
   x=next(x for f,x in rs if x['kind']=='wrapper_outcome');prop(prop(x['result'],'receipt'),'attempt_outcome')['v']='not_modified'
  else:
   x=next(x for f,x in rs if x['kind']=='attempt_outcome');prop(x['result'],'publication_authorized')['v']=True
  chain(cfg['state'],rs);before=snapshot(Path(cfg['state']));_,bad=invoke(mode,cfg,2);assert bad['code']==code,(mode,bad);assert snapshot(Path(cfg['state']))==before and not Path(cfg['observer']).exists()
  passed('rehashed_'+mode,expected_code=code,actual_delivery_count=0,journal_unchanged=True)
 cfg=copied('missing-object');f=next((Path(cfg['state'])/'objects').iterdir());removed={'name':f.name,'sha256':sha(f.read_bytes())};f.unlink();before=snapshot(Path(cfg['state']));_,bad=invoke('missing-object',cfg,2);assert bad['ok']==False;assert snapshot(Path(cfg['state']))==before and not Path(cfg['observer']).exists();passed('missing_actual_object_rejected',code=bad['code'],removed_fixture_object=removed,actual_delivery_count=0)
 # A new independently failing selection keeps the previously completed sibling immutable.
 cfg=copied('sibling-failure');before={f.name:sha(f.read_bytes()) for f,x in rows(cfg['state'])};_,bad=invoke('sibling-failure',{**cfg,'selection':['fixture-record-missing'],'reservation':'reservation_root_missing'});assert bad['result']['status']=='typed_failure';assert bad['summary']['parents']==1 and len(bad['summary']['children'])==2;assert all(sha((Path(cfg['state'])/'journal'/name).read_bytes())==digest for name,digest in before.items());assert sorted(x['status'] for x in bad['summary']['statuses'])==['complete_fixture','typed_failure'];passed('failed_sibling_does_not_promote_or_mutate_completed_child',same_parent=True,separate_children=2)
 cli=['node',str(repo/'packages/ingestion/src/local-job-cli.mjs')]
 d=O/'cli';d.mkdir();_,preview=invoke('cli',args=cli+['preview']);assert preview['publication_authorized']==False
 cfg=copied('cli-status');before=snapshot(Path(cfg['state']));_,status=invoke('cli',args=cli+['status','--state-dir',cfg['state']]);assert status['status']=='complete_fixture' and status['publication_authorized']==False and status['production_composition']==False;assert snapshot(Path(cfg['state']))==before
 _,blocked=invoke('cli',args=cli+['preview','--state-dir',str(d/'forbidden')],expect=2);assert not (d/'forbidden').exists();passed('actual_cli_preview_and_readonly_status',status_no_state_writes=True,preview_state_override_rejected=True)
except BaseException as e:
 save(O/'failure.json',{'type':type(e).__name__,'message':str(e),'completed_groups':len(results)});raise
finally:
 receipt={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':pins['source_head'],'source_tree':pins['source_tree'],'source_pins':len(pins['files']),'source_unchanged':all(sha((repo/x['path']).read_bytes())==x['sha256'] for x in pins['files']),'harness_sha256':sha((O/'supplement-review.py').read_bytes()),'driver_sha256':sha((O/'driver.mjs').read_bytes()),'completed_groups':len(results),'commands':len(commands),'failure':(O/'failure.json').exists(),'live_network':False,'build_or_gate':False,'final_acceptance':False};save(O/'summary.json',receipt);print(json.dumps(receipt))
