from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,shutil
R=Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr010-root-durability-review')
REPO=Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr010-local-jobs-20260912')
HEAD='1318cda5c76cd3262c7668fb7f56fab842876c6f';OUT=R/'attempt-1';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=REPO)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
roots=['packages/connectors','packages/ingestion/src','contracts/ingestion/v1.0.0','contracts/ingestion/v1.1.0','packages/retrieval/tools','scripts/research/refresh.mjs','scripts/research-program/operating-bounds.mjs','scripts/research-program/policy.json','scripts/research-program/receipts/v1.0.0','package-lock.json']
paths=git('ls-tree','-r','--name-only',HEAD,'--',*roots).decode().splitlines();pins=[]
for rel in paths:
 b=git('show',HEAD+':'+rel);assert (REPO/rel).read_bytes()==b,rel;pins.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
save(OUT/'pins.json',{'repo':str(REPO),'source_head':HEAD,'source_tree':git('rev-parse',HEAD+'^{tree}').decode().strip(),'files':pins})
shutil.copyfile(R/'driver.mjs',OUT/'driver.mjs');shutil.copyfile(Path(__file__),OUT/'run-review.py')
env=os.environ.copy();env['USHSO_ROOT_REVIEW_PINS']=str(OUT/'pins.json')
results=[];commands=[]
def invoke(name,cfg,expect=0):
 d=OUT/name;d.mkdir(parents=True,exist_ok=True);cfg.setdefault('state',str(d/'state'));cfg.setdefault('observer',str(d/'deliveries.jsonl'));cfg.setdefault('events',str(d/'events.jsonl'));cmd=['/home/plumbob/bin/with-dev-storage','node',str(OUT/'driver.mjs'),json.dumps(cfg,separators=(',',':'))]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();c=subprocess.run(cmd,env=env,cwd=REPO,capture_output=True,timeout=30);i=sum(x['name']==name for x in commands)+1;(d/f'command-{i}.stdout.log').write_bytes(c.stdout);(d/f'command-{i}.stderr.log').write_bytes(c.stderr)
 rec={'name':name,'started_at':started,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'exit_code':c.returncode,'expected_exit_code':expect,'stdout_sha256':sha(c.stdout),'stderr_sha256':sha(c.stderr)};commands.append(rec);save(OUT/'commands.json',commands)
 assert c.returncode==expect,(name,c.returncode,c.stdout.decode()[-1500:],c.stderr.decode()[-1000:])
 if expect<0:return cfg,None
 lines=[x for x in c.stdout.decode().splitlines() if x.startswith('{')];assert len(lines)==1,(name,c.stdout.decode());return cfg,json.loads(lines[0])
def deliveries(cfg):
 p=Path(cfg['observer']);return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
def journal(state):
 p=Path(state);rows=[];previous=None
 def decode(x):
  t=x['t']
  if t=='null':return None
  if t=='undefined':return {'__independent_undefined__':True}
  if t in ['number','string','boolean']:return x['v']
  if t=='array':return [decode(v) for v in x['v']]
  if t=='map':return {'__independent_map__':[[decode(k),decode(v)] for k,v in x['v']]}
  if t=='object':return {k:decode(v) for k,v in x['v']}
  if t=='bytes_ref':
   b=(p/'objects'/x['sha256']).read_bytes();assert sha(b)==x['sha256'] and len(b)==x['byte_length'];return {'__independent_bytes_ref__':x['sha256'],'bytes':len(b)}
  raise AssertionError(t)
 names=sorted(x for x in (p/'journal').iterdir() if not x.name.startswith('.pending-'))
 for i,f in enumerate(names,1):
  b=f.read_bytes();x=json.loads(b);assert f.name==f'{i:08d}.json' and x['sequence']==i and x['previous_record_sha256']==previous and canonical(x)==b;assert sha(canonical(x['result']))==x['result_digest'];previous=sha(b);rows.append({'raw':x,'sha256':previous,'kind':x['kind'],'id':x['operation_id'],'payload':decode(x['payload']),'result':decode(x['result'])})
 for f in (p/'objects').iterdir():
  if f.name.startswith('.pending-'):continue
  assert f.is_file() and sha(f.read_bytes())==f.name
 return rows
def business(rows):return [(r['id'],r['sha256']) for r in rows if r['kind']!='replay_session']
def finish_case(name,detail):results.append({'name':name,'status':'PASS',**detail});save(OUT/'results.json',results)
try:
 # Reference run uses actual collector but all lineage/hash/count assertions below are independent disk reads.
 cfg,res=invoke('complete',{'action':'run'});assert res['ok'] and res['result']['status']=='complete_fixture';rows=journal(cfg['state']);assert len(deliveries(cfg))==2
 assert res['summary']['parents']==res['summary']['outbox']==1 and all(x['closed'] for x in res['summary']['clients'])
 captures=[r for r in rows if r['kind']=='capture_reference'];assert len(captures)==2 and len({r['result']['capture_ref_id'] for r in captures})==2
 for i,r in enumerate(captures):
  x=r['result'];assert x['source_locator']['redacted_locator']=='https://catalog.example.gov/data.json';assert x['captured_at']==f'2026-09-12T00:00:0{i}.000Z' and x['clocks']['recorded_at']==f'2026-09-12T00:00:0{i}.001Z'
 before=business(rows);_,repeat=invoke('complete',{**cfg,'action':'run'});assert repeat['result']==res['result'] and len(deliveries(cfg))==2 and business(journal(cfg['state']))==before
 finish_case('complete_and_terminal_replay',{'deliveries':2,'captured_references':2,'terminal_records':1})
 windows=[
  ('child_admission',{'point':'after_record_commit','kind':'child_admitted'},0,'complete_fixture',2),
  ('lease_commit',{'point':'after_record_commit','kind':'scheduler_transaction','label':'scheduler-lease-due'},0,'complete_fixture',2),
  ('parent_commit',{'point':'after_record_commit','kind':'scheduler_transaction','label':'scheduler-source'},0,'complete_fixture',2),
  ('intent_before_delivery',{'point':'after_record_commit','kind':'request_intent'},0,'partial_unresolved',0),
  ('delivery_unknown',{'point':'after_fixture_delivery'},1,'partial_unresolved',1),
  ('response_durable',{'point':'after_record_commit','kind':'response'},1,'complete_fixture',2),
  ('capture_object',{'point':'capture.after_object_write_before_reference_commit'},1,'complete_fixture',2),
  ('capture_reference',{'point':'after_record_commit','kind':'capture_reference'},1,'complete_fixture',2),
  ('wrapper_before_page',{'point':'runner.after_fetch_before_page_commit','page':0},1,'complete_fixture',2),
  ('page_before_resume',{'point':'runner.after_page_commit_before_resume','page':0},1,'complete_fixture',2),
  ('sealed_before_checkpoint',{'point':'runner.after_seal_before_checkpoint_commit'},2,'complete_fixture',2),
  ('checkpoint_before_terminal',{'point':'runner.after_checkpoint_transaction'},2,'complete_fixture',2),
  ('terminal_before_exit',{'point':'after_record_commit','kind':'attempt_outcome'},2,'complete_fixture',2)
 ]
 for name,crash,before_calls,status,total_calls in windows:
  c,_=invoke(name,{'action':'run','crash':crash},-9);prefix=journal(c['state']);assert len(deliveries(c))==before_calls and Path(c['events']).is_file();refs={r['id']:r['sha256'] for r in prefix if r['kind']=='capture_reference'}
  c.pop('crash');_,actual=invoke(name,c);assert actual['ok'] and actual['result']['status']==status,(name,actual);assert len(deliveries(c))==total_calls
  replay=journal(c['state']);assert all(any(r['id']==k and r['sha256']==v for r in replay) for k,v in refs.items());assert sum(r['kind']=='attempt_outcome' for r in replay)==1
  assert actual['summary']['parents']==actual['summary']['outbox']==1
  if status=='partial_unresolved':assert sum(r['kind']=='request_intent' for r in replay)==1 and not any(r['kind']=='capture_reference' for r in replay)
  state_before=business(replay);_,twice=invoke(name,c);assert twice['result']==actual['result'] and len(deliveries(c))==total_calls and business(journal(c['state']))==state_before
  finish_case(name,{'real_death_signal':'SIGKILL','deliveries_before':before_calls,'deliveries_after_restarts':total_calls,'terminal_status':status,'existing_capture_reference_bytes_preserved':True})
 # Actual prior child evidence reused with304 without a new public capture object/reference.
 prior=res['result']['collection_job_id'];before=journal(cfg['state']);oldrefs={r['id']:r['sha256'] for r in before if r['kind']=='capture_reference'}
 _,reuse=invoke('complete',{**cfg,'action':'run','reuse':True,'priorChild':prior,'selection':['fixture-record-a'],'reservation':'root_reuse_reservation'});assert reuse['result']['status']=='complete_fixture';after=journal(cfg['state']);assert {r['id']:r['sha256'] for r in after if r['kind']=='capture_reference'}==oldrefs
 fresh=[r for r in after if r['kind']=='wrapper_outcome' and r['payload']['child_id']==reuse['result']['collection_job_id']];assert len(fresh)==2 and all(r['result']['legacy']['http_status']==304 and r['result']['legacy']['bytes']==0 and r['result']['strict']['outcome']=='not_modified' for r in fresh);assert reuse['summary']['parents']==reuse['summary']['outbox']==1 and len(reuse['summary']['children'])==2
 finish_case('cross_child_verified_304_reuse',{'new_capture_references':0,'body_bytes':0,'reused_pages':2,'shared_parent_separate_children':True})
 # Actual source transaction throws after the existing reducer mutates its transactional draft.
 cfgp,tx=invoke('transaction_poison',{'action':'transaction-poison'});assert tx['ok'] and tx['observedLease']==1;prefix=journal(cfgp['state']);assert not any(r['kind']=='scheduler_transaction' and r['payload'].get('calls',[{}])[0].get('args',[{}])[0].get('scheduledSlot')=='2026-09-14T00:00:00.000Z' for r in prefix)
 _,recovered=invoke('transaction_poison',{**cfgp,'action':'run'});assert recovered['result']['status']=='complete_fixture' and len(deliveries(cfgp))==2
 finish_case('actual_transaction_abort_and_shared_poison',{'blocked_old_new_operations':7,'fresh_process_complete':True})
 # A durable-write failure after a reducer mutation poisons old composition; verified prefix is recoverable.
 cfgp,poison=invoke('persistence_poison',{'action':'run','throwFault':True,'crash':{'point':'after_record_commit','kind':'scheduler_transaction','label':'scheduler-source'}});assert poison['ok'] and poison['poison'];assert len(deliveries(cfgp))==0;cfgp.pop('throwFault');cfgp.pop('crash');_,recovered=invoke('persistence_poison',cfgp);assert recovered['result']['status']=='complete_fixture' and len(deliveries(cfgp))==2
 finish_case('persisted_transaction_ambiguous_ack_poison',{'blocked_operations':4,'fresh_process_parent_reused':True})
 cfgl,late=invoke('late_response',{'action':'late','timeout':100});assert late['ok'] and late['result']['status']=='typed_failure' and len(deliveries(cfgl))==1;rows=journal(cfgl['state']);assert not any(r['kind']=='capture_reference' or (r['kind']=='connector_operation' and r['payload']['method']=='commitPage') for r in rows);assert sum(r['kind']=='request_intent' for r in rows)==1
 finish_case('actual_deadline_no_late_promotion',{'deliveries':1,'late_capture_and_page_mutations':0,'terminal':'typed_failure'})
except BaseException as e:
 save(OUT/'failure.json',{'type':type(e).__name__,'message':str(e),'completed_groups':len(results)});raise
finally:
 unchanged=all(sha((REPO/p['path']).read_bytes())==p['sha256'] for p in pins)
 save(OUT/'summary.json',{'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':HEAD,'source_tree':git('rev-parse',HEAD+'^{tree}').decode().strip(),'source_files_pinned':len(pins),'source_unchanged':unchanged,'driver_sha256':sha((OUT/'driver.mjs').read_bytes()),'orchestrator_sha256':sha((OUT/'run-review.py').read_bytes()),'completed_groups':len(results),'failure':(OUT/'failure.json').exists(),'real_SIGKILL_commands':sum(c['exit_code']==-9 for c in commands),'commands':len(commands),'live_network':False,'build_or_gate':False,'final_acceptance':False})
print(json.dumps(json.loads((OUT/'summary.json').read_bytes())))
