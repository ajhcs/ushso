import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const cfg=JSON.parse(process.argv[2]);
const pins=JSON.parse(fs.readFileSync(process.env.USHSO_ROOT_REVIEW_PINS,'utf8'));
const repo=pins.repo;
const hash=b=>createHash('sha256').update(b).digest('hex');
function check(){for(const p of pins.files)assert.equal(hash(fs.readFileSync(path.join(repo,p.path))),p.sha256,p.path)}
check();
const {createLocalCollector}=await import(pathToFileURL(path.join(repo,'packages/ingestion/src/local-collector-adapter.mjs')));
const {loadFixtureCatalog}=await import(pathToFileURL(path.join(repo,'packages/ingestion/src/local-fixture-catalog.mjs')));
const fixture=await loadFixtureCatalog();
if(cfg.timeout)fixture.input.budget_reservation.timeout_ms=cfg.timeout;
let collector,delayed,lateResolve;
let armed=cfg.crash;
function observer(row){fs.appendFileSync(cfg.observer,JSON.stringify({pid:process.pid,...row})+'\n')}
function summary(){const x=collector.inspect();return {children:[...x.children.keys()],parents:x.scheduler.runs.size,outbox:x.scheduler.outbox.size,clients:x.scheduler.clientLifecycle.map(x=>({closed:x.closed})),statuses:[...x.children.keys()].map(id=>collector.status(id)),records:collector.store.records.map(r=>({kind:r.kind,id:r.operation_id,hash:r.sha256}))}}
try{
 collector=await createLocalCollector({stateDir:cfg.state,fixture,
 onDelivery:observer,
 fault:async(point,detail)=>{
  if(!armed||point!==armed.point)return;
  if(armed.kind&&detail.kind!==armed.kind)return;
  if(armed.label&&collector?.store.records.at(-1)?.payload?.label!==armed.label)return;
  if(armed.page!==undefined&&detail.pageIndex!==armed.page)return;
  fs.appendFileSync(cfg.events,JSON.stringify({point,detail,pid:process.pid})+'\n');
  if(cfg.throwFault){const e=new Error('Root injected durable storage failure');e.code='ROOT_STORAGE_FAULT';throw e;}
  process.kill(process.pid,'SIGKILL');
 },
 responseFor:cfg.action==='late'?async({response})=>{delayed=response;return new Promise(r=>lateResolve=r)}:cfg.reuse?async({response})=>({...response,status:304,bodyBytes:new Uint8Array()}):null
 });
 if(cfg.action==='hold'){console.log(JSON.stringify({ready:true,pid:process.pid}));setInterval(()=>{},1000);await new Promise(()=>{});}
 const input={...fixture.input,selected_record_ids:cfg.selection??fixture.input.selected_record_ids,budget_reservation:{...fixture.input.budget_reservation,reservation_id:cfg.reservation??fixture.input.budget_reservation.reservation_id}};
 const admitted=await collector.admit(input);assert.equal(admitted.kind,'admitted');
 const job=admitted.job;
 if(cfg.reuse)await collector.seedFixtureReuse({childId:job.collection_job_id,priorChildId:cfg.priorChild});
 if(cfg.action==='transaction-poison'){
  await collector.schedule(job);const before=summary();const db=await collector.openDatabase();let observedLease;
  await assert.rejects(db.transaction('scheduler-lease-due',async tx=>{observedLease=await tx.leaseDueSources({scheduledSlot:'2026-09-14T00:00:00.000Z',leaseAcquiredAt:'2026-09-14T00:00:00.000Z',leaseOwner:'scheduler_'+'a'.repeat(32),leaseExpiresAt:'2026-09-14T00:00:30.000Z',limit:1});throw new Error('ROOT_TX_CALLBACK_FAIL');}),/ROOT_TX_CALLBACK_FAIL/);
  assert.equal(observedLease.length,1);
  const errors=[];
  for(const op of [()=>db.transaction('scheduler-lease-due',()=>[]),()=>collector.openDatabase(),()=>collector.admit(input),()=>collector.execute(job.collection_job_id),()=>collector.store.putObject(new Uint8Array([1])),()=>collector.store.record('replay_session','unexpected',{},null),()=>collector.status(job.collection_job_id)]){
   try{await op();errors.push(null)}catch(e){errors.push(e.code)}
  }
  assert.ok(errors.every(x=>x==='LOCAL_STORE_POISONED'));
  await db.close();await collector.close();check();console.log(JSON.stringify({ok:true,action:cfg.action,before,errors,observedLease:observedLease.length}));
 }else{
  let result;
  try{result=await collector.execute(job.collection_job_id)}catch(error){
   if(!cfg.throwFault)throw error;
   const errors=[];for(const op of [()=>collector.openDatabase(),()=>collector.execute(job.collection_job_id),()=>collector.store.putObject(new Uint8Array([1])),()=>collector.store.find('header')]){try{await op();errors.push(null)}catch(e){errors.push(e.code)}}
   assert.ok(errors.every(x=>x==='LOCAL_STORE_POISONED'));await collector.close();check();console.log(JSON.stringify({ok:true,poison:true,code:error.code,errors}));process.exit(0);
  }
  if(cfg.action==='late'){
   assert.ok(lateResolve,'Actual fixture response must have been entered');const before=summary();lateResolve(delayed);await new Promise(r=>setTimeout(r,40));const after=summary();assert.deepEqual(after,before,'Late response cannot mutate committed state');console.log(JSON.stringify({ok:true,action:'late',result,before,after}));
  }else console.log(JSON.stringify({ok:true,result,summary:summary()}));
  await collector.close();check();
 }
}catch(error){await collector?.close().catch(()=>{});check();console.log(JSON.stringify({ok:false,code:error.code??null,message:error.message}));process.exitCode=2;}
