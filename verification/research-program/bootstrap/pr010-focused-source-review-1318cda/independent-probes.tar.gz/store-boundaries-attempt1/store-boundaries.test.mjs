import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const pins=JSON.parse(await fs.readFile(process.env.USHSO_ROOT_REVIEW_PINS,'utf8'));
const hash=b=>createHash('sha256').update(b).digest('hex');
async function check(){for(const x of pins.files)assert.equal(hash(await fs.readFile(path.join(pins.repo,x.path))),x.sha256,x.path)}
await check();after(check);
const {LocalCollectionStore,encodeLocalValue,decodeLocalValue}=await import(pathToFileURL(path.join(pins.repo,'packages/ingestion/src/local-collection-store.mjs')));
const area=process.env.USHSO_ROOT_REVIEW_AREA;
assert.ok(path.isAbsolute(area)&&area.startsWith('/mnt/d/tmp/plumbob/'));
const defer=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {resolve,promise}};

test('queued object write retains real kernel lock until close drains and late calls stay rejected',async()=>{
 const entered=defer(),release=defer();let objectPending=false;
 const store=await LocalCollectionStore.open(path.join(area,'close-drain'),{pins:{independent_probe:'close_drain'},fault:async(point,detail)=>{if(point==='after_file_sync'&&detail.folder==='objects'){objectPending=true;entered.resolve();await release.promise}}});
 const bytes=new Uint8Array([21,22,23]);const putting=store.putObject(bytes);await entered.promise;assert.ok(objectPending);
 let closed=false;const closing=store.close().then(()=>{closed=true});
 try{
  await new Promise(r=>setTimeout(r,15));assert.equal(closed,false);
  await assert.rejects(LocalCollectionStore.open(path.join(area,'close-drain'),{pins:{independent_probe:'close_drain'}}),e=>e.code==='WRITER_BUSY');
 }finally{release.resolve()}
 const object=await putting;await closing;
 await assert.rejects(store.putObject(new Uint8Array([24])),e=>['LOCAL_STORE_CLOSING','LOCAL_STORE_CLOSED'].includes(e.code));
 const next=await LocalCollectionStore.open(path.join(area,'close-drain'),{pins:{independent_probe:'close_drain'}});
 try{assert.deepEqual(new Uint8Array(await next.getObject(object.sha256)),bytes)}finally{await next.close()}
});

test('concurrent distinct object writes cannot exceed aggregate bound; same bytes are charged once',async()=>{
 const state=path.join(area,'aggregate');const store=await LocalCollectionStore.open(state,{pins:{independent_probe:'aggregate'}});
 try{
  const size=262144;const values=Array.from({length:33},(_,i)=>new Uint8Array(size).fill(i));
  const outcomes=await Promise.allSettled(values.map(x=>store.putObject(x)));
  assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,32);const rejected=outcomes.filter(x=>x.status==='rejected');assert.equal(rejected.length,1);assert.equal(rejected[0].reason.code,'OBJECT_TOTAL_BOUND_EXCEEDED');
  assert.equal(store.objectBytes,8388608);
  const duplicates=await Promise.all(Array.from({length:4},()=>store.putObject(values[0])));assert.ok(duplicates.every(x=>x.sha256===hash(values[0])));assert.equal(store.objectBytes,8388608);
  const names=(await fs.readdir(path.join(state,'objects'))).filter(x=>!x.startsWith('.pending-'));assert.equal(names.length,32);
  let total=0;for(const name of names){const bytes=await fs.readFile(path.join(state,'objects',name));assert.equal(hash(bytes),name);total+=bytes.length}assert.equal(total,8388608);
 }finally{await store.close()}
 const reopened=await LocalCollectionStore.open(state,{pins:{independent_probe:'aggregate'}});assert.equal(reopened.objectBytes,8388608);await reopened.close();
});

test('tagged codec preserves ordered Maps, undefined positions and bytes independently',async()=>{
 const bytes=new Uint8Array([4,5]);const input={array:[undefined,null],map:new Map([['second',undefined],['first',bytes]])};const objects=new Map();
 const encoded=await encodeLocalValue(input,async b=>{objects.set(hash(b),new Uint8Array(b));return {sha256:hash(b),byte_length:b.length}});
 assert.deepEqual(encoded,{t:'object',v:[['array',{t:'array',v:[{t:'undefined'},{t:'null'}]}],['map',{t:'map',v:[[{t:'string',v:'second'},{t:'undefined'}],[{t:'string',v:'first'},{t:'bytes_ref',sha256:hash(bytes),byte_length:2}]]}]]});
 const decoded=await decodeLocalValue(encoded,async h=>objects.get(h));assert.deepEqual(decoded,input);assert.ok(decoded.map instanceof Map);assert.deepEqual([...decoded.map.keys()],['second','first']);assert.ok(Object.hasOwn(decoded.array,0));
});

test('unsupported accessors/subclasses and malformed replay values reject before reconstruction effects',async()=>{
 let touched=0;const getter=Object.defineProperty({},'value',{enumerable:true,get(){touched++;return 1}});const setter=Object.defineProperty({},'value',{enumerable:true,set(){touched++}});
 class ArrayChild extends Array{};class MapChild extends Map{};
 for(const input of [getter,setter,new ArrayChild(1),new MapChild(),[,,],Infinity,{value:NaN}])await assert.rejects(encodeLocalValue(input));assert.equal(touched,0);
 for(const encoded of [{t:'unknown',v:[]},{t:'number',v:Infinity},{t:'string',v:'x'.repeat(100001)},{t:'map',v:[[{t:'string',v:'x'},{t:'null'}],[{t:'string',v:'x'},{t:'null'}]]},{t:'object',v:[['z',{t:'null'}],['a',{t:'null'}]]}])await assert.rejects(decodeLocalValue(encoded,()=>{throw new Error('Unexpected bytes read')}));
 await assert.rejects(decodeLocalValue({t:'bytes_ref',sha256:'a'.repeat(64),byte_length:2},async()=>new Uint8Array(1)),e=>e.code==='BYTES_REFERENCE_SIZE');
});
