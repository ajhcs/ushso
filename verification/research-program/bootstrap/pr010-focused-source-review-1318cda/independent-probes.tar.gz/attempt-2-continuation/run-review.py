from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,shutil
R=Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr010-root-durability-review')
REPO=Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr010-local-jobs-20260912')
HEAD='1318cda5c76cd3262c7668fb7f56fab842876c6f';OUT=R/'attempt-2-continuation';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,j):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=REPO)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
roots=['packages/connectors','packages/ingestion/src','contracts/ingestion/v1.0.0','contracts/ingestion/v1.1.0','packages/retrieval/tools','scripts/research/refresh.mjs','scripts/research-program/operating-bounds.mjs','scripts/research-program/policy.json','scripts/research-program/receipts/v1.0.0','package-lock.json']
paths=git('ls-tree','-r','--name-only',HEAD,'--',*roots).decode().splitlines();pins=[]
for rel in paths:
 b=git('show',HEAD+':'+rel);assert (REPO/rel).read_bytes()==b,rel;pins.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
save(OUT/'pins.json',{'repo':str(REPO),'source_head':HEAD,'source_tree':git('rev-parse',HEAD+'^{tree}').decode().strip(),'files':pins})
shutil.copyfile(R/'driver.mjs',OUT/'driver.mjs');shutil.copyfile(Path(__file__),OUT/'run-review.py')
env=os.environ.copy();env['USHSO_ROOT_REVIEW_PINS']=str(OUT/'pins.json')
results=[];commands=[]
def invoke(name,cfg,expect=0):
 d=OUT/name;d.mkdir(parents=True,exist_ok=True);cfg.setdefault('state',str(d/'state'));cfg.setdefault('observer',str(d/'deliveries.jsonl'));cfg.setdefault('events',str(d/'events.jsonl'));cmd=['/home/plumbob/bin/with-dev-storage','node',str(OUT/'driver.mjs'),json.dumps(cfg,separators=(',',':'))]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();c=subprocess.run(cmd,env=env,cwd=REPO,capture_output=True,timeout=30);i=sum(x['name']==name for x in commands)+1;(d/f'command-{i}.stdout.log').write_bytes(c.stdout);(d/f'command-{i}.stderr.log').write_bytes(c.stderr)
 rec={'name':name,'started_at':started,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'exit_code':c.returncode,'expected_exit_code':expect,'stdout_sha256':sha(c.stdout),'stderr_sha256':sha(c.stderr)};commands.append(rec);save(OUT/'commands.json',commands)
 assert c.returncode==expect,(name,c.returncode,c.stdout.decode()[-1500:],c.stderr.decode()[-1000:])
 if expect<0:return cfg,None
 lines=[x for x in c.stdout.decode().splitlines() if x.startswith('{')];assert len(lines)==1,(name,c.stdout.decode());return cfg,json.loads(lines[0])
def deliveries(cfg):
 p=Path(cfg['observer']);return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
def journal(state):
 p=Path(state);rows=[];previous=None
 def decode(x):
  t=x['t']
  if t=='null':return None
  if t=='undefined':return {'__independent_undefined__':True}
  if t in ['number','string','boolean']:return x['v']
  if t=='array':return [decode(v) for v in x['v']]
  if t=='map':return {'__independent_map__':[[decode(k),decode(v)] for k,v in x['v']]}
  if t=='object':return {k:decode(v) for k,v in x['v']}
  if t=='bytes_ref':
   b=(p/'objects'/x['sha256']).read_bytes();assert sha(b)==x['sha256'] and len(b)==x['byte_length'];return {'__independent_bytes_ref__':x['sha256'],'bytes':len(b)}
  raise AssertionError(t)
 names=sorted(x for x in (p/'journal').iterdir() if not x.name.startswith('.pending-'))
 for i,f in enumerate(names,1):
  b=f.read_bytes();x=json.loads(b);assert f.name==f'{i:08d}.json' and x['sequence']==i and x['previous_record_sha256']==previous and canonical(x)==b;assert sha(canonical(x['result']))==x['result_digest'];previous=sha(b);rows.append({'raw':x,'sha256':previous,'kind':x['kind'],'id':x['operation_id'],'payload':decode(x['payload']),'result':decode(x['result'])})
 for f in (p/'objects').iterdir():
  if f.name.startswith('.pending-'):continue
  assert f.is_file() and sha(f.read_bytes())==f.name
 return rows
def business(rows):return [(r['id'],r['sha256']) for r in rows if r['kind']!='replay_session']
def finish_case(name,detail):results.append({'name':name,'status':'PASS',**detail});save(OUT/'results.json',results)
try:
 old=R/'attempt-1'/'complete';new=OUT/'complete';new.mkdir();shutil.copytree(old/'state',new/'state');shutil.copyfile(old/'deliveries.jsonl',new/'deliveries.jsonl')
 cfg={'action':'run','state':str(new/'state'),'observer':str(new/'deliveries.jsonl'),'events':str(new/'events.jsonl')}
 res=json.loads((old/'command-1.stdout.log').read_text().strip())
 save(OUT/'continuation.json',{'prior_attempt':str(R/'attempt-1'),'prior_passed_groups':14,'prior_real_SIGKILLs':13,'retained_failure':'Root supplied invalid root_reuse_reservation instead of required reservation_ prefix; actual admission correctly blocked it.','correction':'Use reservation_root_reuse for positive304control only.','original_state_and_artifacts_preserved':True,'source_changed':False})
 # Actual prior child evidence reused with304 without a new public capture object/reference.
 prior=res['result']['collection_job_id'];before=journal(cfg['state']);oldrefs={r['id']:r['sha256'] for r in before if r['kind']=='capture_reference'}
 _,reuse=invoke('complete',{**cfg,'action':'run','reuse':True,'priorChild':prior,'selection':['fixture-record-a'],'reservation':'reservation_root_reuse'});assert reuse['result']['status']=='complete_fixture';after=journal(cfg['state']);assert {r['id']:r['sha256'] for r in after if r['kind']=='capture_reference'}==oldrefs
 fresh=[r for r in after if r['kind']=='wrapper_outcome' and r['payload']['child_id']==reuse['result']['collection_job_id']];assert len(fresh)==2 and all(r['result']['legacy']['http_status']==304 and r['result']['legacy']['bytes']==0 and r['result']['strict']['outcome']=='not_modified' for r in fresh);assert reuse['summary']['parents']==reuse['summary']['outbox']==1 and len(reuse['summary']['children'])==2
 finish_case('cross_child_verified_304_reuse',{'new_capture_references':0,'body_bytes':0,'reused_pages':2,'shared_parent_separate_children':True})
 # Actual source transaction throws after the existing reducer mutates its transactional draft.
 cfgp,tx=invoke('transaction_poison',{'action':'transaction-poison'});assert tx['ok'] and tx['observedLease']==1;prefix=journal(cfgp['state']);assert not any(r['kind']=='scheduler_transaction' and r['payload'].get('calls',[{}])[0].get('args',[{}])[0].get('scheduledSlot')=='2026-09-14T00:00:00.000Z' for r in prefix)
 _,recovered=invoke('transaction_poison',{**cfgp,'action':'run'});assert recovered['result']['status']=='complete_fixture' and len(deliveries(cfgp))==2
 finish_case('actual_transaction_abort_and_shared_poison',{'blocked_old_new_operations':7,'fresh_process_complete':True})
 # A durable-write failure after a reducer mutation poisons old composition; verified prefix is recoverable.
 cfgp,poison=invoke('persistence_poison',{'action':'run','throwFault':True,'crash':{'point':'after_record_commit','kind':'scheduler_transaction','label':'scheduler-source'}});assert poison['ok'] and poison['poison'];assert len(deliveries(cfgp))==0;cfgp.pop('throwFault');cfgp.pop('crash');_,recovered=invoke('persistence_poison',cfgp);assert recovered['result']['status']=='complete_fixture' and len(deliveries(cfgp))==2
 finish_case('persisted_transaction_ambiguous_ack_poison',{'blocked_operations':4,'fresh_process_parent_reused':True})
 cfgl,late=invoke('late_response',{'action':'late','timeout':100});assert late['ok'] and late['result']['status']=='typed_failure' and len(deliveries(cfgl))==1;rows=journal(cfgl['state']);assert not any(r['kind']=='capture_reference' or (r['kind']=='connector_operation' and r['payload']['method']=='commitPage') for r in rows);assert sum(r['kind']=='request_intent' for r in rows)==1
 finish_case('actual_deadline_no_late_promotion',{'deliveries':1,'late_capture_and_page_mutations':0,'terminal':'typed_failure'})
except BaseException as e:
 save(OUT/'failure.json',{'type':type(e).__name__,'message':str(e),'completed_groups':len(results)});raise
finally:
 unchanged=all(sha((REPO/p['path']).read_bytes())==p['sha256'] for p in pins)
 save(OUT/'summary.json',{'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':HEAD,'source_tree':git('rev-parse',HEAD+'^{tree}').decode().strip(),'source_files_pinned':len(pins),'source_unchanged':unchanged,'driver_sha256':sha((OUT/'driver.mjs').read_bytes()),'orchestrator_sha256':sha((OUT/'run-review.py').read_bytes()),'completed_groups':len(results),'failure':(OUT/'failure.json').exists(),'real_SIGKILL_commands':sum(c['exit_code']==-9 for c in commands),'commands':len(commands),'live_network':False,'build_or_gate':False,'final_acceptance':False})
print(json.dumps(json.loads((OUT/'summary.json').read_bytes())))
