from pathlib import Path
import os,json,subprocess,hashlib,datetime,shutil,selectors
R=Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr010-root-durability-review');O=R/'supplement-attempt2-continuation';O.mkdir(exist_ok=False)
pins=json.loads((R/'attempt-2-continuation/pins.json').read_bytes());repo=Path(pins['repo']);env=os.environ.copy();env['USHSO_ROOT_REVIEW_PINS']=str(R/'attempt-2-continuation/pins.json')
shutil.copyfile(R/'driver-sibling.mjs',O/'driver.mjs');shutil.copyfile(Path(__file__),O/'supplement-review.py')
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
results=[];commands=[]
def invoke(name,cfg=None,expect=0,args=None):
 d=O/name;d.mkdir(exist_ok=True)
 if args is None:
  cfg.setdefault('state',str(d/'state'));cfg.setdefault('observer',str(d/'deliveries.jsonl'));cfg.setdefault('events',str(d/'events.jsonl'));args=['node',str(O/'driver.mjs'),json.dumps(cfg,separators=(',',':'))]
 c=subprocess.run(args,cwd=repo,env=env,capture_output=True,timeout=30);n=len(commands)+1;(d/f'{n}.stdout.log').write_bytes(c.stdout);(d/f'{n}.stderr.log').write_bytes(c.stderr)
 commands.append({'name':name,'argv':args,'exit_code':c.returncode,'expected':expect,'stdout_sha256':sha(c.stdout),'stderr_sha256':sha(c.stderr)});save(O/'commands.json',commands)
 assert c.returncode==expect,(name,c.returncode,c.stdout.decode(),c.stderr.decode());lines=[x for x in c.stdout.decode().splitlines() if x.startswith('{')];assert len(lines)==1,(name,lines);return cfg,json.loads(lines[0])
def snapshot(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
def copied(name):
 d=O/name;d.mkdir();shutil.copytree(R/'attempt-1/complete/state',d/'state');return {'action':'run','state':str(d/'state'),'observer':str(d/'deliveries.jsonl'),'events':str(d/'events.jsonl')}
def prop(x,key):assert x['t']=='object';return next(v for k,v in x['v'] if k==key)
def rows(p):return [(f,json.loads(f.read_bytes())) for f in sorted((Path(p)/'journal').glob('*.json'))]
def chain(p,rs):
 previous=None
 for f,x in rs:
  x['previous_record_sha256']=previous;x['result_digest']=sha(canonical(x['result']));b=canonical(x);f.write_bytes(b);previous=sha(b)
 # Independent recomputation of every retained sequence, result digest and hash link.
 previous=None
 for i,(f,x) in enumerate(rows(p),1):
  b=f.read_bytes();assert x['sequence']==i and f.name==f'{i:08d}.json' and x['previous_record_sha256']==previous and sha(canonical(x['result']))==x['result_digest'];previous=sha(b)
def passed(name,**detail):results.append({'name':name,'status':'PASS',**detail});save(O/'results.json',results)
try:
 save(O/'continuation.json',{'prior_attempt':'supplement-attempt1','prior_passed_groups':6,'retained_fixture_failure':'Root requested fixture-record-missing, correctly blocked by approved selection admission.','correction':'Use approved fixture-record-a selection with a bounded one-request reservation to force a real separate-child execution failure.'})
 # A new independently failing selection keeps the previously completed sibling immutable.
 cfg=copied('sibling-failure');before={f.name:sha(f.read_bytes()) for f,x in rows(cfg['state'])};_,bad=invoke('sibling-failure',{**cfg,'selection':['fixture-record-a'],'reservation':'reservation_root_exhausted','maximumRequests':1});assert bad['result']['status']=='typed_failure';assert bad['summary']['parents']==1 and len(bad['summary']['children'])==2;assert all(sha((Path(cfg['state'])/'journal'/name).read_bytes())==digest for name,digest in before.items());assert sorted(x['status'] for x in bad['summary']['statuses'])==['complete_fixture','typed_failure'];passed('failed_sibling_does_not_promote_or_mutate_completed_child',same_parent=True,separate_children=2)
 cli=['node',str(repo/'packages/ingestion/src/local-job-cli.mjs')]
 d=O/'cli';d.mkdir();_,preview=invoke('cli',args=cli+['preview']);assert preview['publication_authorized']==False
 cfg=copied('cli-status');before=snapshot(Path(cfg['state']));_,status=invoke('cli',args=cli+['status','--state-dir',cfg['state']]);assert status['status']=='complete_fixture' and status['publication_authorized']==False and status['production_composition']==False;assert snapshot(Path(cfg['state']))==before
 _,blocked=invoke('cli',args=cli+['preview','--state-dir',str(d/'forbidden')],expect=2);assert not (d/'forbidden').exists();passed('actual_cli_preview_and_readonly_status',status_no_state_writes=True,preview_state_override_rejected=True)
except BaseException as e:
 save(O/'failure.json',{'type':type(e).__name__,'message':str(e),'completed_groups':len(results)});raise
finally:
 receipt={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':pins['source_head'],'source_tree':pins['source_tree'],'source_pins':len(pins['files']),'source_unchanged':all(sha((repo/x['path']).read_bytes())==x['sha256'] for x in pins['files']),'harness_sha256':sha((O/'supplement-review.py').read_bytes()),'driver_sha256':sha((O/'driver.mjs').read_bytes()),'completed_groups':len(results),'commands':len(commands),'failure':(O/'failure.json').exists(),'live_network':False,'build_or_gate':False,'final_acceptance':False};save(O/'summary.json',receipt);print(json.dumps(receipt))
