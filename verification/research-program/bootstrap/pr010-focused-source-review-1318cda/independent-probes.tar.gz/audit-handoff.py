from pathlib import Path
import json,hashlib,subprocess,datetime,re
R=Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr010-local-jobs-20260912');O=Path('/mnt/d/tmp/plumbob/ushso-epic-execution-20260912/pr010-root-durability-review/handoff-audit');O.mkdir(exist_ok=False)
H='1318cda5c76cd3262c7668fb7f56fab842876c6f';P='1e5342f4b0671c2e67f22bcf202bbb2c33b8ee0f';B='50a844d218600f95c13e64c2db64ab4d8562ae0d';E='verification/research-program/pr-010/producer-20260912/'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=R)
def obj(rev,path):return git('show',rev+':'+path)
def read(path):return json.loads(obj(P,path))
checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)});assert ok,name
def verify(item):
 b=obj(P,item['path']);check('artifact '+item['path'],sha(b)==item['sha256'] and len(b)==item['bytes'] and (R/item['path']).read_bytes()==b);return b
check('transport HEAD exact',git('rev-parse','HEAD').decode().strip()==P);check('clean worktree',not git('status','--porcelain=v1'));check('transport parent source',git('rev-parse',P+'^').decode().strip()==H)
h=read('docs/research-program/handoffs/PR-010.json');s=read(E+'source-identity.json');idx=read(E+'index.json');g=read(E+'behavioral-groups.json');runtime=read(E+'runtime-pins.json')
check('handoff source',h['head_sha']==s['source_head_sha']==idx['source_head_sha']==g['source_head_sha']==H);check('source tree',s['source_tree_sha']==idx['source_tree_sha']==git('rev-parse',H+'^{tree}').decode().strip());check('dependency merge',h['dependency_merge_shas']=={'PR-009':'80996a8d3c00792d8abb8946a67a69e0400f621a'})
check('source identities count',len(s['source_pins'])==85==len(h['source_identities']));check('runtime identities count',len(runtime['source_pins'])==80)
for pin in s['source_pins']:
 b=obj(H,pin['path']);check('source pin '+pin['path'],sha(b)==pin['sha256'] and obj(P,pin['path'])==b and (R/pin['path']).read_bytes()==b)
check('handoff source pins exact',sorted((x['id'],x['sha256']) for x in h['source_identities'])==sorted((x['path'],x['sha256']) for x in s['source_pins']));check('runtime pins subset',set((x['path'],x['sha256']) for x in runtime['source_pins'])<=set((x['path'],x['sha256']) for x in s['source_pins']))
for x in s['protected_objects']:
 a=git('rev-parse',B+':'+x['path']).decode().strip();b=git('rev-parse',H+':'+x['path']).decode().strip();check('protected '+x['path'],a==b==x['base_git_object']==x['source_git_object'] and x['unchanged'])
for x in idx['artifacts']+idx['command_events']:verify(x)
for x in h['artifacts']:verify(x)
evidence_paths=set(git('ls-tree','-r','--name-only',P,'--',E).decode().splitlines());indexed=set(x['path'] for x in idx['artifacts']+idx['command_events'])|{E+'index.json'};check('complete evidence index',evidence_paths==indexed)
transport_paths=set(git('diff','--name-only',H,P).decode().splitlines());check('evidence-only transport',transport_paths==evidence_paths|{'docs/research-program/handoffs/PR-010.json'})
logs={}
for c in h['commands']:
 event=json.loads(verify(c['event_source']));check('event identity '+c['id'],event['head_sha']==H and event['tree_sha']==s['source_tree_sha'] and event['exit_code']==0 and event['worktree_clean_before_and_after']);out=verify(event['stdout']).decode();err=verify(event['stderr']);check('clean stderr '+c['id'],err==b'');logs[c['id']]=out
 if 'counts' in event:
  counts=event['counts'];check('passing terminal '+c['id'],counts['tests']==counts['pass'] and counts['fail']==counts['cancelled']==counts['skipped']==0 and 'ℹ fail 0' in out and 'ℹ todo 0' in out)
check('all behavioral groups mapped',len(g['groups'])==g['planned_groups']==g['producer_checked_groups']==36 and g['independently_accepted_groups']==0 and len(set(x['id'] for x in g['groups']))==36)
for group in g['groups']:
 check('group '+group['id'],bool(group['observed_tests']) and all(('✔ '+x['test']+' (') in logs[x['command_id']] for x in group['observed_tests']))
check('exact behavior scope count',len(s['source_files'])==12);plan=read('docs/master-plan/2026-09-10/plan.json');row=next(x for x in plan['prs'] if x['id']=='PR-010');(O/'plan-row.json').write_text(json.dumps(row,indent=2)+'\n')
result={'format':'ushso.pr010.root-handoff-audit.v1','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':H,'source_tree':s['source_tree_sha'],'transport_head':P,'transport_tree':git('rev-parse',P+'^{tree}').decode().strip(),'handoff_sha256':sha(obj(P,'docs/research-program/handoffs/PR-010.json')),'index_sha256':sha(obj(P,E+'index.json')),'checks':len(checks),'passed':all(x['passed'] for x in checks),'behavioral_groups':36,'source_pins':85,'runtime_pins':80,'evidence_files':len(evidence_paths),'qualification':'Evidence integrity and producer coverage only; root behavioral probes and controller conditions are separate.'};(O/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(O/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');(O/'audit-handoff.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(result))
