import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const [repository, destination] = process.argv.slice(2);
assert(repository && destination, 'Usage: node browser.mjs ABS_REVIEW_WORKTREE ABS_NEW_OUTPUT');
const root = path.resolve(repository), out = path.resolve(destination);
const source = path.dirname(new URL(import.meta.url).pathname);
const port = Number(process.env.USHSO_PR006_BROWSER_PORT ?? 18886);
const debugPort = Number(process.env.USHSO_PR006_CHROME_PORT ?? 9236);
assert(port !== debugPort && port >= 1024 && debugPort >= 1024);
await fs.mkdir(out, { recursive: false });
const listeners = execFileSync('ss', ['-tlnp'], { encoding: 'utf8' });
await fs.writeFile(path.join(out, 'listeners-before.txt'), listeners);
for (const p of [port, debugPort]) assert(!listeners.split('\n').some(line => new RegExp(`:${p}\\s`).test(line)), `Port ${p} already in use`);
const head = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
assert(!execFileSync('git', ['-C', root, 'status', '--porcelain'], { encoding: 'utf8' }).trim());
const esbuild = createRequire(path.join(root, 'package.json'))('esbuild');
const entry = await fs.readFile(path.join(source, 'pr006-controller-browser-entry.tsx'), 'utf8');
await esbuild.build({ stdin: { contents: entry, loader: 'tsx', sourcefile: 'controller-browser-entry.tsx', resolveDir: root }, bundle: true, platform: 'browser', format: 'esm', target: 'es2022', jsx: 'automatic', define: { 'import.meta.env': '{}', 'process.env.NODE_ENV': '"production"' }, outfile: path.join(out, 'browser.js'), loader: { '.woff': 'file', '.woff2': 'file' }, logLevel: 'silent' });
const { createRetrievalEngine } = await import(pathToFileURL(path.join(root, 'packages/retrieval/tools/retrieval-core-v1.2.mjs')));
const input = JSON.parse(await fs.readFile(path.join(root, 'tests/fixtures/direct-base-input.json')));
const now = '2026-09-11T00:00:00.000Z';
const rows = Array.from({ length: 4 }, (_, i) => {
  const r = structuredClone(input.record);
  r.record_id = `fixture:pr006:browser:${i}`;
  r.identity.asset.asset_id = r.record_id;
  r.identity.asset.name = r.title = `${['Alpha', 'Beta', 'Gamma', 'Omega'][i]} registry`;
  r.description = 'Synthetic registry metadata for controller browser interaction checks.';
  r.identity.source = { source_id: i % 2 ? 'controller-source-b' : 'controller-source-a', name: i % 2 ? 'Registry Beta' : 'Registry Alpha' };
  r.geography.coverage_level = i % 2 ? 'state' : 'unknown';
  r.geography.jurisdictions = i % 2 ? ['pennsylvania'] : [];
  r.access.status = i === 1 ? 'unknown' : 'public_catalog';
  return r;
});
const uniform = structuredClone(rows).map(r => { r.geography.coverage_level = 'unknown'; r.geography.jurisdictions = []; r.access.status = 'public_catalog'; return r; });
function make(records) { return createRetrievalEngine({ records, searchDocuments: null, vocabulary: input.vocabulary, joinRoutes: [], namedSourceRegistry: { sources: [] }, corpus: { corpus_id: 'controller-browser-fixture', corpus_version: 'test', generation: 'controller-browser-generation', published_at: now } }); }
const engines = { mixed: make(rows), uniform: make(uniform) };
const requests = [];
const json = (res, code, body) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(body)); };
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, `http://127.0.0.1:${port}`);
    if (u.pathname === '/') { res.writeHead(200, { 'content-type': 'text/html' }); res.end('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/browser.css"></head><body><div id="root"></div><script type="module" src="/browser.js"></script></body></html>'); return; }
    if (['/browser.js', '/browser.css'].includes(u.pathname)) { res.writeHead(200, { 'content-type': u.pathname.endsWith('.js') ? 'text/javascript' : 'text/css' }); res.end(await fs.readFile(path.join(out, u.pathname.slice(1)))); return; }
    const fixture = u.pathname.match(/^\/fixture\/(mixed|uniform)\.json$/);
    if (fixture) { json(res, 200, engines[fixture[1]].retrieve({ question: 'registry', page_size: 100 }, { now })); return; }
    const api = u.pathname.match(/^\/api\/(mixed|uniform)\/(discover|catalog)$/);
    if (api) {
      let query = {};
      if (req.method === 'POST') { let body = ''; for await (const chunk of req) { body += chunk; assert(body.length < 10000); } query = JSON.parse(body); }
      else {
        const grouped = {};
        for (const token of u.searchParams.getAll('filter')) { const separator = token.indexOf(':'); assert(separator > 0); const key = token.slice(0, separator); (grouped[key] ??= []).push(token.slice(separator + 1)); }
        query = { ...(u.searchParams.has('page_size') ? { page_size: Number(u.searchParams.get('page_size')) } : {}), ...(u.searchParams.has('cursor') ? { cursor: u.searchParams.get('cursor') } : {}), ...(u.searchParams.has('sort') ? { sort: u.searchParams.get('sort') } : {}), facet_filters: grouped };
      }
      requests.push({ method: req.method, path: u.pathname, query });
      json(res, 200, api[2] === 'catalog' ? engines[api[1]].browse(query, { now }) : engines[api[1]].retrieve(query, { now })); return;
    }
    json(res, 404, { error: 'local_controller_fixture_not_available' });
  } catch (error) { json(res, 500, { error: error.message }); }
});
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve); });
const profile = path.join(out, 'chrome-profile');
const chrome = spawn('/usr/bin/google-chrome', ['--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-background-networking', '--no-first-run', '--no-default-browser-check', `--remote-debugging-port=${debugPort}`, '--remote-debugging-address=127.0.0.1', `--user-data-dir=${profile}`, 'about:blank'], { detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
let chromeLog = '';
for (const stream of [chrome.stdout, chrome.stderr]) stream.on('data', b => { chromeLog += b; });
async function poll(url, init) { for (let i = 0; i < 150; i++) { assert(chrome.exitCode === null, `Chrome exited ${chrome.exitCode}`); try { const r = await fetch(url, init); if (r.ok) return r.json(); } catch {} await new Promise(resolve => setTimeout(resolve, 100)); } throw new Error('CHROME_NOT_READY'); }
const cases = [];
async function page(mode, scenario, route, action) {
  const target = await poll(`http://127.0.0.1:${debugPort}/json/new`, { method: 'PUT' });
  const socket = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
  let sequence = 0; const pending = new Map(); const errors = [];
  socket.onmessage = event => { const m = JSON.parse(event.data); if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails); if (pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result); } };
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++sequence; pending.set(id, { resolve, reject }); socket.send(JSON.stringify({ id, method, params })); });
  const evaluate = async expression => { const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }); if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description ?? r.exceptionDetails.text); return r.result.value; };
  const wait = async expression => { for (let i = 0; i < 200; i++) { if (await evaluate('Boolean(' + expression + ')')) return; await new Promise(resolve => setTimeout(resolve, 100)); } throw new Error(`BROWSER_CONDITION: ${expression}`); };
  try {
    await send('Page.enable'); await send('Runtime.enable');
    await send('Emulation.setDeviceMetricsOverride', { width: 1280, height: 900, deviceScaleFactor: 1, mobile: false });
    await send('Page.navigate', { url: `http://127.0.0.1:${port}/?${new URLSearchParams({ provider: mode, scenario, route })}` });
    await wait('window.__ushsoControllerAudit?.responses.length > 0 && document.querySelector("[aria-busy=false]")');
    await action({ send, evaluate, wait });
    assert.deepEqual(errors, []);
    const routeId = createHash('sha256').update(route).digest('hex').slice(0, 12);
    await fs.writeFile(path.join(out, `${mode}-${scenario}-${routeId}.json`), JSON.stringify(await evaluate('({audit:window.__ushsoControllerAudit,html:document.body.innerHTML,text:document.body.innerText})'), null, 2));
  } catch (error) {
    const routeId = createHash('sha256').update(route).digest('hex').slice(0, 12);
    const state = await evaluate('({audit:window.__ushsoControllerAudit,controllerError:window.__ushsoControllerError,html:document.body.innerHTML,text:document.body.innerText})').catch(e => ({ snapshot_error: e.message }));
    await fs.writeFile(path.join(out, `${mode}-${scenario}-${routeId}-failed.json`), JSON.stringify({ error: error.stack, state, runtime_errors: errors }, null, 2));
    throw error;
  } finally { await fetch(`http://127.0.0.1:${debugPort}/json/close/${target.id}`, { method: 'PUT' }).catch(() => {}); socket.close(); }
}
const formState = `(() => [...document.querySelectorAll('.desktop-facets fieldset, .desktop-facets details')].map(s=>({section:s.querySelector('legend,summary')?.textContent,options:[...s.querySelectorAll('label')].filter(l=>l.querySelector('input')).map(l=>{const i=l.querySelector('input');return {label:l.textContent,checked:i.checked,disabled:i.disabled,describedby:i.getAttribute('aria-describedby')}})})))()`;
function clickOption(section, labelPattern) { return `(() => {const s=[...document.querySelectorAll('.desktop-facets fieldset, .desktop-facets details')].find(s=>(s.querySelector('legend,summary')?.textContent??'').includes(${JSON.stringify(section)}));if(!s)throw Error('SECTION_MISSING');if(s.tagName==='DETAILS')s.open=true;const l=[...s.querySelectorAll('label')].find(l=>new RegExp(${JSON.stringify(labelPattern)},'i').test(l.textContent));if(!l)throw Error('OPTION_MISSING');const i=l.querySelector('input');if(i.disabled)throw Error('OPTION_DISABLED');i.click();return true})()`; }
async function check(name, action) { try { await action(); cases.push({ name, passed: true }); } catch (error) { cases.push({ name, passed: false, error: error.stack }); } }
try {
  await poll(`http://127.0.0.1:${debugPort}/json/version`);
  for (const mode of ['api', 'fixture']) {
    await check(`${mode}: known plus unknown filters round-trip and use current counts`, () => page(mode, 'mixed', '/search?q=registry', async p => {
      assert.equal(await p.evaluate('window.__ushsoControllerAudit.responses.at(-1).total_matches'), 4);
      await p.evaluate(clickOption('Geography', 'Pennsylvania'));
      await p.wait('window.__ushsoControllerAudit.responses.at(-1).total_matches === 2 && document.querySelector("[aria-busy=false]")');
      const sections = await p.evaluate(formState);
      const geography = sections.find(s => s.section.includes('Geography'));
      const unknown = geography.options.find(o => /unknown|unresolved/i.test(o.label));
      assert(unknown && !unknown.disabled && !unknown.checked);
      assert(!/\(\s*\d+\s*\)/.test(unknown.label), 'Missing unknown option must have no invented numeric count');
      await p.evaluate(clickOption('Geography', 'unknown|unresolved'));
      await p.wait('window.__ushsoControllerAudit.responses.at(-1).total_matches === 4 && document.querySelector("[aria-busy=false]")');
      const audit = await p.evaluate('window.__ushsoControllerAudit');
      assert(audit.requests.at(-1).traversal.filters.includes('geography:pennsylvania'));
      assert(audit.requests.at(-1).traversal.filters.includes('geography:unknown'));
      assert.equal((await p.evaluate(formState)).find(s => s.section.includes('Geography')).options.filter(o => o.checked).length, 2);
    }));
    await check(`${mode}: selected absent filters remain removable after a zero result`, () => page(mode, 'mixed', '/search?q=registry&filter=source:controller-source-a&filter=geography:pennsylvania', async p => {
      assert.equal(await p.evaluate('window.__ushsoControllerAudit.responses.at(-1).total_matches'), 0);
      const selected = (await p.evaluate(formState)).flatMap(s => s.options).filter(o => o.checked);
      assert.equal(selected.length, 2);
      assert(selected.every(o => !o.disabled));
      await p.evaluate(clickOption('Geography', 'Pennsylvania'));
      await p.wait('window.__ushsoControllerAudit.responses.at(-1).total_matches === 2 && document.querySelector("[aria-busy=false]")');
      const audit = await p.evaluate('window.__ushsoControllerAudit');
      assert.deepEqual(audit.requests.at(-1).traversal.filters, ['source:controller-source-a']);
    }));
    await check(`${mode}: uniform missing coverage and catalog access have described reasons`, () => page(mode, 'uniform', '/search?q=registry', async p => {
      const state = await p.evaluate(formState);
      const geo = state.find(s => s.section.includes('Geography')).options.find(o => /unknown|unresolved/i.test(o.label));
      const access = state.find(s => /Access/i.test(s.section)).options.find(o => /catalog/i.test(o.label));
      for (const option of [geo, access]) assert(option && option.describedby, 'Unavailable option must expose a described reason');
      const descriptions = await p.evaluate(`(${JSON.stringify([geo.describedby, access.describedby])}).map(ids=>ids.split(/\\s+/).map(id=>document.getElementById(id)?.textContent??'').join(' '))`);
      assert(descriptions.every(text => text.trim().length > 0));
      assert(/(unresolved|unknown).*geograph|geograph.*(unresolved|unknown)/i.test(descriptions[0]));
      assert(/(cannot|no).*narrow|unavailable/i.test(descriptions[0]));
      assert(/catalog/i.test(descriptions[1]) && /payload.*(unknown|unresolved)/i.test(descriptions[1]));
      const screenshot = await p.send('Page.captureScreenshot', { format: 'png' });
      await fs.writeFile(path.join(out, `${mode}-uniform.png`), Buffer.from(screenshot.data, 'base64'));
    }));
  }
} finally {
  try { process.kill(-chrome.pid, 'SIGTERM'); } catch (e) { if (e.code !== 'ESRCH') throw e; }
  for (let i = 0; chrome.exitCode === null && i < 50; i++) await new Promise(resolve => setTimeout(resolve, 100));
  if (chrome.exitCode === null) { try { process.kill(-chrome.pid, 'SIGKILL'); } catch (e) { if (e.code !== 'ESRCH') throw e; } }
  for (let i = 0; chrome.exitCode === null && chrome.signalCode === null && i < 50; i++) await new Promise(resolve => setTimeout(resolve, 100));
  await new Promise(resolve => server.close(resolve));
  await fs.writeFile(path.join(out, 'chrome.log'), chromeLog);
  if (chrome.exitCode !== null || chrome.signalCode !== null) await fs.rm(profile, { recursive: true, force: true });
}
const report = { format: 'ushso.pr006-controller-browser.v1', head, fixture_scope: 'Synthetic offline records rendered by actual candidate React pages and real API/fixture providers. Local API calls use the actual retrieval engine. No participant, publisher access or production claim.', cases, requests, passed: cases.filter(c => c.passed).length, failed: cases.filter(c => !c.passed).length, script_sha256: createHash('sha256').update(await fs.readFile(new URL(import.meta.url))).digest('hex') };
await fs.writeFile(path.join(out, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ head, cases, receipt: path.join(out, 'receipt.json') }));
process.exitCode = report.failed ? 1 : 0;
