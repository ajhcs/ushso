// Controller-authored independent cases. All changed rows below are synthetic
// local fixtures; their names and counts are not publisher observations.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const root = path.resolve(process.argv[2] ?? process.cwd());
const base = 'c58787297fc543b3fdd31736e1c96ed1af29ffd8';
const toolsPath = pathToFileURL(path.join(root, 'packages/retrieval/tools/'));
const candidate = await import(new URL('retrieval-core-v1.2.mjs', toolsPath));
const originalBytes = execFileSync('git', ['-C', root, 'show', `${base}:packages/retrieval/tools/retrieval-core-v1.2.mjs`]);
const originalSource = originalBytes.toString().replace(/from '(\.\/[^']+)'/g, (_, rel) => `from '${new URL(rel, toolsPath).href}'`);
const control = await import(`data:text/javascript;base64,${Buffer.from(originalSource).toString('base64')}`);
const fixtureBytes = await readFile(path.join(root, 'tests/fixtures/direct-base-input.json'));
const fixture = JSON.parse(fixtureBytes);
const now = '2026-09-11T00:00:00.000Z';
const rows = [];
const specs = [
  ['Alpha registry', 'source:opaque-A', 'Registry One', 'unknown', [], 'public_catalog', 'cap:literal/A~01', 'Care episodes'],
  ['Beta registry', 'source:opaque-B', 'Registry Two — documented labels', 'state', ['pennsylvania'], 'unknown', 'cap:literal/B', 'Épisodes de soins'],
  ['Gamma registry', 'source:opaque-C', 'Registry 三', 'unknown', [], 'public_catalog', 'cap:literal/C', 'Observed discharge labels'],
  ['Omega registry', 'source:opaque-B', 'Registry Two — documented labels', 'state', ['pennsylvania'], 'public_catalog', 'cap:literal/B', 'Épisodes de soins'],
];
for (const [i, [title, sourceId, sourceName, coverage, jurisdictions, access, capabilityId, label]] of specs.entries()) {
  const record = structuredClone(fixture.record);
  record.record_id = `fixture:pr006:controller:${i}`;
  record.identity.asset.asset_id = record.record_id;
  record.identity.asset.name = title;
  record.title = title;
  record.description = 'Synthetic registry fixture for independent facet semantics.';
  record.identity.source = { source_id: sourceId, name: sourceName };
  record.geography.coverage_level = coverage;
  record.geography.jurisdictions = jurisdictions;
  record.access.status = access;
  const capability = { ...record.capabilities.topics[0], id: capabilityId, label };
  record.capabilities = { topics: [capability], use_cases: [structuredClone(capability)] };
  rows.push(record);
}
function engine(module, records = rows, mode = 'on_demand') {
  return module.createRetrievalEngine({
    records, vocabulary: fixture.vocabulary, joinRoutes: [], namedSourceRegistry: { sources: [] },
    corpus: { corpus_id: 'pr006-controller-synthetic', corpus_version: 'test', generation: 'controller-fixed-generation', published_at: now },
    ...(mode === 'on_demand' ? { searchDocuments: null } : {}),
  });
}
function option(response, section, value) {
  return response.facets.sections.find(s => s.id === section)?.options.find(o => o.value === value);
}
function withoutOptionLabels(response) {
  const value = structuredClone(response);
  for (const section of value.facets.sections) for (const item of section.options) item.label = '__only_label_normalized__';
  return value;
}
const cases = [];
function check(name, fn) {
  try { fn(); cases.push({ name, passed: true }); }
  catch (error) { cases.push({ name, passed: false, message: error.message, code: error.code ?? null }); }
}
const e = engine(candidate);
check('synthetic fixtures survive the real record validator', () => {
  const response = e.browse({}, { now });
  assert.equal(response.total_matches, 4);
  assert.equal(response.partial_results.invalid_item_count, 0);
});
check('source labels use complete matches including sources absent from the first page', () => {
  const r = e.browse({ page_size: 1, sort: 'title_asc' }, { now });
  assert.equal(r.results[0].record.identity.source.source_id, 'source:opaque-A');
  assert.equal(option(r, 'source', 'source:opaque-B').label, 'Registry Two — documented labels');
  assert.equal(option(r, 'source', 'source:opaque-B').count, 2);
  assert.equal(option(r, 'source', 'source:opaque-C').label, 'Registry 三');
});
check('capability labels preserve literal Unicode and canonical values outside the page', () => {
  const r = e.browse({ page_size: 1, sort: 'title_asc' }, { now });
  assert.equal(option(r, 'capability', 'cap:literal/B').label, 'Épisodes de soins');
  assert.equal(option(r, 'capability', 'cap:literal/B').value, 'cap:literal/B');
  assert.equal(option(r, 'capability', 'cap:literal/B').count, 2);
  assert.equal(option(r, 'capability', 'cap:literal/A~01').count, 1);
});
check('all pages preserve complete-match facets and exact source/filter record identities', () => {
  let cursor = null;
  let firstFacets;
  const ids = [];
  do {
    const r = e.browse({ page_size: 1, sort: 'title_asc', ...(cursor ? { cursor } : {}) }, { now });
    firstFacets ??= r.facets;
    assert.deepEqual(r.facets, firstFacets);
    ids.push(...r.results.map(item => item.record_id));
    cursor = r.pagination.next_cursor;
  } while (cursor);
  assert.deepEqual(ids, rows.map(r => r.record_id));
  assert.equal(new Set(ids).size, 4);
});
check('same-dimension OR and cross-dimension AND preserve literal values', () => {
  const r = e.browse({ facet_filters: { geography: ['unknown', 'pennsylvania'], source: ['source:opaque-A', 'source:opaque-B'], access_status: ['public_catalog'] } }, { now });
  assert.deepEqual(r.results.map(item => item.record_id), [rows[0].record_id, rows[3].record_id]);
  assert.equal(r.total_matches, 2);
  assert.equal(option(r, 'access_status', 'public_catalog').count, 2);
  const exact = e.browse({ facet_filters: { capability: ['cap:literal/A~01'] } }, { now });
  assert.deepEqual(exact.results.map(item => item.record_id), [rows[0].record_id]);
});
check('missing options have no invented count and unknown geography does not become national', () => {
  const r = e.browse({ facet_filters: { source: ['source:opaque-A'] } }, { now });
  assert.equal(option(r, 'source', 'source:opaque-B'), undefined);
  assert.equal(option(r, 'geography', 'national'), undefined);
  assert.equal(option(r, 'geography', 'unknown').count, 1);
  assert.equal(option(r, 'access_status', 'unknown'), undefined);
});
check('conflicting source names do not select an arbitrary asserted label', () => {
  const conflicting = structuredClone(rows);
  conflicting[3].identity.source.name = 'Different publisher under the same ID';
  const r = engine(candidate, conflicting).browse({}, { now });
  const label = option(r, 'source', 'source:opaque-B').label;
  assert.notEqual(label, 'Registry Two — documented labels');
  assert.notEqual(label, 'Different publisher under the same ID');
});
check('conflicting capability names do not select an arbitrary asserted label', () => {
  const conflicting = structuredClone(rows);
  for (const c of [...conflicting[3].capabilities.topics, ...conflicting[3].capabilities.use_cases]) c.label = 'Different semantic label';
  const r = engine(candidate, conflicting).browse({}, { now });
  const label = option(r, 'capability', 'cap:literal/B').label;
  assert.notEqual(label, 'Épisodes de soins');
  assert.notEqual(label, 'Different semantic label');
});
for (const mode of ['on_demand', 'projected']) check(`every non-label response field equals the dispatch base: ${mode}`, () => {
  const before = engine(control, rows, mode), after = engine(candidate, rows, mode);
  const immutable = JSON.stringify(rows);
  for (const sort of ['canonical_relevance', 'title_asc', 'release_newest', 'observation_latest']) {
    for (const facet_filters of [{}, { geography: ['unknown'] }, { geography: ['unknown', 'pennsylvania'], access_status: ['public_catalog'] }, { source: ['nonexistent'] }, { capability: ['cap:literal/A~01'] }]) {
      let cursor = null;
      do {
        const query = { sort, facet_filters, page_size: 1, ...(cursor ? { cursor } : {}) };
        const a = before.browse(query, { now }), b = after.browse(query, { now });
        assert.deepEqual(withoutOptionLabels(b), withoutOptionLabels(a));
        cursor = a.pagination.next_cursor;
      } while (cursor);
    }
  }
  assert.equal(JSON.stringify(rows), immutable);
});
const report = {
  format: 'ushso.pr006-controller-facet-cases.v1',
  candidate_head: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  control_head: base,
  control_module_sha256: createHash('sha256').update(originalBytes).digest('hex'),
  fixture_sha256: createHash('sha256').update(fixtureBytes).digest('hex'),
  fixture_scope: 'Synthetic variants of the preserved direct-base input; no source/payload/scientific observation.',
  cases, passed: cases.filter(c => c.passed).length, failed: cases.filter(c => !c.passed).length,
};
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.failed ? 1 : 0;
