# PR-009 final scope decision proposal

This is a read-only design decision against the exact integration input
`ca98b0069ae11976316100ab2e8c6193a0337e7f` (tree
`eed6f09df573a79ac1fca7d37a7f5cbd252693d0`) in
`/mnt/d/worktrees/plumbob/ushso-research-program-20260910`. The selected
interface is `gpt-5.6-luna/max`; this records the controller-selected
interface and is not a serving-model self-attestation. The worktree was clean.
The mutable worktree advanced while the parent reviewed PR-008, so the pinned
commit/tree were revalidated directly with `git show`/`rev-parse`; this
proposal remains bound to the exact input above.
No repository files were changed, and no test, network, runtime, service,
credential, store, database, queue, deployment, procurement, or paid-resource
action was performed.

The disposition is to keep PR-009 as three meaningful commits, after PR-008
has an accepted handoff and exact head/merge binding. The coherent boundary is
a successor ADR, an operating policy plus pure policy/receipt composition
validator, and a standalone additive receipt schema with its research-program
test. Existing connector and ingestion exports are read-only dependencies.
Durable persistence belongs to PR-010/PR-011. No `packages/connectors/`,
`packages/ingestion/`, released ingestion schema, or WP5 v1.0.0 file needs to
change.

## The three commits and exact paths

Bind these paths in the PR-009 task scope before implementation:

1. **C-009-1 — Reconcile the architecture decisions**

   - `docs/adr/0008-operating-bounds-and-evidence-receipts.md` (use the next
     unused ADR number if the owner assigns one instead);
   - `docs/adr/README.md`, for the index row if the successor is accepted.

   The ADR should state its status and implementation state separately, name
   the retained clauses of ADR-0001 through ADR-0005, and explain any
   successor refinement. It may describe conditional topology options and
   measured-cost/rights gates. It must not select an unmeasured cheapest
   provider, authorize paid infrastructure, or alter the current public
   no-source-egress state.

2. **C-009-2 — Define request and retention budgets**

   - `scripts/research-program/policy.json`;
   - `scripts/research-program/operating-bounds.mjs`.

   The policy is a fixture-only local integration policy. All activation flags
   are false: live network, receipt writes, database writes, and queue
   activation. The external authorization gate remains `AUTH-04`. Source
   entries contain exact source, descriptor, endpoint, and route-template IDs;
   they do not contain arbitrary URLs, query strings, credentials, or body
   content. The pure module validates those references and the request,
   response, retry, DLQ, retention, rights, and cost bounds in memory.

3. **C-009-3 — Implement the evidence receipt contract**

   - `scripts/research-program/receipts/v1.0.0/evidence-receipt.schema.json`;
   - `scripts/research-program/receipts/v1.0.0/README.md`;
   - `tests/research-program/operating-bounds.test.mjs`;
   - optionally, only with explicit ownership and rights review,
     `tests/research-program/fixtures/pr009-census-negative/` containing a
     sanitized manifest, selected receipt projection, and rejected HTML body.

   The schema is a standalone research-program artifact, not a new npm
   workspace or a replacement for `contracts/ingestion/*`. If the fixture is
   not promoted, the test can use an equivalent inline HTML challenge fixture
   while the handoff binds the permitted retained scratch evidence. It must
   not claim to replay a scratch path that is absent from the candidate tree.

This is an extension of the existing research-program tooling because it
composes facts already expressed by the connector and ingestion packages. It
does not create another HTTP client, redirect engine, capture protocol, retry
loop, R2 adapter, queue abstraction, database port, or deletion service.

## Reuse and interface

`operating-bounds.mjs` should export only the small pure interface needed by
the policy and receipt tests:

```js
export const OPERATING_BOUNDS_POLICY_VERSION
export const EVIDENCE_RECEIPT_VERSION
export const EVIDENCE_RECEIPT_SCHEMA_PATH
export function validateOperatingBoundsPolicy(policy, options = {})
export function composeEvidenceReceipt(input)
export function validateEvidenceReceipt(receipt, options = {})
```

The validators accept loaded objects and injected context and return
`{ valid, issues }`. The composer returns a frozen in-memory receipt. None of
the three functions may read files, call `fetch`, import `node:http`,
`node:https`, `node:net`, or `node:tls`, open a database, write R2, send a
Queue or Workflow message, acquire a lease, delete data, or start a
connector. Loading files and compiling the JSON Schema is test setup only.

Use these existing exports without editing their package files or adding a
package-root re-export:

| Existing path | Read-only exports and purpose |
| --- | --- |
| `packages/connectors/src/index.mjs` | `APPROVED_SOURCE_DESCRIPTOR_TEMPLATES`, `CENSUS_METADATA_DESCRIPTOR`, `DESCRIPTOR_TEMPLATE_ACTIVATION`, `validateDescriptor`, `routeManifestInventory`, `compileManifestRequest`, `redactedLocator`, `contractValidationTarget`, `classifyResponse`, and `mediaTypeFromHeaders` for descriptor, route, safe-locator, content, and strict-contract checks. |
| `packages/connectors/src/route-manifest.mjs` | `DEFAULT_RESPONSE_LIMITS` and `responseLimitsForDescriptor`; import the existing module directly because adding a root export would be a connector-byte/WP5 change. |
| `packages/ingestion/src/index.mjs` | `STAGE_POLICIES`, `classifyFailure`, `retryBudget`, and `DLQ_SINK_TRANSPORT_POLICY` for retry, failure-disposition, budget, and DLQ consistency. |

Do not import or wrap `BoundedHttpClient`, `R2CaptureProtocol`,
`DeterministicConnectorRunner`, `createQueueRetentionReconciler`,
`createRetentionGcService`, or PostgreSQL/Queue ports.

The receipt is `ushso.research-program.evidence-receipt.v1.0.0`, JSON Schema
2020-12, with local `$defs` and `additionalProperties: false` at every object
boundary. It references existing `metadata_fetch` and `capture_reference`
contracts without adding properties to them. Its fields cover request type,
expected classes, safe final locator, observed sizes and hashes, source and
parser identity, attempt outcome, next action, and explicit truth boundaries.
Cross-field checks must preserve captured, 304/not-modified, access-only,
pre-egress, typed-failure, truncation/incomplete, and safe-locator semantics.
Raw and semantic hashes are populated only from a real capture reference. A
hash of a retained rejected body is separately labeled as an observed rejected
body hash and never proves capture or schema validity.

The receipt needs one explicit refinement for the retained Census evidence:
`request_type` may be `historical_observation` for an unmatched historical
observation. That branch carries the label `sample-census-acs`,
`route_match: unmatched_historical_observation`, and null source, descriptor,
endpoint, and template IDs. It does not copy the historical query URL or
invent a manifest/template identity. The receipt retains only the safe final
host/path, sets `redirect_count: null` because the chain/count was not
recorded, sets parser state to `not_run`, records a typed failure and
`payload_access_verified: false`, and maps the HTML Missing Key result to the
bounded source action (`pause_source`, or the exact existing equivalent).

## Policy and retention decisions

`policy.json` should constrain the current paused descriptors and their
metadata/schema routes. It should reject source-payload, query-execution,
download, form-submission, login, arbitrary URL, secret, unbounded file, and
unapproved redirect inputs. Request bounds must be no looser than descriptor
bounds, structural response limits must equal the existing
`DEFAULT_RESPONSE_LIMITS`, and source concurrency/rate/burst must be equal to
or stricter than the descriptor. Existing stage retry/delay values, retry
budgets, and DLQ transport policy are inputs to comparison, not a second
retry system.

Retention must preserve the distinction in ADR-0004. Ninety days is the
default active raw metadata/documentation retention. A versioned source-policy
class may choose a shorter or longer period for a stated legal, evidence,
refresh, or operational reason, but the override needs an owner, rationale,
review date, audit event, and explicit legal/rights/dependency/recovery
evidence. Capture hashes, safe provenance, and evidence-lineage references
outlive raw retention while dependencies remain. Security and audit receipts
remain at least 365 days. Existing planner/GC online, dependency, archive,
restore, backup/PITR, replay, rollback, and audited-GC checks remain in force;
the new validator must not turn the 90-day default into an unconditional
per-source legal floor or execute deletion.

Aggregate previews, raw samples, and source payload retention stay disabled or
pending source-specific rights and privacy review. Project-wide permission to
publish code does not establish source-payload rights or a paid budget.

## Current cost and publication inputs

The permitted Neon receipt is
`/mnt/d/tmp/plumbob/ushso-research-program-20260910/pr009-official-pricing-20260911/neon-fresh-fetch-receipt.json`
(560 bytes, SHA-256
`ec8d028957f4e4812289f35ed73e09691bc1ee2b6e071e673cba34ea0612119c`). It
records a public GET 200 for `https://neon.com/pricing` at
`2026-09-11T17:54:21.006904+00:00`. The response was 12,533 bytes with SHA-256
`4a9c3a39127211649236973c9d93da688a82c55353cb43e4191247f84780e3ed`. The
official page states no monthly minimum on paid plans, Launch compute at
`$0.106/CU-hour`, Scale compute at `$0.222/CU-hour`, storage at
`$0.35/GB-month`, history at `$0.20/GB-month`, snapshots at `$0.09/GB-month`,
and 500 GB per project of public egress before `$0.10/GB`. The raw response
at `neon-pricing.raw` remains local review material; publish only that short
paraphrase and the source URL. The stale six-month snippet with a 100 GB/$5
minimum is not an input.

These are conditional arithmetic inputs, not measured costs:

```text
Neon compute = CU-hours × selected Launch/Scale rate
Neon storage/history/snapshot = GB-month × (0.35/0.20/0.09)
Neon public egress = max(0, GB-month − 500) × 0.10
```

Root supplied current official Cloudflare facts from
`https://developers.cloudflare.com/workers/platform/pricing/`: a `$5`
minimum per account-month, 10 million included requests and 30 million
included CPU-ms, then `$0.30` per million requests and `$0.02` per million
CPU-ms. The official limits URL
`https://developers.cloudflare.com/workers/platform/limits/` gives 20,000
static files on Free, 100,000 on Paid, and a 25 MiB per-file limit. The
official static-assets billing page says asset storage and requests are free,
but `run_worker_first` routes invoke a billable Worker. The pinned wrangler
uses `run_worker_first: ['/*']`; PR-009 must not change it. The conditional
Worker expression is:

```text
account charge = 5
  + max(0, requests − 10,000,000) / 1,000,000 × 0.30
  + max(0, CPU-ms − 30,000,000) / 1,000,000 × 0.02
```

Actual requests, CPU-ms, provider plan, account products, Neon CU-hours,
database/R2 layout, history/snapshot volume, retention, compression,
replication, egress, connection/IO behavior, and invoice are unknown. The
proposal makes no cheapest-provider, procurement, monthly-budget, or actual
bill claim.

The 21 MB gate input
`/mnt/d/tmp/plumbob/ushso-research-program-20260910/gate-component-e6da2e2.json`
is SHA-256
`eb91ff62e7933753c1d1db723f3c56db635baadc0744efb7929753a00a1330d4`. It was
parsed programmatically. Its accepted `apps/web/dist` set contains 41,865
assets totaling 1,338,661,425 bytes; the largest is
`apps/web/dist/corpus-v1.2.0/corpus/records-0001.jsonl` at 8,383,528 bytes,
SHA-256
`8b7403e0d0d363ea5879a9dc2e0e2a774ea31e5cd556bf1826ec02706cd33202`. These
are measured publication artifact bytes. They are not database size, R2
layout, monthly usage, a newly rehashed artifact, or an actual provider bill.

## Census negative evidence

The permitted sanitized copy is
`/mnt/d/tmp/plumbob/ushso-research-program-20260910/pr009-census-negative-input/`.
Its source ledger is 30,264 bytes with SHA-256
`3b42a0c919bb4509cab45071f51a52283789aa7d9cc63b6e2122cebea82e88e1`. The
selected retained body is 8,531 bytes, SHA-256
`c2f4687e09b80676de7f68dec92ebea395209616dbc6f895520e547c5f68c0f5`; the
receipt records status 200, `text/html`, observed at
`2026-09-10T14:01:05.543190+00:00`, and final locator
`https://api.census.gov/data/missing_key.html`.

This response came from a historical observation/query URL, not an approved
metadata route. Treat it as an unmatched historical negative observation.
Do not copy its query, assign fabricated manifest/template IDs, claim a
connector run, or infer a zero redirect count. The new receipt should carry a
nullable unknown redirect count, an observed rejected-body hash if retained,
HTML access/content restriction, parser `not_run`, typed failure, and no
payload-access or scientific qualification. The body is complete for this
negative observation, but that does not make it a valid capture or payload.

## Meaningful tests and suite registration

The root `package.json` already registers
`test:research-program` as `node --test tests/research-program/*.test.mjs`
and includes it in the root `npm test` chain. The proposed test therefore
needs no root-script edit. It should cover:

- a policy accepted against current paused descriptors and metadata/schema
  routes;
- an accepted capture reference, a 304 with prior capture and zero new
  bytes, an access probe with no body, and a pre-egress policy block;
- default 90-day raw retention and 365-day security/audit retention, plus a
  shorter/longer override with complete evidence;
- unknown/arbitrary URL, query/download, secret, missing-route, unbounded,
  unexpected-media, private-locator, unapproved-redirect, malformed, and
  truncated inputs;
- the actual unmatched Census 200-HTML result as typed failure/pause with
  null redirect count and no fabricated route identity; and
- a source-level boundary check that rejects transport, R2, database, Queue,
  Workflow, lease, and deletion dependencies in the pure module.

`run-contract-suites.mjs` explicitly registers `wp5` at
`verification/wp5` with `test` and `validate` scripts. Its versioned discovery
selects the highest directory that has the required package/tests/scripts.
There is only `verification/wp5/v1.0.0` at this input. A file is not run merely
because it exists: WP5 runs through `--verification`, `--all`, or
`--suite wp5`; the aggregate `verify:research-navigator` uses `--all`.
`scripts/research-program/` is not discovered as a contract or verification
suite, so the new test is covered by the root test registration and the
PR-009 handoff hashes.

## First WP5 successor boundary

WP5 v1.0.0 asserts the connector fingerprint
`df5fb94f4f3f3468ca2631a63768a4bf7711696657c88c4b7df57830e7031b99`, and its
validator requires fixed receipts to match. The connector fingerprint covers
every file below `packages/connectors/` except the permitted package-manifest
exception. Consequently, any first byte change to a connector source file,
test, README, tool, `package.json`, or `src/index.mjs` makes the v1.0.0
fingerprint and fixed receipts stale. Adding a root export for route limits or
the receipt composer would trigger the same boundary.

PR-010's planned ingestion/services durable wiring and PR-012's planned
ingestion quota/retry/scheduling work do not require a WP5 successor if they
remain within their owned paths; their own WP4/DB evidence remains separate.
PR-011's planned connector content/access/receipt behavior is the first
expected successor boundary. Before that first connector edit, assign an
additive `verification/wp5/v1.1.0/` (or explicitly selected next immutable
version) with its own package, tests, validator, fingerprint, evidence
ledger, receipts, and activation state. Preserve all v1.0.0 bytes and never
weaken or repin its fixed check. A future formal
`contracts/<domain>/v1.x.x` receipt package is a separate contract-suite
decision and does not itself trigger WP5 when connector bytes remain intact.

There is no scope split required before this narrowed PR-009. Split only if a
released cross-package contract, a connector helper/export, or source-specific
rights/retention evidence becomes necessary; each case then needs its own
explicit owner and gate. The remaining immediate blocker is accepted PR-008.
