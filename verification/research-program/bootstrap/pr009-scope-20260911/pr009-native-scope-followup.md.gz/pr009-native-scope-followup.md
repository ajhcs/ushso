# PR-009 operating-bounds follow-up design review

## Review record and disposition

- Review mode: read-only design review against the immutable integration input.
- Selected interface: `gpt-5.6-luna/max`. This is the controller-selected interface recorded for the review; it is not a serving-model self-attestation.
- Worktree: `/mnt/d/worktrees/plumbob/ushso-research-program-20260910`.
- Exact input commit: `ca98b0069ae11976316100ab2e8c6193a0337e7f`.
- Exact input tree: `eed6f09df573a79ac1fca7d37a7f5cbd252693d0`.
- The pinned worktree was clean at the start and end of the review. No repository files were changed, no tests were run, and no network, fetch, store, database, queue, credential, deployment, or paid-resource action was performed.
- The only retained Census body/receipt input read was root’s permitted sanitized scratch copy at `/mnt/d/tmp/plumbob/ushso-research-program-20260910/pr009-census-negative-input/`; the original dirty workspace was not read.

**Disposition: this three-commit shape is coherent and can settle C-009-3 without changing WP5, provided the new receipt path is explicitly added to PR-009 ownership and the hard PR-008 dependency remains.** Remove `packages/connectors/` and `packages/ingestion/` edits from this narrowed implementation. Use their existing exports as read-only dependencies from a pure research-program validator. Add a standalone, self-contained schema under a newly named versioned path in `scripts/research-program/`. Leave durable persistence to PR-010/PR-011 as stated.

The three commits can therefore be:

| Commit | Narrowed contents | Boundary |
| --- | --- | --- |
| C-009-1 | Successor ADR under `docs/adr/` | Record retained ADR-0001/0002/0003/0004/0005 clauses, conditional topology options, measured-input gates, and the disabled public state. Do not select an unmeasured cheapest provider or authorize infrastructure. |
| C-009-2 | `scripts/research-program/policy.json` and `scripts/research-program/operating-bounds.mjs` | Validate policy references and bounds against existing connector/ingestion exports. Compose receipts in memory only. No transport, R2, PostgreSQL, Queue, Workflow, or deletion call. |
| C-009-3 | `scripts/research-program/receipts/v1.0.0/evidence-receipt.schema.json`, its boundary README, and `tests/research-program/operating-bounds.test.mjs` | Define and test a complete additive receipt projection while validating underlying ingestion v1.0 records unchanged. Use the retained Census negative fixture as an access/content failure. Do not edit `contracts/ingestion/*` or `verification/wp5/v1.0.0`. |

PR-008 remains unaccepted at this input: the execution ledger has no `head_sha`, `merge_sha`, or accepted handoff for it. The three commits are a sound target after PR-008 acceptance; they must not be implemented on this pinned tree before that gate.

## Exact owned paths and exports

The following path set is the smallest complete ownership extension. The task binding and handoff must name each new path before editing because the original PR-009 assignment names only `scripts/research-program/policy.json`, not the new schema or root test.

```text
docs/adr/<new-successor-adr>.md
scripts/research-program/policy.json
scripts/research-program/operating-bounds.mjs
scripts/research-program/receipts/v1.0.0/evidence-receipt.schema.json
scripts/research-program/receipts/v1.0.0/README.md
tests/research-program/operating-bounds.test.mjs
```

`scripts/research-program/receipts/v1.0.0/` should remain a standalone research-program artifact, not a new npm workspace or a formal package under `contracts/`. It therefore does not require a package-lock workspace entry or a new `run-contract-suites` definition. The README must say that it is an immutable, body-free receipt projection whose durable persistence and activation are downstream responsibilities. Record the schema file’s raw SHA-256 and byte length in the PR-009 handoff. If a future consumer requires a released cross-package contract, promote this artifact in a separately owned `contracts/<domain>/v1.x.x` package with its own manifest, tests, validator, and workspace-lock changes; do not pretend the script path is already that package.

`scripts/research-program/operating-bounds.mjs` should expose a small pure API:

```js
export const OPERATING_BOUNDS_POLICY_VERSION
export const EVIDENCE_RECEIPT_VERSION
export const EVIDENCE_RECEIPT_SCHEMA_PATH
export function validateOperatingBoundsPolicy(policy, options = {})
export function composeEvidenceReceipt(input)
export function validateEvidenceReceipt(receipt, options = {})
```

Recommended behavior is a `{ valid, issues }` result from both validators and a frozen receipt from `composeEvidenceReceipt`. The functions must accept already loaded objects and injected context; they must not read files, call `fetch`, open a database, write an object, send a Queue message, acquire a lease, or start a connector. The test may load `policy.json` and the schema with `node:fs/promises` and compile the schema with the repository’s existing Ajv dependency; that I/O remains test setup, not validator behavior.

Use these existing exports as read-only inputs, without editing their package files or package-root exports:

| Existing path | Exports to consume | Use |
| --- | --- | --- |
| `packages/connectors/src/index.mjs` | `APPROVED_SOURCE_DESCRIPTOR_TEMPLATES`, `CENSUS_METADATA_DESCRIPTOR`, `DESCRIPTOR_TEMPLATE_ACTIVATION`, `validateDescriptor`, `routeManifestInventory`, `compileManifestRequest`, `redactedLocator`, `contractValidationTarget` | Validate descriptor identity, exact endpoint/template/purpose, paused/AUTH-04 state, safe locators, and v1.0 metadata-fetch/capture pairing. `compileManifestRequest` is a pure route check and must only be used with policy fixture input. |
| `packages/connectors/src/route-manifest.mjs` | `DEFAULT_RESPONSE_LIMITS`, `responseLimitsForDescriptor` | The package root does not currently re-export these structural limits. Import the existing module directly rather than adding an index export, because an index/package edit would change the WP5 fingerprint. |
| `packages/ingestion/src/index.mjs` | `STAGE_POLICIES`, `classifyFailure`, `retryBudget`, `DLQ_SINK_TRANSPORT_POLICY` | Check retry and DLQ policy equality and derive the bounded next action from an existing typed failure. Do not instantiate a control-plane service. |
| `packages/connectors/src/content-classifier.mjs` through the root export | `classifyResponse`, `mediaTypeFromHeaders` | Test a retained body’s content/access outcome without transport or capture. |

Do not import or wrap `BoundedHttpClient`, `R2CaptureProtocol`, `DeterministicConnectorRunner`, `createQueueRetentionReconciler`, `createRetentionGcService`, or PostgreSQL/Queue ports. Those are execution components and would turn this validator into a duplicate transport subsystem.

## Standalone receipt interface

The new schema must be self-contained JSON Schema 2020-12 with `additionalProperties: false` at every object boundary and local `$defs`; it must not alter or `$ref`-extend the released v1.0 schemas. It should carry references and selected safe facts from the existing records rather than embedding source bytes or a new transport record.

The required top-level shape should be:

```text
receipt_version: "ushso.research-program.evidence-receipt.v1.0.0"
receipt_id
policy_version
underlying_contracts
request
identities
attempt
response
content_assessment
boundaries
```

The fields have these meanings:

- `underlying_contracts` pins `metadata_fetch` and `capture_reference` to `ingestion.v1.0.0` when present. The composer must call `contractValidationTarget('metadata_fetch', 'ingestion.v1.0.0')` and the equivalent capture target, or produce a typed interface error. No v1.0 schema receives new properties.
- `request` contains `request_type` (`metadata_fetch` or `access_probe`), `source_id`, `descriptor_id`, `endpoint_id`, `template_id`, `purpose`, `target_class`, and the exact route `expected_content_classes`. The expected classes come from the descriptor route; they are not caller-selected free text.
- `identities` contains source and descriptor IDs, connector name/version from the descriptor, and a parser identity with an explicit `state` of `ran` or `not_run`. A successful parsed capture requires a real supplied parser identity; a blocked, access-only, or pre-parse outcome records `not_run` rather than inventing one.
- `attempt` contains existing IDs (`fetch_id`, `run_id`, `job_id`) when available, `observed_at`, `response_status`, the existing outcome (`captured`, `not_modified`, or `typed_failure`) plus `access_observed` and `blocked_before_egress` for the standalone projection, a body-free failure object, and a controlled `next_action`. For a failure, `next_action` must agree with `classifyFailure`; for a successful or not-modified outcome it is `none`.
- `response` contains a safe `final_locator` object (`final_host`, `final_path_class`, `redacted_locator`, `redirect_count`) or null for pre-egress rejection; media type; compressed/decompressed byte counts; capture, reused-capture, and evidence reference IDs; and hashes. `raw_sha256` and `semantic_sha256` are populated only from an existing capture reference. A separate `observed_body_sha256` may be supplied for a retained failed response, with an explicit `hash_scope` of `observed_rejected_body` or `observed_partial_body`; it must never be treated as a capture or schema-validity proof.
- `content_assessment` separates `expected_content_classes`, actual classification, and `validation_state` (`passed`, `failed`, `incomplete`, or `not_run`). It must encode `truncated` or `incomplete` explicitly. A rejected HTML response cannot be represented as `passed`; a partial hash cannot be represented as a complete capture.
- `boundaries` has required constants `body_included:false`, `payload_access_verified:false`, `analysis_executed:false`, and `credentials_included:false`. These are truth-boundary fields, not claims of future capability.

The semantic validator should enforce these cross-field rules:

1. A captured receipt has a new capture reference, non-null capture hashes and sizes equal to the capture reference, a safe locator matching the route, and `validation_state: passed` only when parser identity and accepted content classification are present.
2. A 304 receipt has `outcome: not_modified`, zero new compressed/decompressed bytes, a non-null exact prior capture reference, no new raw/semantic hash, and no parser run.
3. An access probe has no body, no capture, zero bytes, no parser, and an `access_observed` outcome. It never upgrades to payload access.
4. A response with `outcome: typed_failure` may include observed status, bytes, safe final locator, or an observed rejected-body hash, but it has no capture reference and cannot have `validation_state: passed`.
5. A pre-egress block has no final locator or response status, zero bytes, no hashes/capture, and a failure/next action that identifies the policy block. It must not fabricate an attempted source response.
6. Every locator is HTTPS, redacted, bounded, and host/path coherent. The requested source query is never copied into the receipt; endpoint/template IDs and the safe final locator are enough. Secret, signed, private, or credential-bearing values are rejected.
7. `next_action` is a closed object whose disposition is one of `none`, `retry`, `typed_observation`, `quarantine`, `pause_source`, or `fail_enumeration`, with a bounded safe reason code. This reuses ingestion’s failure taxonomy instead of creating a second retry system.

This completes C-009-3 at the interface level. The later PRs may persist this object or add a formal package adapter, but the schema and pure composer already define every requested field and every failure state. Durable storage is intentionally absent.

## Policy shape and reuse check

`policy.json` should be an operating policy, not a second connector manifest. Its source entries should contain exact IDs and route template IDs, never arbitrary URLs, user query strings, credentials, or raw response content. A useful shape is:

```text
policy_version
scope: fixture_only_local_integration
activation: { live_network_permitted:false, receipt_writes_permitted:false,
              db_writes_permitted:false, queue_activation_permitted:false,
              external_authorization_gate:"AUTH-04" }
route_policy: { allowed_purposes, forbidden_route_classes }
request_bounds: { timeout, maximum_redirects, compressed/decompressed bytes,
                  pages, response depth/nodes/records/links/observations }
source_policies: [ { source_id, descriptor_id, route_template_ids,
                     concurrency, requests_per_second, burst } ]
retry_policy: { stage limits and delays, dlq sink, queue retention }
retention_policy: { active_raw_days, evidence_lineage_days,
                    security_audit_receipt_days, override_evidence_required }
rights_policy: { aggregate_preview: disabled_pending_rights_review,
                 raw_samples: disabled_pending_source_terms }
cost_inputs: { measurement_state: unmeasured, required_evidence: [...] }
```

The pure policy validator should:

- validate every referenced descriptor with `validateDescriptor` and require the current paused, pending-legal, `activation_authorized:false`, `live_network_permitted:false` state;
- require each route template ID to be present in `routeManifestInventory`, restrict purposes to the existing four allowed purposes, require all existing forbidden classes, and reject an observation/query/download route;
- require policy request bounds to be no looser than descriptor bounds (`maximum_pages`, compressed/decompressed bytes, run seconds, redirects) and structural limits to equal `DEFAULT_RESPONSE_LIMITS`;
- require each source concurrency/rate/burst to agree with or be stricter than its descriptor’s `origin_policy` and require Census to expose only `/data.json` and `variables.json` metadata/schema routes;
- compare stage retry/delay values to `STAGE_POLICIES`, queue/DLQ values to `DLQ_SINK_TRANSPORT_POLICY`, and use `retryBudget` for the transport-attempt relationship;
- require the 90-day active raw floor, 365-day security/audit receipt floor, all-zero dependency requirement, and explicit override owner/rationale/review fields without reimplementing `retention-gc.mjs` or executing deletion;
- require aggregate previews and raw/sample retention to remain disabled or explicitly pending rights review; and
- require costs to be labeled `unmeasured` with required future evidence, with no currency estimate or paid budget inferred from publication permission.

The controls are existing behavior composed into a research-program policy check. There is no new HTTP client, redirect engine, capture protocol, retry loop, or database abstraction.

## Test design and actual negative evidence

`tests/research-program/operating-bounds.test.mjs` is the right test location. The root package already defines `test:research-program` as `node --test tests/research-program/*.test.mjs`, and the root `test` chain invokes it. Adding this file requires no root script change. The test should load the policy and schema, compile the schema with strict Ajv settings, and cover:

### Positive cases

1. The policy validates against all current paused descriptors, including the exact Census dataset inventory and variables route templates, with no transport call.
2. A synthetic accepted metadata-fetch plus capture-reference pair composes and validates a receipt. The original v1.0 records validate separately and remain byte-identical. Source/connector/parser identity, expected classes, safe final locator, actual sizes/hashes, `captured`, and `next_action:none` reconcile exactly.
3. A 304 fixture composes with the prior capture ID, zero new bytes, no new hash, and `not_modified`.
4. A pre-egress `policy_blocked` failure composes with a null locator, no response, and `pause_source` next action.
5. A policy with 90-day active raw and 365-day security/audit floors passes; an override with complete owner/rationale/review evidence is accepted only as an explicit conditional class.

### Negative cases

1. An arbitrary URL, unknown source, missing eligible route, observation/query route, secret parameter, or user-supplied payload is rejected before any transport object is available.
2. A v1.0 metadata-fetch or capture-reference object with an added receipt field is rejected by the released strict schema. The standalone receipt references those objects and does not mutate them.
3. The actual retained Census negative input has these bindings: selected receipt/body directory `/mnt/d/tmp/plumbob/ushso-research-program-20260910/pr009-census-negative-input/`; source ledger 30,264 bytes, SHA-256 `3b42a0c919bb4509cab45071f51a52283789aa7d9cc63b6e2122cebea82e88e1`; body 8,531 bytes, SHA-256 `c2f4687e09b80676de7f68dec92ebea395209616dbc6f895520e547c5f68c0f5`; status `200`; media type `text/html`; observed `2026-09-10T14:01:05.543190+00:00`; final URL `https://api.census.gov/data/missing_key.html`. The content classifier must reject it as an access/content restriction (the body contains an HTML form/input challenge), and the receipt must record typed failure/`pause_source` or the repository’s equivalent safe next action. It must never be `captured`, JSON/schema-valid, or payload-access success. The new receipt must not copy the historical request query from the retained receipt; use only the safe final locator and route IDs.
4. HTML where JSON is expected, login/challenge content, payload/row/query/archive content, private or signed locators, unsupported media, unapproved redirects, private/rebound addresses, and malformed content all fail or quarantine with no capture success.
5. A truncated or byte-limit-exceeded fixture produces `validation_state: incomplete`, a bounded observed hash if available, and an explicit next action. It cannot say fully captured or schema-valid.
6. Retention below 90 days, security/audit receipt retention below 365 days, a nonzero GC dependency, or an override missing owner/rationale/review is rejected or GC-blocked. No deletion executes.
7. A source/static scan of `operating-bounds.mjs` rejects direct `fetch`, `node:http`/`https`/`net`/`tls`, R2, `openDatabase`, Queue send, or package-side effect imports. This verifies that the implementation is a pure composition layer rather than transport duplication.

If root promotes the sanitized Census input into the repository for reproducible test execution, the exact proposed fixture path is `tests/research-program/fixtures/pr009-census-negative/` with a manifest, body-free selected receipt projection, and HTML body. That path needs the same explicit ownership extension. If it remains a handoff-only artifact, the committed test must use an equivalent inline challenge fixture and the handoff must bind the actual retained files and hashes; it must not claim to replay a file that is not in the candidate tree.

## Actual suite registration and WP5 trigger boundary

The current registration does not treat every validator file as an automatically executed suite.

- `package.json:36` registers `test:research-program` with the root glob `tests/research-program/*.test.mjs`; `package.json:51` runs it in the root `npm test` chain. The proposed test is therefore directly registered through the existing root test command.
- `scripts/run-contract-suites.mjs:37-58` defines versioned contract/evaluation/verification suites. `wp5` is explicitly registered at line 45 with root `verification/wp5` and required scripts `test` and `validate`.
- `discoverLatestSuite` at lines 273-287 selects the highest version directory under that root and requires a package manifest and discovered Node tests. There is currently only `verification/wp5/v1.0.0`; its package scripts call `tests/*.test.mjs` and `tools/validate-wp5.mjs`.
- `--verification`, `--all`, or `--suite wp5` causes that discovered WP5 package to run. The root has no dedicated `test:wp5` script; the aggregate `verify:research-navigator` script invokes `--all`.
- `scripts/research-program/` is not searched by `discoverContractPackages` or `discoverVerificationSuites`, and it is outside `snapshotSealedArtifacts`’s sealed roots (`contracts`, `docs/feedback`, `evaluation`, `verification`). The new standalone schema and validator are covered by the root research-program test and the PR handoff hash, not by an assumed contract-suite invocation.

The fixed WP5 checks remain strong. `verification/wp5/v1.0.0/tests/wp5-verification.test.mjs` asserts connector fingerprint `df5fb94f4f3f3468ca2631a63768a4bf7711696657c88c4b7df57830e7031b99`; `tools/validate-wp5.mjs` recomputes the fingerprint and requires every current receipt to match. `verification/wp5/v1.0.0/tools/common.mjs` hashes every file below `packages/connectors/` except a possible `manifests/package-manifest.json`.

Consequently, the narrowed PR-009 makes no WP5 change: scripts, the standalone schema, root research-program tests, and documentation do not enter that connector fingerprint. The existing WP5 v1.0.0 package and its strict receipt checks remain untouched. The validator’s read-only imports do not alter bytes or package exports.

## First downstream changes that require a WP5 successor

The first actual downstream edit under `packages/connectors/` requires a separately owned WP5 verification successor. This is a byte-level trigger, not a judgment about whether the behavior is large:

| Downstream change | WP5 v1.0.0 effect | Required handling |
| --- | --- | --- |
| PR-010’s planned `packages/ingestion/` and `services/` durable job wiring, if it stays within its owned paths | No connector fingerprint change | No WP5 successor solely for this work. It must preserve its own WP4/DB evidence and consume the standalone receipt as a data contract only where assigned. |
| PR-011’s planned change to `packages/connectors/src/` for content-aware HTTP/access handling or receipt emission | Current fixed fingerprint and all fixed WP5 receipts become stale; v1.0 validator fails | Before the first connector byte changes, assign a successor such as `verification/wp5/v1.1.0/` with its own package, tests, validator, fingerprint, evidence ledger, receipts, and activation status. Preserve all `verification/wp5/v1.0.0` bytes. |
| PR-012’s planned `packages/ingestion/` quota/retry/scheduling work, if it remains there | No WP5 fingerprint change; it may change future WP4 fingerprint/evidence | No WP5 successor unless PR-012 also edits a connector file. Keep WP4 verification ownership separate. |
| Any addition or change to a connector source file, test, README, tool, `package.json`, or `src/index.mjs` (including a public re-export of response limits or the receipt composer) | `connectorFingerprint()` includes it, so the fixed WP5 expected digest no longer matches | Treat the first such edit as the WP5-successor boundary. Do not weaken or update the v1.0 expected digest in place. |
| A later PR-013 connector adapter/resource extraction change | Same stale-fingerprint result if no earlier connector edit has occurred; otherwise it consumes the already assigned successor | Include the changed connector tree and new receipt behavior in the existing or newly versioned WP5 successor, with exact fingerprint and local/activation scope. |
| A formal `contracts/<domain>/v1.x.x` receipt package without connector edits | No WP5 fingerprint change | It is discovered by the contract suite only if it has package metadata, tests, and validate script under a versioned `contracts` root. It is a separate contract-suite decision and is not necessary for the script-path PR-009 shape. |

The successor package should normally be `verification/wp5/v1.1.0/` (or the next explicitly selected immutable version). Because the `wp5` definition has no major-version filter, the runner will select the highest version directory when the successor has the required private package and scripts. The old v1.0.0 suite remains available by direct path and remains a historical receipt set. No change to `scripts/run-contract-suites.mjs` is needed for a correctly shaped successor, and no fixed validator is assumed to run merely because its file exists.

## Remaining gates and no-cost/no-rights claims

The policy may state code-level limits and required evidence, but it must keep these inputs unresolved:

- actual Neon/Cloudflare/R2/Queue/Workflow pricing and usage, measured workload/2x capacity, connection/storage/IO, latency, provider SLA/residency/caps, and recovery/rollback drills;
- source-specific terms/legal review, raw and aggregate/sample retention rights, MRF rights/privacy, and override owner/rationale/review evidence;
- credentials, authenticated principals, live route confirmation, live shadows/canaries, and any production activation;
- R03 scheduled attempts, R14 held-out model outputs/spend, R15 actual cycles, and R16 release/capacity/rollback evidence.

The policy must label these as `unmeasured`, `pending_rights_review`, or `pending_external_authorization` as applicable. It must not infer paid budget or source-payload rights from project-wide permission to publish code, planning, or sanitized evidence. No model call is part of PR-009.

## Final recommendation

Proceed with the three meaningful commits only after PR-008 acceptance and explicit task-binding ownership of the new script receipt path, README, root test, and any repository-promoted sanitized Census fixture. Keep C-009-3 complete by delivering the standalone strict schema plus pure composer and validator with captured, 304, access-only, pre-egress, typed-failure, truncation, and Census 200/HTML negative cases. Preserve every connector/ingestion package file and every released contract/WP5 receipt byte. Defer the first connector edit—and therefore the WP5 successor—to PR-011 or whichever downstream task first changes `packages/connectors/`.
