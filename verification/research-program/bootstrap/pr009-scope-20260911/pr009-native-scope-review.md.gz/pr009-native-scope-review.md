# PR-009 native operating-bounds scope review

## Review record

- Review mode: read-only scope preparation. No implementation, tests, runtime work, network request, credential/config access, deployment, source download, or paid-resource action was performed.
- Selected interface: `gpt-5.6-luna/max`. This records the controller-selected interface for this review; it is not a serving-model self-attestation.
- Immutable input worktree: `/mnt/d/worktrees/plumbob/ushso-research-program-20260910`.
- Exact input commit: `ca98b0069ae11976316100ab2e8c6193a0337e7f`.
- Exact input tree: `eed6f09df573a79ac1fca7d37a7f5cbd252693d0`.
- The pinned worktree was clean at review time and remained at the exact commit/tree above.
- The requested top-level `prs/PR-009.md` does not exist in the pinned tree. The assignment read from `docs/master-plan/2026-09-10/prs/PR-009.md`, which is the repository path containing PR-009.

## Scope decision

**Hold implementation until PR-008 is accepted, and resolve the receipt-contract and verification-evidence splits before any package edit.** PR-009 can own a bounded policy file and a successor ADR after PR-008 lands. Its operating-bounds work can reuse the existing connector and ingestion controls. The requested evidence receipt, if it is a cross-package or durable wire contract, cannot be implemented by adding fields to the strict `ingestion.v1.0.0` records or by silently changing a sealed WP5 fingerprint. It needs a separately versioned receipt interface and a verification owner. Durable persistence belongs to the downstream control-plane work identified for PR-010/PR-011/PR-012.

PR-008 is still planned/in progress in the pinned execution ledger: it has no `head_sha`, no `merge_sha`, and no accepted handoff. Its assignment says to preserve the frozen v1.0/v1.1 schemas and wait for its acceptance. PR-009 therefore has no implementation base that is authorized by this input. PR-003, PR-004, and PR-007 provide historical or integrated artifacts, but they do not remove that dependency.

The minimal implementable PR-009 after that dependency is accepted is:

1. a successor ADR under `docs/adr/` that records conditional control-plane/storage choices and unresolved measured inputs while reaffirming the existing truth, privacy, publication, rollback, and no-egress boundaries; and
2. `scripts/research-program/policy.json` plus narrowly scoped validators/fixtures, if needed, that encode allowlists, request budgets, retention classes, typed failure behavior, and receipt composition without enabling live collection.

The receipt requirement should be split out, or explicitly reduced to a package-private projection that references existing immutable v1.0 records. A package-private projection still needs its own immutable version and later durable consumer work; it must not be presented as a new v1.0 wire record.

## Reusable implementation and contracts

The following modules are the existing control surface to extend or call after the dependency gate. They already encode the relevant bounds and should be treated as the source of behavior rather than reimplemented in PR-009.

| Concern | Reusable implementation | Scope implication |
| --- | --- | --- |
| Source and route identity | `packages/connectors/src/descriptors.mjs`, `route-manifest.mjs`, `source-route-allowlist.mjs` | Reuse descriptor source IDs, exact route templates, allowed purposes, forbidden classes, host/path validation, the Census metadata-only routes, and the existing 90-day fixture retention default. Do not introduce a caller-supplied URL or observation/query route. |
| Request boundary and network safety | `packages/connectors/src/bounded-http-client.mjs`, `network-policy.mjs`, `pinned-streaming-transport.mjs`, `origin-governor.mjs` | Reuse injected transport/resolver/capture/ledger/governor ports, pre-egress rejection, public-address pinning and rebinding checks, manual bounded redirects, timeout and byte caps, per-origin concurrency/rate limits, and typed failures. |
| Content and access outcome | `packages/connectors/src/content-classifier.mjs` and connector security fixtures | Reuse media/profile checks, login/challenge and private-locator quarantine, payload/row/query sentinels, shape/size limits, and the rule that an HTTP status is not content or access success. |
| Capture evidence | `packages/connectors/src/capture-protocol.mjs` | Reuse exact decoded-byte and semantic hashes, safe headers, redacted locator fields, bounded R2 content keys, conditional object write followed by a PostgreSQL reference, and the distinction between capture observation and content identity. |
| Run barriers | `packages/connectors/src/runner.mjs` and `packages/connectors/src/errors.mjs` | Reuse checkpointing, incomplete/`partial_unpublished` outcomes, retry/failure typing, and the rule that failed work cannot replace the last good publication. |
| Collection policy tests | `packages/connectors/tests/security.test.mjs`, `contracts.test.mjs`, `fixture-matrix.test.mjs` and `packages/connectors/src/testing/fixture-matrix.mjs`, `wave-fixtures.mjs` | Extend positive and negative fixtures only after deciding whether any connector edit will receive a versioned WP5 evidence successor. |
| Retry and typed workflow behavior | `packages/ingestion/src/failure-policy.mjs`, `message-contract.mjs`, `redaction.mjs` | Reuse stage retry limits, typed dispositions, ID/ref-only queue envelopes, secret/body-free logs, and bounded retry-after behavior. |
| Queue/DLQ behavior | `queue-retention-reconciler.mjs`, `dlq-sink-policy.mjs`, `dlq-observation-ingress.mjs`, `dead-letter.mjs` | Reuse 4-day transport retention, durable lost-delivery observations, no synthetic attempts, and replay with new lineage. Do not make receipt policy a second retry engine. |
| Retention and lifecycle safety | `packages/ingestion/src/retention-gc.mjs`, `source-control.mjs`, `ports.mjs`, `postgres-control-store.mjs` | Reuse the all-zero dependency proof, checksum/archive/restore and backup checks, recovery horizon, legal policy, audit trail, pause/drain/resume controls, and fresh-client-per-step contract. PR-009 should define policy and fixtures; it is not authorized to execute deletion. |
| Frozen contract routing | `packages/connectors/src/contract-versions.mjs` and `contracts/ingestion/v1.0.0/`, `contracts/ingestion/v1.1.0/` | Source descriptors use ingestion v1.1; metadata-fetch, capture-reference, harvest-plan, and checkpoint records remain ingestion v1.0 by intentional compatibility. The released schemas are strict and immutable. |

There is no `scripts/research-program/policy.json` in the pinned tree. That is the one named PR-009 policy path that can be added, subject to the dependency and ownership decisions above. The connector and ingestion packages are private and do not contain a package seal at this tree. Their verification fingerprints nevertheless bind implementation evidence: WP5 fixed receipts bind the connector fingerprint, and WP4 computes a fingerprint over ingestion/control-plane implementation for its verification output.

## Earlier ADR clauses that require explicit successor treatment

The successor ADR must state which clauses it retains and which, if any, it supersedes. The following must remain explicit.

- **ADR-0001, product and truth boundary:** catalog visibility does not prove payload access, authorization, join compatibility, coverage, or scientific fitness. The truth envelope retains `source_requests_made=false`, `retrieval_executed=false`, `payloads_acquired=false`, `analysis_executed=false`, and `identity_merges_performed=false` until separately evidenced. Typed unknown, missing, failed, blocked, stale, and authentication-required outcomes remain meaningful; a zero result is scoped.
- **ADR-0002, immutable contracts:** released package directories, manifests, schemas, fingerprints, evaluator packages, and receipts are immutable successors. Strict schemas reject unexpected properties, and enum additions are breaking. Every payload, manifest, cache, receipt, and client must use an explicit immutable version. No `expected_content`, `final_locator`, `parser_identity`, or `next_action` fields may be inserted into v1.0 metadata-fetch/capture objects in place.
- **ADR-0003, identity:** no automatic identity merge or similarity-based equality may be introduced as a side effect of retention or evidence processing.
- **ADR-0004, architecture and operations:** PostgreSQL remains canonical; R2 is limited to bounded public metadata/document evidence and never source payloads, healthcare rows, credentials, cookies, auth material, or secret URLs. Public routes do not harvest, accept credentials, or write R2; staging and production resources, identities, and secrets stay separate; publication is immutable and rollback is pointer-based and non-destructive. The existing roles and capture ordering remain the baseline: validate bounded content, hash exact bytes, conditionally write the object, then commit the capture reference.
- **ADR-0004, unresolved infrastructure:** Neon tier/region, capacity, connection/storage/IO usage, provider SLA/HA/residency/caps, PITR/RPO/RTO, Cloudflare/Access identity, Terraform apply, and production traffic are not evidenced or authorized. The provisional 1–4 CU, 30-day PITR, RPO <=5 minutes, RTO <=30 minutes, and related planning values are not measured commitments. If evidence later changes topology, a new primary-source successor ADR is required. The security addendum specifically rejects the earlier six-`neon_role` assumption because of automatic `neon_superuser` membership; PR-009 must not revive it.
- **ADR-0005, search:** PostgreSQL FTS/GIN is the first production candidate, with immutable generation-bound documents and canonical revision hydration. The current static adapter remains the emergency/public fallback. A dedicated search vendor requires an actual bounded benchmark failure, comparison, cost/security/privacy/residency evidence, least-privilege and rollback planning, and a superseding ADR. PR-009 must not call an unmeasured topology the cheapest or alter the current public no-source-egress runtime.

These are successor decisions, not permission to provision infrastructure, bind a Worker, enable a queue/workflow, activate a connector, or release a new candidate.

## Policy inputs: evidenced versus missing

The policy can encode existing bounds and failure rules, but it must distinguish measured facts from planning values and unresolved external facts.

| Already evidenced in the pinned repository | Still missing and must remain unresolved |
| --- | --- |
| Exact positive source/route allowlists; metadata/document/schema/access-probe purposes; no payload/query/download/archive/login/payment routes; Census descriptor has `/data.json` and `variables.json` metadata/schema routes and no observation route. | Procured Neon/Cloudflare/R2/Queue/Workflow pricing and actual usage costs, including storage, IO, egress, connections, cache behavior, and retention costs. |
| Code-level bounds: per-origin concurrency/rate/burst, request timeout and run limit, one redirect, compressed/decompressed byte caps, structural depth/node/record/link/observation caps, and stage retry ceilings. | A versioned measured workload manifest, p95/p99 latency and capacity at 2x expected load, connection/storage/IO measurements, timed recovery and rollback drills, and provider SLA/HA/region/residency/capacity evidence. |
| Existing capture protocol: raw and semantic hashes, safe headers, bounded redacted locator, exact byte sizes, conditional object write, and reference-after-write ordering. | Source-specific legal/terms/rights decisions, raw-capture and per-source retention classes, review owners and dates, and whether any aggregate preview or MRF sample is permitted. An aggregate/sample store is a separate rights and privacy decision. |
| Existing retention safeguards: active raw metadata/doc default 90 days, longer-lived hashes/provenance/evidence lineage, security/audit receipts at least 365 days, queue transport retention 4 days, GC all-zero dependency proof, and no destructive delete without proof/audit. | Actual source-specific exception rationale and review evidence for shorter/longer classes; legal/backup/lineage replay horizons sufficient to justify any override. |
| WP4/WP5 are local/fixture-only controls with in-memory ports; WP5 fixed receipts record 18 descriptors, 29 routes, one capture/object, zero prohibited/external actions, and activation pending AUTH-04. | Authenticated production principal, credentials, source terms, live shadow/canary evidence, deployment authority, and any paid resource. Project-wide publication permission covers code/planning/sanitized evidence only; it does not infer paid budget, credentials, or source-payload rights. |
| The audit report records a historical Census `sample-census-acs` HTTP 200/HTML missing-key outcome and states that status alone is not access/content success. The portable audit index records `evidence/http-receipts.json` as 30,264 bytes with SHA-256 `3b42a0c919bb4509cab45071f51a52283789aa7d9cc63b6e2122cebea82e88e1`. | The declared Census receipt/body is absent from the pinned tree: `docs/reviews/2026-09-10-product-data-audit/evidence/http-receipts.json` is an index-declared path only, and the body is not separately materialized in the portable package. The preserved original checkout is out of scope. No claim of local replay, fresh access, payload access, or credentialed retry can be made. |
| Existing model/evaluation documents require auditable spend, held-out residual samples, confidence intervals, precision, zero critical errors, and exact model identity for later R14 work. | No PR-009 model call, serving endpoint, model spend budget, paid inference authorization, or credentials are evidenced. Do not use the illustrative economics in the master plan as a quote or spending authority. |

## Narrow owned paths and implementation shape

After PR-008 acceptance and root’s ownership decision, keep PR-009 to these paths:

- `docs/adr/`: add one successor ADR, or a clearly scoped pair if storage and collection policy cannot be reviewed together. It should record conditional options, required measurements, and unresolved facts. It should not contain an infrastructure apply, secret, production binding, paid commitment, or an unmeasured “cheapest” selection.
- `scripts/research-program/policy.json`: add a versioned, machine-readable policy whose source entries point to exact descriptor/route identities. Include global and per-source concurrency/rate/timeout/redirect/byte/shape/retry limits, retention classes and override evidence requirements, security/audit retention, queue retention, and typed stop/next-action states. The policy must have no arbitrary URL field and must not activate source egress.
- `packages/connectors/`: only add a package-local validator or receipt composition layer if root assigns it and the WP5 verification successor is owned. It may compose existing immutable metadata-fetch/capture refs with expected-content, final-locator, parser/connector identity, outcome, and next-action facts under a new explicit private interface. It must not change the v1.0 schemas, mutate existing exports in a way that changes their meaning, or claim a durable cross-package contract without the separate contract work.
- `packages/ingestion/`: reuse existing retention/retry/DLQ/redaction behavior. A policy adapter may validate the JSON policy against these controls, but durable receipt persistence, new DB columns, migrations, public handlers, queue activation, and destructive retention execution belong to a later control-plane scope.

Keep `contracts/`, `db/migrations/`, services, `verification/wp5/v1.0.0` fixed artifacts, and public runtime out of this PR unless a separately approved successor scope explicitly includes them. Preserve the current static/public adapter and all disabled activation states.

## Acceptance cases

These cases are narrow enough to review without live requests or paid resources.

### Positive cases

1. A policy fixture accepts `source_census_metadata` with the exact `/data.json` or `/data/{year}/{dataset_family}/{dataset}/variables.json` route, bounded descriptor values, and a metadata/schema purpose. It emits a typed plan or fixture action while the source remains paused and no transport is called.
2. A valid bounded JSON metadata fixture composes a new package-local receipt projection from existing v1.0 refs. The projection records request type, expected content profile, final redacted locator, actual compressed/decompressed sizes, raw and semantic hashes from the capture ref, source/parser or connector identity, captured outcome, and a bounded next action. It contains no secrets or body bytes, and the underlying v1.0 records still validate unchanged.
3. A valid 304/not-modified fixture references the prior immutable capture, records zero new body bytes and a typed `not_modified` outcome, and creates no new capture object.
4. A retention policy with the existing 90-day active raw default and at least 365-day security/audit receipt retention validates. A GC proof passes only when all dependency counts are zero and archive/restore, backup/PITR, legal policy, replay horizon, workflow grace, and rollback checks are true.

### Negative cases

1. An arbitrary URL, unknown source, missing eligible route, or user-supplied query/body is rejected before transport and records only an ID/ref, typed blocked outcome, and safe next action.
2. The known Census 200/HTML missing-key result is classified as an authentication/content restriction (or the repository’s equivalent typed access/content failure), never as a successful capture or schema-valid response. The receipt records the observed status/content outcome and next action without requesting credentials. Until a sanitized fixture is materialized, this case may use a synthetic equivalent but must not claim replay of the historical body.
3. HTML where JSON/schema content is expected, login/challenge pages, payload/row/query/archive content, signed/private locators, unsupported media, unapproved redirects, private/rebound addresses, and malformed shape are quarantined or typed failed with no capture reference or publication success.
4. A truncated or byte-limit-exceeded JSON/file fixture cannot be schema-valid. Its receipt records incomplete/truncated outcome and bounded next action; it cannot say fully captured or fully validated.
5. An unbounded file/row/decompression request, missing owner/rationale/review on a retention override, online retention below the recovery horizon/90-day floor, security/audit retention below 365 days, or a nonzero GC dependency is rejected or GC-blocked with an auditable reason; no deletion runs.
6. An attempted v1.0 schema extension adding `expected_content`, `final_locator`, `parser_identity`, or `next_action` is rejected by strict contract validation. The change is accepted only under a new versioned receipt interface with its own manifest, validator, fingerprint, and consumer plan.
7. Any connector code change that leaves WP5 v1.0 receipts at their old implementation fingerprint fails the existing WP5 validator. The acceptance path is a versioned verification successor or an explicitly assigned refresh, never silent mutation of historical receipts.

## Required splits and blockers before implementation

1. **Hard dependency:** PR-008 is unaccepted at the exact input. No PR-009 implementation may start until its additive schema/identity/extractor work is accepted and its handoff is available.
2. **Receipt interface split:** C-009-3 asks for fields not present in strict v1.0 metadata-fetch/capture contracts. Create a separately versioned evidence-receipt contract/package with a manifest, schema, validator, compatibility statement, and consumers, or narrow C-009-3 to an explicitly private package-local projection. Do not extend or relabel v1.0.
3. **Verification split:** connector edits change the package implementation fingerprint consumed by fixed WP5 v1.0 receipts. A WP5 verification successor/receipt refresh must have an owner and immutable version. Ingestion changes likewise require its computed fingerprint to be recorded in the appropriate future verification artifact; they must not overwrite released evidence.
4. **Durability split:** DB capture references currently have fixed fields and grants; new cross-package receipt fields need migrations, storage ownership, schema review, and downstream control-plane wiring. Defer this to the appropriate PR-010/011/012 or a separately assigned interface PR.
5. **Cost/rights split:** actual provider pricing/usage, measured capacity and recovery evidence, source terms, raw/sample retention, and aggregate/MRF rights are absent. PR-009 may name them as gates and encode a disabled/conditional policy; it cannot claim a cheapest measured topology, authorize paid capacity, or authorize aggregate/raw sample retention.
6. **Census evidence split:** the historical 200/HTML evidence is index-declared but not present in the pinned tree. A sanitized portable fixture/receipt package is needed for exact replay acceptance. Reading the original dirty checkout or fetching Census is prohibited by this review.
7. **Downstream release split:** R03, R14, R15, and R16 require later materialized attempts, held-out model results/spend, scheduled cycles, and exact release/capacity/rollback evidence. PR-009 can define their control inputs and negative boundaries; it cannot mark those requirements satisfied.

The resulting decision is **scope PR-009 as policy plus conditional ADR after accepted PR-008, and split C-009-3/verification/durable persistence before package implementation**. No implementation is authorized by this review.

