import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import time

root=pathlib.Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr008-final-review-20260911')
scratch=pathlib.Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
out=scratch/'pr008-controller-review-a90071e'
task='ushso-pr008-final-review-20260911'
head='a90071e261bee496fad1e3b1f98b07e0504a0fdd'
node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
npm=str(scratch/'tooling/node_modules/.bin/npm')
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(root),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==head
assert not git('status','--porcelain')
assert git('rev-parse','HEAD^{tree}')=='9b05e1bb1c087150195fcc1dccd6287dcbc1f4a1'
packet_path=scratch/'pr008-native-dispatch-packet.json'
assert hashlib.sha256(packet_path.read_bytes()).hexdigest()=='59a44a1a19d616365eb0ab8a38bb035a8a5d89ef95b886477b101561b0e7381f'
packet=json.loads(packet_path.read_text())
base='a00630c712e3a4e64354a77d268cb168fa3f528a'
changed=git('diff','--name-only',base,head).splitlines()
assert all(any(p==owned or owned.endswith('/') and p.startswith(owned) for owned in packet['owned_paths']) for p in changed)
frozen_paths=['contracts/machine-toolkit/v1.0.0','contracts/machine-toolkit/v1.1.0','packages/identity/schemas','evaluation/research-program/cohorts.json','evaluation/research-program/tasks.json','docs/research-program/acceptance.md']
assert not git('diff','--name-only',base,head,'--',*frozen_paths)
out.mkdir(exist_ok=False)
checks=[
 ('controller-semantic-cases',[node,str(scratch/'pr008-controller-cases.mjs'),str(root),str(out/'semantic-receipt.json')]),
 ('controller-parent-chain',[node,str(scratch/'pr008-controller-parent-chain-cases-v3.mjs'),str(root),str(out/'parent-chain-receipt.json')]),
 ('variable-identity',[node,'--test','tests/research-program/variable-identity.test.mjs']),
 ('extractors',[node,'--test','tests/research-extractors.test.mjs']),
 ('cms-layout',[node,'--test','tests/cms-layout.test.mjs']),
 ('dictionary-review',[node,'--test','tests/dictionary-review.test.mjs']),
 ('update-cycle',[node,'--test','tests/update-cycle.test.mjs']),
 ('identity-package-test',[npm,'test','--prefix','packages/identity']),
 ('identity-package-validate',[npm,'run','validate','--prefix','packages/identity']),
 ('handoff',[node,'scripts/research-program/check-handoff.mjs','docs/research-program/handoffs/PR-008.json'])
]
commands=[]
for label,cmd in checks:
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(cmd,cwd=root,capture_output=True,timeout=120)
    (out/(label+'.stdout.log')).write_bytes(result.stdout)
    (out/(label+'.stderr.log')).write_bytes(result.stderr)
    commands.append({'name':label,'command':cmd,'cwd':str(root),'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,'stdout':{'path':label+'.stdout.log','bytes':len(result.stdout),'sha256':hashlib.sha256(result.stdout).hexdigest()},'stderr':{'path':label+'.stderr.log','bytes':len(result.stderr),'sha256':hashlib.sha256(result.stderr).hexdigest()}})
    print(json.dumps({'name':label,'exit_code':result.returncode}),flush=True)
handoff=json.loads((root/'docs/research-program/handoffs/PR-008.json').read_text())
artifact_errors=[]
for item in handoff['artifacts']:
    p=root/item['path']
    if not p.is_file(): artifact_errors.append({'path':item['path'],'error':'missing'}); continue
    b=p.read_bytes()
    if hashlib.sha256(b).hexdigest()!=item['sha256'] or len(b)!=item['bytes']: artifact_errors.append({'path':item['path'],'error':'hash_or_size_mismatch'})
assert git('rev-parse','HEAD')==head
assert not git('status','--porcelain')
receipt={'format':'ushso.pr008.controller-review.v1','head':head,'tree':git('rev-parse','HEAD^{tree}'),'base':'a00630c712e3a4e64354a77d268cb168fa3f528a','checked_artifact_count':len(handoff['artifacts']),'handoff_sha256':hashlib.sha256((root/'docs/research-program/handoffs/PR-008.json').read_bytes()).hexdigest(),'packet_sha256':hashlib.sha256(packet_path.read_bytes()).hexdigest(),'frozen_paths_unchanged':frozen_paths,'owned_changed_paths':changed,'artifact_errors':artifact_errors,'commands':commands,'worktree_clean_after':True,'accepted':False,'scope':'Independent fixed-head review; failing semantic cases require producer correction. No integration, payload or scientific acceptance.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out/'receipt.json'),'failed_commands':sum(c['exit_code']!=0 for c in commands),'artifact_errors':artifact_errors}))
