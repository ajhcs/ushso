# PR-086/WP11 addendum: durable named fixtures and the PR-008 lock transition

## Disposition

Against immutable commit `a30cd7730de04200f7cd3ffb75ca83378c9e9a1d` (tree
`401b7e745ab01f3c7883f3b64180ad9294e27ac0`), the line-389 correction proposed
in the companion WP11 test review is necessary but insufficient for the next
workspace transition. `reportCurrentVersusHistoricalInputs` classifies an
unknown lock as `unreviewed_package_lock` and then throws
`WP11_CURRENT_INPUT_UNREVIEWED_DRIFT`; a completed PR-008 workspace lock would
therefore fail the current wrapper before it can return a pending report.

The narrow successor should have two distinct layers:

1. A test-local current path/hash/length oracle and durable named fixture. This
   corrects the 156-current-versus-154-historical test assumption and removes
   the named fixture's dependency on mutable workspace files or unpublished
   Git objects.
2. A separate, exact PR-008 current-lock transition record in the wrapper.
   It is eligible only after the accepted PR-008 candidate's actual lock bytes
   have been independently reviewed. It must not extend the historical seal or
   issue current approval.

No implementation, allowlist, test, or repository change was made for this
addendum.

## What is already retained

At this head, the historical snapshot durably contains the original package
and lock bytes only:

- `historical-preimage-snapshot/blobs/25874c7d...` is the original
  `package.json`, 3555 bytes, SHA-256
  `25874c7d9464210794bd7a1467b117ef5fc71808fdf5e34726ea65181744561c`.
- `historical-preimage-snapshot/blobs/af2070ae...` is the historical
  `package-lock.json`, 134190 bytes, SHA-256
  `af2070ae111bc67c397b07e33b44c1fbd15bba31b63210990068943998e1bc28`.

The named pre-PR005 current transition bytes are not retained in a separate
payload under the existing named or historical fixture locations. They are
currently available as root files and Git-history objects: PR-003
`package.json` is 3666 bytes / SHA-256
`b6c3469c7b10ecb90114199c18c3ebb293d801b8c8a3521cb25ded2fdba8d05e`, and the
PR-085 CI v1.4 lock is 134511 bytes / SHA-256
`37e4a9ec1fba9ab254aa7a596e1a0e3f73919cf5358717dc6e06e0478be6b20c`. The
current root has those bytes at this head, but PR-008 can change the root
lock. A fresh or shallow CI checkout cannot be required to contain commits
`bf46d92b0e4fc91457bd3eb78aa1742ae84038f2` or
`4f90157108a92ce9541c340d5536eac31f24a1d`.

## Exact future owned paths

Keep the correction bounded to these paths:

- `tests/wp11-attestation.test.mjs`: independent current inventory oracle,
  named fixture loader, current-set mutation/addition/removal controls, and
  role assertions.
- `scripts/verify-wp11-attestation.mjs`: one separately named exact
  `PR008_REVIEWED_PACKAGE_LOCK` record and its current-wrapper role branch,
  added only after the independent lock review below. Leave
  `ALLOWED_PACKAGE_LOCK.historical` and `.pr085_ci_v14` unchanged.
- `verification/research-program/ci-attestation/wp11-v1.3.0/policy.json`:
  record the current transition provenance and exact old/new bytes and hashes
  in a separately named `reviewed_current_transitions` section. Do not rewrite
  `historical`, `allowed_package_lock`, snapshot, receipt, or approval fields.
- `verification/research-program/ci-attestation/wp11-v1.3.0/named-pre-pr005-fixture/manifest.json`,
  `package.json`, and `package-lock.json`: exact tracked payloads for the
  named two-transition fixture. The manifest must bind each role, payload
  path, decoded byte length, and SHA-256. The test reads these files directly;
  it never calls Git for this fixture. These files stay outside
  `historical-preimage-snapshot/`, whose 154-file reader rejects extra or
  unreferenced blobs.
- `verification/research-program/pr-086/` and
  `docs/research-program/handoffs/PR-086.json`: additive evidence and handoff
  only, including the fixture manifest hash, transition review receipt, exact
  candidate head/tree, and unresolved status before root acceptance.

Add all three fixture names to `WP11_WRAPPER_IMPLEMENTATION_FILES` and the
policy's declared list together, so the current wrapper subject covers the
named test input as well as the loader. The test must still hash-bind every
payload against the manifest. This changes only the pending current wrapper
subject and requires no historical repin.

## Current-lock transition choice

The smallest safe choice is an exact pin, not a generic lockfile approval. Once
PR-008 has an accepted exact candidate, record:

```json
{
  "id": "pr008_workspace_lock_transition",
  "path": "package-lock.json",
  "source_commit": "<accepted PR-008 final commit>",
  "historical_bytes": 134511,
  "historical_sha256": "37e4a9ec1fba9ab254aa7a596e1a0e3f73919cf5358717dc6e06e0478be6b20c",
  "current_bytes": "<measured>",
  "current_sha256": "<measured>",
  "review_receipt": { "path": "<durable PR-008 evidence>", "sha256": "<receipt hash>" }
}
```

`lockStateFor` can check this record after the two existing states and return a
distinct state; `currentInputRole` should expose
`pr008_workspace_lock_transition`. Unknown bytes must continue through the
existing catch as `unreviewed_package_lock`, and the report must continue to
throw. The named and PR-005 historical-transition tests must still require
`pr085_ci_v14_workspace_lock`; a PR-008 candidate test must require the new
role. Both reports retain `approval: null`,
`historical_approval_transferred: false`, `combined_acceptance: false`, and
`release_qualified: false`.

The repository already has `auditWorkspaceLock` in
`verification/testing/ci/v1.4.0/tools/ci-inventory.mjs`. It checks lockfile
version, root/workspace descriptors, links, and discovered workspace paths, but
it does not bind an old/new byte pair or prove that all non-PR-008 dependency
records stayed unchanged. Importing that latest-suite helper as the WP11 role
gate would couple WP11 to another package and accept a wider class of lock
changes. It may be used as a secondary semantic check during PR-008 review;
it must not replace the exact current-lock pin. A reusable strict delta rule
would need a new bounded contract for canonical old/new record comparison and
its own ownership, so it is larger than this correction.

## Required independent review before the new role is enabled

Root must supply, from the accepted PR-008 candidate, the actual final
`package-lock.json` bytes, length, SHA-256, source head/tree, and a durable
review receipt. The review must compare the new lock with the current PR-085
base (`134511` / `37e4a9ec...`) and verify the exact PR-008 workspace package
and `node_modules/*` link entries against the corresponding package manifests.
It must record whether any root package, registry dependency, resolved version,
integrity, engine, or unrelated workspace entry also changed. No claim may be
made from the PR-008 plan alone, and no future hash may be invented here.

The transition is acceptable only when that review establishes the exact
current bytes and the candidate's own package-lock/workspace checks pass. A
one-byte mutation, an incomplete or partial transition, an unknown lock, or a
lock whose unrelated entries drift must remain blocked. The new record is a
reviewed current-input transition, not a historical approval and not a release
or procurement decision.

## Acceptance and seal boundaries

The test oracle must derive the current 156-file set from
`scope-paths.json`, the four broad builder roots, and the three explicit root
files, then compare every path, byte length, and SHA-256 independently of the
builder's path array. Keep historical `SEALED_WP11_FILE_COUNT === 154`, total
bytes, subject, receipt, and offline snapshot checks exact. Keep the current
and wrapper drafts pending with approval null. The known PR-008 lock may make
the current-versus-historical report return a complete 154-pin diff, but it
does not make the 154 historical seal 155/156 files and does not grant a
current approval.

The existing current mutation, historical snapshot blob, runner, direct
validate/issue, and approval-overclaim controls remain. Add current fixture
positive coverage and negative missing, unexpected, duplicate, and
hash/length-mismatch cases. No package version, released schema bytes,
historical inventory, approval, receipt, general runner registration, or
production boundary changes are part of this correction.

## Reviewed inputs and provenance

- Companion proposal retained unchanged at
  `/mnt/d/tmp/plumbob/ushso-research-program-20260910/wp11-current-file-set-test-correction-proposal.md`:
  7713 bytes, SHA-256
  `cc20861afec1e56b9601a3598fe84e6cc842e3bbf1af630c4749b7a09f2097db`.
- `tests/wp11-attestation.test.mjs`: 39335 bytes, SHA-256
  `4a48478762c2ea6e3529b865f6cfba02db6f04a0cab5c05849bc66ac5b21bdc9`.
- `scripts/verify-wp11-attestation.mjs`: 33143 bytes, SHA-256
  `360bdf7b409374e6d85b493667c49e7fcea1022c9defbd56bcb1305cdd326db5`.
- `verification/research-program/ci-attestation/wp11-v1.3.0/policy.json`:
  4861 bytes, SHA-256
  `9373939ec21f1e606164a30e4a2e1f55dcd147ec2b22290289b5feec6dcadee8`.
- Historical inventory: 41674 bytes, SHA-256
  `46fc584ae6b494ca562455968c14ba799970c45237479b7edadb74939cd1a000`;
  154 files totaling 1347732 bytes.
