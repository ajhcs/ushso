from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,gzip,subprocess

R=Path.cwd();S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
task='ushso-pr006-pr008-combined-20260911';base='16880f31b5806111ae89d6911ff0f38beea396a8';producer='8cc74ed2ffbaab5b6b009770930dbf0e6fef0f3d';source='0ddacd2be49f8d8df4a43bf8272385311e65722b';authority='96431eca22ddb9f33ad0244538d198624228d37a'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],text=True).strip();blob=lambda h,p:subprocess.check_output(['git','show',h+':'+p]);now=lambda:datetime.now(timezone.utc).isoformat()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==base and not git('status','--porcelain')
assert git('rev-parse',producer+'^{tree}')=='c77da5bd60b281d9d098b2ba02bb6e6729ff011e'
pr='verification/research-program/pr-086/';hp='docs/research-program/handoffs/PR-086.json'
producer_handoff=blob(producer,hp);assert sha(producer_handoff)=='adc03b574d413e18de8410ddfbd1fe9faa787d447227e7234df7bc594093029b'
implementation_review=(S/'pr086-current-input-review-0ddacd2/receipt.json').read_bytes();assert sha(implementation_review)=='c5469dd676cc36ea9593caae8725345c74d2089be9b53e74d53d793408ba8f36'
assert json.loads(implementation_review)['status']=='PASS'
wp11_paths=['scripts/verify-wp11-attestation.mjs','tests/wp11-attestation.test.mjs','verification/research-program/ci-attestation/wp11-v1.3.0/','verification/wp11/','scripts/run-contract-suites.mjs','verification/successor-support.mjs']
assert not git('diff','--name-only',source,producer,'--',*wp11_paths)
result=subprocess.run(['git','merge','--no-ff','--no-edit','-m','Compose reviewed PR086 current-input continuation',producer],capture_output=True)
for name,b in [('stdout',result.stdout),('stderr',result.stderr)]: (S/('compose-pr086-final.'+name+'.log')).write_bytes(b)
assert result.returncode==0,result.stderr.decode();merge=git('rev-parse','HEAD');assert not git('status','--porcelain')
destination='verification/research-program/bootstrap/pr086-current-input-review-20260911';D=R/destination;assert not D.exists();D.mkdir(parents=True)
artifacts=[]
def retain(raw,relative,origin):
 data=gzip.compress(raw,mtime=0);assert gzip.decompress(data)==raw
 p=D/(relative+'.gz');p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
 artifacts.append({'path':p.relative_to(R).as_posix(),'bytes':len(data),'sha256':sha(data),'decoded':{'bytes':len(raw),'sha256':sha(raw),'encoding':'gzip'},'origin':origin})
for p in sorted((S/'pr086-current-input-review-0ddacd2').iterdir()):
 if p.is_file():retain(p.read_bytes(),'implementation-review/'+p.name,str(p))
for name in ['pr086-controller-current-input-cases-v1.mjs','pr086-controller-current-input-cases-v2.mjs','pr086-controller-current-input-cases.mjs','pr086-controller-legacy-negative-a30cd77.json','pr086-controller-legacy-negative-a30cd77-v2.json','pr086-controller-procedure-correction.json','pr086-controller-probe-refinement-v3.json','run-pr086-current-input-independent-review.py','review-pr086-final-metadata.py','pr086-final-metadata-review-8cc74ed-failed.json','compose-pr086-and-correct-metadata.py']:
 retain((S/name).read_bytes(),'controller/'+name,str(S/name))
original_paths=[pr+'source/authority-pr086.md',pr+'source/manifest.json',hp,'docs/research-program/execution-ledger.json']
for p in original_paths:retain((R/p).read_bytes(),'before-controller-correction/'+p,merge+':'+p)
assignment_path=pr+'source/authority-pr086.md';expected=blob(authority,'docs/master-plan/2026-09-10/prs/PR-086.md')
assert len(expected)==11443 and sha(expected)=='8fea1108ed7e1fb9f2c6c79b471755d5ab4daf5d790963d31df6af1d98f65d8b'
(R/assignment_path).write_bytes(expected)
sp=R/pr/'source/manifest.json';manifest=json.loads(sp.read_text())
row=next(x for x in manifest['records'] if x['path']==assignment_path);row.update(bytes=len(expected),sha256=sha(expected));sp.write_text(json.dumps(manifest,indent=2)+'\n')
h=json.loads((R/hp).read_text())
for a in h['artifacts']:
 if a['path'] in [assignment_path,pr+'source/manifest.json']:
  b=(R/a['path']).read_bytes();a.update(bytes=len(b),sha256=sha(b))
h['unresolved_claims'].append({'id':'controller-authority-source-correction','status':'pending','detail':'Root corrected the retained assignment to exact authority96431eca bytes and updated current reference hashes after the producer handoff. Original producer bytes and failed source review remain in bootstrap/pr086-current-input-review-20260911. This is controller-authored metadata; separate peer review remains pending. Product/test/policy bytes are unchanged from the independently reviewed implementation0ddacd2b.'})
(R/hp).write_text(json.dumps(h,indent=2)+'\n')
lp=R/'docs/research-program/execution-ledger.json';ledger=json.loads(lp.read_text());index=next(i for i,t in enumerate(ledger['tasks']) if t['pr_id']=='PR-086');prior=ledger['tasks'][index]
(D/'previous-pr086-ledger-task.json').write_text(json.dumps(prior,indent=2)+'\n')
packet=json.loads((S/'pr086-current-input-correction-dispatch.json').read_text())
ledger['tasks'][index]={
 'pr_id':'PR-086','status':'independent_review','owner':None,'dependencies':list(packet['dependency_merge_shas']),
 'dependency_merge_shas':packet['dependency_merge_shas'],'owned_paths':packet['owned_paths'],'base_sha':packet['base_sha'],'base_tree':packet['base_tree'],'head_sha':producer,'head_tree':'c77da5bd60b281d9d098b2ba02bb6e6729ff011e','merge_sha':None,'integration_merge_sha':None,'github_pr_url':None,'branch':packet['branch'],'worktree':packet['repo'],'task_id':packet['task'],'provider':'native Codex collaboration','actual_model':'gpt-5.6-luna','selected_model':'gpt-5.6-luna','provider_status':'completed','handoff':hp,'evidence_directory':pr,'planned_atomic_commits':3,'prerequisites_satisfied':True,'parent_pr':'PR-005','previous_accepted_implementation':{'head_sha':prior['head_sha'],'integration_merge_sha':prior['integration_merge_sha'],'base_sha':prior['base_sha'],'ledger_record':destination+'/previous-pr086-ledger-task.json','prior_acceptance_preserved':True},'current_input_correction':{'correction_id':'PR086-CURRENT-INPUT-20260911','status':'behavior_independently_verified_metadata_review_pending','decision':'verification/research-program/bootstrap/pr086-current-inventory-scope-20260911/decision.json','dispatch':'verification/research-program/bootstrap/current-correction-dispatches-20260911/pr086-current-input-correction-dispatch.json','reviewed_lock_input':'verification/research-program/bootstrap/pr008-lock-review-072241e/review.json','implementation_review':destination+'/index.json','controller_metadata_correction':destination+'/metadata-correction.json'},'blockers':['Separate review of controller authority-source and live-ledger metadata correction; combined gate and actual hosted CI pending.'],'next_action':'Validate the default handoff against this actual continuation binding, run focused combined checks and exact-candidate gate, obtain separate controller-metadata review and hosted CI before shared integration. Current subject approvals remain PR082-owned and null.'}
controller=ledger['controller'];controller['current_active_corrections']=[]
for field in ['active_assignments','active_native_implementations']:
 if isinstance(controller.get(field),list):
  old=controller[field];controller.setdefault('preserved_assignment_observations',[]).extend(old);controller[field]=[]
controller['current_correction_review']={'PR-006':'independently_verified_final8a9b921','PR-008':'independently_verified_final911aff5','PR-086':'behavior_passed; controller metadata correction awaits separate review'}
controller['provider_readiness_observation']={'version':'3.4.3','grok_ready':True,'dsh_default_model':'meta/muse-spark-1.3-contributor','provider_prompt_dispatched':False,'current_disclosure_block':'automatic_review_rejected; specific user authorization question pending','evidence':destination+'/provider-and-downstream/pr010-grok-scope-auto-review-rejection.json.gz'}
controller['next_component_candidate']={'status':'local_corrected_composition_pending_preflight_gate_and_peer_metadata_review','components':{'PR-006':'8a9b921fa4be059624606116ed5ad33c238bb9ab','PR-008':'911aff5588ea59b12b81b58f1d5e07ce09a987d3','PR-086':producer},'isolated_composition_head':merge,'full_gate_pending':True,'combined_hosted_ci_pending':True,'peer_metadata_review_pending':True,'accepted':False}
controller.setdefault('implementation_authorship',[]).append('PR086 exact authority-source byte-copy/reference correction and continuation ledger binding; original producer/accepted records preserved; separate peer review pending.')
ledger['updated_at']=now();lp.write_text(json.dumps(ledger,indent=2)+'\n')
correction={'format':'ushso.pr086-controller-metadata-correction.v1','recorded_at':now(),'author':'Astra/root','producer_head':producer,'producer_tree':'c77da5bd60b281d9d098b2ba02bb6e6729ff011e','composition_merge':merge,'source_implementation_head':source,'changed_producer_files':[assignment_path,pr+'source/manifest.json',hp],'source_assignment':{'authority_commit':authority,'path':'docs/master-plan/2026-09-10/prs/PR-086.md','bytes':len(expected),'sha256':sha(expected)},'new_live_ledger_base':packet['base_sha'],'previous_accepted_record':destination+'/previous-pr086-ledger-task.json','product_test_policy_and_historical_bytes_changed':False,'independent_peer_review':'pending; native followup rejected due to agent task limit and Grok disclosure blocked by automatic review','acceptance':False}
(D/'metadata-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
for name in ['pr010-grok-scope-auto-review-rejection.json','pr009-public-pricing-preparation-20260911.json']:
 retain((S/name).read_bytes(),'provider-and-downstream/'+name,str(S/name))
for p in sorted((S/'pr011-epa-destination-observation-20260911').iterdir()):
 if p.is_file():
  if p.suffix=='.gz':retain(gzip.decompress(p.read_bytes()),'epa-observation/'+p.name[:-3],str(p)+' (decoded exact gzip input)')
  else:retain(p.read_bytes(),'epa-observation/'+p.name,str(p))
idx={'format':'ushso.independent-review-portable-index.v1','recorded_at':now(),'reviewed_implementation_head':source,'producer_head':producer,'artifacts':artifacts,'controller_metadata_correction':'metadata-correction.json','metadata_files':[{'path':destination+'/'+n,'bytes':(D/n).stat().st_size,'sha256':sha((D/n).read_bytes())} for n in ['metadata-correction.json','previous-pr086-ledger-task.json']],'peer_metadata_review_pending':True,'accepted':False}
(D/'index.json').write_text(json.dumps(idx,indent=2)+'\n')
for a in h['artifacts']:
 b=(R/a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path']
assert not git('diff','--name-only',producer,'--',*wp11_paths)
subprocess.run(['python3','docs/master-plan/2026-09-10/validate.py'],check=True)
subprocess.run(['git','add','--',assignment_path,pr+'source/manifest.json',hp,'docs/research-program/execution-ledger.json',destination],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Bind current PR086 provenance and preserve prior review evidence'],check=True,stdout=subprocess.DEVNULL)
assert not git('status','--porcelain')
result={'format':'ushso.corrected-components-composition.v1','recorded_at':now(),'repo':str(R),'task':task,'base':base,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'producer_heads':controller['next_component_candidate']['components'],'pr086_local_merge':merge,'index':{'path':destination+'/index.json','sha256':sha((D/'index.json').read_bytes()),'bytes':(D/'index.json').stat().st_size},'pr086_handoff_sha256':sha((R/hp).read_bytes()),'controller_metadata_correction':destination+'/metadata-correction.json','fresh_dependency_install_required':True,'preflight_pending':True,'gate_pending':True,'hosted_ci_pending':True,'peer_metadata_review_pending':True,'accepted':False,'requirements_accepted':[]}
p=S/'corrected-components-final-candidate.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
