from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time

R=Path.cwd(); S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
head='0ddacd2be49f8d8df4a43bf8272385311e65722b'; base='a30cd7730de04200f7cd3ffb75ca83378c9e9a1d'; authority='1b343b98173949480bd52929b9207725f6ca8f8c'
task='ushso-pr086-current-input-review-20260911'; out=S/'pr086-current-input-review-0ddacd2'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
blob=lambda h,p:subprocess.check_output(['git','show',h+':'+p])
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
tree=git('rev-parse','HEAD^{tree}')
packet_raw=(S/'pr086-current-input-correction-dispatch.json').read_bytes()
assert sha(packet_raw)=='802a056e95e6e0ad1a7f9cfec67bfa536971a5ed0f511b574b728dafcb173360'
packet=json.loads(packet_raw)
changed=git('diff','--name-only',base,head).splitlines()
assert all(any(p==o or o.endswith('/') and p.startswith(o) for o in packet['owned_paths']) for p in changed)
frozen=['verification/wp11/','verification/successor-support.mjs','verification/research-program/ci-attestation/wp11-v1.3.0/historical-preimage-snapshot/','verification/research-program/ci-attestation/wp11-v1.3.0/historical-preimage-reader.mjs','scripts/run-contract-suites.mjs','package.json','package-lock.json','evaluation/research-program/cohorts.json','evaluation/research-program/tasks.json','docs/research-program/acceptance.md']
assert not git('diff','--name-only',base,head,'--',*frozen)
fixture_root='verification/research-program/ci-attestation/wp11-v1.3.0/named-pre-pr005-fixture/'
manifest=json.loads((R/fixture_root/'manifest.json').read_text())
fixture_bindings=[]
for item in manifest['files']:
    b=(R/fixture_root/item['fixture_path']).read_bytes()
    assert b==blob(item['source_commit'],item['source_path'])
    assert len(b)==item['bytes'] and sha(b)==item['sha256']
    fixture_bindings.append({k:item[k] for k in ['path','source_commit','source_path','bytes','sha256']})
origin='verification/research-program/bootstrap/pr008-lock-review-072241e/'
copy='verification/research-program/pr-086/pr008-lock-review-072241e/'
files=git('ls-tree','-r','--name-only',authority,'--',origin).splitlines()
assert len(files)>10
assert sorted(p[len(copy):] for p in git('ls-tree','-r','--name-only',head,'--',copy).splitlines())==sorted(p[len(origin):] for p in files)
for p in files:
    assert (R/copy/p[len(origin):]).read_bytes()==blob(authority,p),p
review_raw=(R/copy/'review.json').read_bytes()
assert len(review_raw)==9360 and sha(review_raw)=='a4d52b75b44f7d3340e8a91ad0dc4716ce4d513b84d18edf8b4ebca656e94b3a'
assert not out.exists();out.mkdir()
node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node';commands=[]
checks=[('controller-current-input-cases',[node,str(S/'pr086-controller-current-input-cases.mjs'),str(R),str(out/'controller-cases.json')]),('wp11-regression-tests',[node,'--test','tests/wp11-attestation.test.mjs']),('wp11-adapter',[node,'scripts/verify-wp11-attestation.mjs']),('wp11-contract-suite',[node,'scripts/run-contract-suites.mjs','--suite','wp11'])]
for label,args in checks:
    started=datetime.now(timezone.utc).isoformat();t=time.monotonic()
    try:
        p=subprocess.run(args,capture_output=True,timeout=300);code=p.returncode;streams={'stdout':p.stdout,'stderr':p.stderr}
    except subprocess.TimeoutExpired as e:
        code=124;streams={'stdout':e.stdout or b'','stderr':(e.stderr or b'')+b'\nController command timeout after 300 seconds\n'}
    bindings={}
    for name,b in streams.items():
        n=label+'.'+name+'.log';(out/n).write_bytes(b);bindings[name]={'path':n,'bytes':len(b),'sha256':sha(b)}
    commands.append({'label':label,'argv':args,'started_at':started,'duration_seconds':time.monotonic()-t,'exit_code':code,'streams':bindings})
    print(json.dumps({'label':label,'exit_code':code}),flush=True)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
ok=all(c['exit_code']==0 for c in commands)
receipt={'format':'ushso.pr086-current-input-independent-review.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'reviewer':'Astra/root','implementation_author':'native /root/pr009_operating_bounds_scope','head':head,'tree':tree,'base':base,'scope_packet_sha256':sha(packet_raw),'changed_paths':changed,'protected_paths_unchanged':frozen,'named_fixture_git_byte_bindings':fixture_bindings,'portable_review_files_matched':len(files),'portable_review_sha256':sha(review_raw),'source_review':['Historical lock roles and immutable historical reader/snapshot, released WP11 versions and runner are unchanged.','Only exact byte/hash pair f90550e2 with134907bytes receives the separate PR008 current role. Current binding requires the exact independent review receipt and policy source/previous/new identities.','The test oracle enumerates declared current scope and broad roots independently of the technical builder, compares all path/hash/length values and rejects duplicate/add/remove/mutated fixture inputs.','Named pre-PR005 package fixtures read only committed portable bytes with exact historical provenance; no mutable-current or Git fallback remains in that named fixture. Other explicitly historical Git test cases retain their existing Git requirement.'],'commands':commands,'status':'PASS' if ok else 'FAIL','final_handoff_review':'pending producer final evidence commit','independent_integration_acceptance':'pending combined gate and hosted CI','requirements_accepted':[],'current_approval_issued':False,'worktree_clean':True}
p=out/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':sha(p.read_bytes()),'status':receipt['status']}),flush=True)
raise SystemExit(0 if ok else 1)
