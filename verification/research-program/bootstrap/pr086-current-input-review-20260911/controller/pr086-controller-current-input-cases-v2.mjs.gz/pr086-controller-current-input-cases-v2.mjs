import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root=path.resolve(process.argv[2]);
const output=path.resolve(process.argv[3]);
const task=process.env.WORKTREE_BOOTSTRAP_TASK;
assert.ok(task,'managed task identity is required');
execFileSync('/home/plumbob/.local/bin/worktree-bootstrap',['verify',task,'--repo',root,'--require-writer'],{cwd:root,stdio:'pipe'});
assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');
const mode=process.argv[4] ?? 'current';
const sha=b=>createHash('sha256').update(b).digest('hex');
const subject=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const wp=await import(pathToFileURL(path.join(root,'scripts/verify-wp11-attestation.mjs')).href);
const history=await import(pathToFileURL(path.join(root,'verification/research-program/ci-attestation/wp11-v1.3.0/historical-preimage-reader.mjs')).href);
const retained=await history.readHistoricalPreimageSnapshot({root});
assert.equal(retained.file_count,154);
assert.equal(retained.subject_sha256,'294d8b40bb5a2dbe1f55cdfde4a60205de75ee1ffe48e0108eae69aea2db0f98');
const currentLock=execFileSync('git',['show','072241ed12f2c0b04deb833eee857ca43920b9d3:package-lock.json'],{cwd:root,maxBuffer:2_000_000});
const previousLock=execFileSync('git',['show','a90071e261bee496fad1e3b1f98b07e0504a0fdd:package-lock.json'],{cwd:root,maxBuffer:2_000_000});
assert.equal(sha(currentLock),'f90550e267d390cb7fc328319f0d2cf849b76a9e52b5e83f6eefc4a045d58ec8');
assert.equal(currentLock.length,134907);
assert.equal(sha(previousLock),'37e4a9ec1fba9ab254aa7a596e1a0e3f73919cf5358717dc6e06e0478be6b20c');
const cases=[];
async function check(id,fn){
  try { const detail=await fn();cases.push({id,status:'passed',detail:detail ?? null}); }
  catch(error){cases.push({id,status:'failed',error:String(error.message).slice(0,1400),stack:String(error.stack).split('\n').slice(0,5).join('\n')});}
}
const readWithLock=lock=>async(_root,p)=>p==='package-lock.json'?lock:readFile(path.join(root,p));
async function diffWith(lock){return wp.reportCurrentVersusHistoricalInputs({root,snapshot:retained,readCurrentFile:readWithLock(lock),currentSource:'controller_actual_committed_lock_fixture'});}
async function expectUnreviewed(lock){
  let rejected;
  try{await diffWith(lock);}catch(e){rejected=e;}
  assert.ok(rejected,'changed lock must be rejected');
  assert.match(rejected.message,/WP11_CURRENT_INPUT_UNREVIEWED_DRIFT:package-lock\.json/);
  const row=rejected.changed.find(r=>r.path==='package-lock.json');
  assert.equal(row.role,'unreviewed_package_lock');
  assert.equal(row.current_sha256,sha(lock));
  assert.equal(row.current_bytes,lock.length);
  assert.equal(row.historical_sha256,'af2070ae111bc67c397b07e33b44c1fbd15bba31b63210990068943998e1bc28');
  return {error:rejected.message,role:row.role,current_sha256:row.current_sha256};
}
if(mode==='legacy-negative'){
  await check('prior-wrapper-rejects-new-committed-lock',()=>expectUnreviewed(currentLock));
}else{
  await check('actual-current-wrapper-keeps-all-approval-boundaries',async()=>{
    const report=await wp.verifyWp11Attestation({root});
    assert.equal(report.status,'PASS');
    for(const part of [report.current,report.wrapper]){
      assert.equal(part.approval,null);
      assert.equal(part.status,'pending_authorized_review');
      assert.notEqual(part.subject_sha256,retained.subject_sha256);
    }
    assert.equal(report.current.release_gate_pass,false);
    assert.equal(report.current.production_eligibility,false);
    assert.equal(report.boundaries.current_approval_issued,false);
    assert.equal(report.boundaries.historical_approval_reused,false);
    const independent=[];
    for(const pin of retained.files){
      const bytes=await readFile(path.join(root,pin.path));
      if(sha(bytes)!==pin.sha256 || bytes.length!==pin.bytes)independent.push({path:pin.path,historical_bytes:pin.bytes,historical_sha256:pin.sha256,current_bytes:bytes.length,current_sha256:sha(bytes)});
    }
    independent.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
    const actual=report.current_versus_historical.changed.map(({path,historical_bytes,historical_sha256,current_bytes,current_sha256})=>({path,historical_bytes,historical_sha256,current_bytes,current_sha256}));
    assert.deepEqual(actual,independent);
    assert.equal(report.current_versus_historical.compared_file_count,154);
    assert.equal(report.current_versus_historical.approval,null);
    assert.equal(report.current_versus_historical.combined_acceptance,false);
    return {historical_files:154,changed_historical_inputs:independent.length,current_file_count:report.current.file_count,current_subject:report.current.subject_sha256,wrapper_subject:report.wrapper.subject_sha256};
  });
  await check('current-inventory-matches-independent-immutable-tree-enumeration',async()=>{
    const declared=JSON.parse(await readFile(path.join(root,'verification/wp11/v1.3.0/scope-paths.json'),'utf8'));
    const tracked=execFileSync('git',['ls-tree','-r','--name-only','HEAD'],{cwd:root,encoding:'utf8',maxBuffer:8_000_000}).trim().split('\n');
    const roots=['verification/wp11/v1.3.0/','apps/web/src/','packages/retrieval/tools/','packages/retrieval/schemas/'];
    const selected=[...new Set([...declared,'verification/successor-support.mjs','package.json','package-lock.json',...tracked.filter(p=>roots.some(r=>p.startsWith(r)))])].sort();
    const expected=[];
    for(const p of selected){const b=await readFile(path.join(root,p));expected.push({path:p,bytes:b.length,sha256:sha(b)});}
    const draft=await wp.buildCurrentWp11Draft({root});
    assert.equal(new Set(draft.technical_evidence.files.map(f=>f.path)).size,draft.technical_evidence.files.length);
    assert.deepEqual(draft.technical_evidence.files,expected);
    assert.equal(draft.approval,null);
    assert.equal(draft.release_gate_pass,false);
    assert.equal(retained.file_count,154);
    return {current_file_count:expected.length,historical_file_count:retained.file_count};
  });
  await check('exact-reviewed-pr008-lock-has-distinct-unapproved-current-role',async()=>{
    const r=await diffWith(currentLock);const row=r.changed.find(x=>x.path==='package-lock.json');
    assert.equal(row.role,'pr008_workspace_lock_transition');
    assert.equal(row.current_sha256,sha(currentLock));
    assert.equal(row.current_bytes,currentLock.length);
    assert.equal(row.historical_sha256,'af2070ae111bc67c397b07e33b44c1fbd15bba31b63210990068943998e1bc28');
    for(const key of ['current_approval_issued','historical_approval_transferred','combined_acceptance','release_qualified'])assert.equal(r[key],false);
    assert.equal(r.approval,null);return row;
  });
  await check('previous-current-lock-retains-its-original-role',async()=>{
    const r=await diffWith(previousLock);const row=r.changed.find(x=>x.path==='package-lock.json');
    assert.equal(row.role,'pr085_ci_v14_workspace_lock');assert.equal(row.current_sha256,sha(previousLock));assert.equal(r.approval,null);return {role:row.role};
  });
  await check('historical-lock-is-not-relabelled-as-pr008',async()=>{
    const r=await diffWith(retained.bytesByPath.get('package-lock.json'));
    assert.equal(r.changed.some(x=>x.path==='package-lock.json'),false);assert.equal(r.approval,null);
  });
  await check('one-byte-change-to-reviewed-lock-still-fails',()=>expectUnreviewed(Buffer.concat([currentLock,Buffer.from(' ')])));
  await check('partial-workspace-transition-still-fails',async()=>{
    const v=JSON.parse(currentLock);delete v.packages['contracts/machine-toolkit/v1.2.0'];return expectUnreviewed(Buffer.from(JSON.stringify(v,null,2)+'\n'));
  });
  await check('unrelated-dependency-change-still-fails',async()=>{
    const v=JSON.parse(currentLock);assert.ok(v.packages['node_modules/ajv']);v.packages['node_modules/ajv'].version='0.0.0-controller-negative';return expectUnreviewed(Buffer.from(JSON.stringify(v,null,2)+'\n'));
  });
  await check('missing-transition-policy-binding-fails',async()=>{
    const p=JSON.parse(await readFile(path.join(root,'verification/research-program/ci-attestation/wp11-v1.3.0/policy.json'),'utf8'));
    assert.ok(p.reviewed_current_transitions,'positive policy must declare transition provenance');
    delete p.reviewed_current_transitions;
    await assert.rejects(()=>wp.bindWrapperImplementation({root,policy:p}),/WP11_/);
  });
  await check('changed-transition-policy-hash-fails',async()=>{
    const p=JSON.parse(await readFile(path.join(root,'verification/research-program/ci-attestation/wp11-v1.3.0/policy.json'),'utf8'));
    let edits=0;
    function mutate(x){if(x&&typeof x==='object')for(const k of Object.keys(x)){if(x[k]===sha(currentLock)){x[k]='0'.repeat(64);edits++;}else mutate(x[k]);}}
    mutate(p.reviewed_current_transitions);assert.ok(edits>0);
    await assert.rejects(()=>wp.bindWrapperImplementation({root,policy:p}),/WP11_/);
  });
}
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),subject);
assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');
const receipt={format:'ushso.pr086-controller-current-input-cases.v1',head:subject,root,mode,passed:cases.filter(c=>c.status==='passed').length,failed:cases.filter(c=>c.status==='failed').length,cases,current_lock_sha256:sha(currentLock),historical_subject:retained.subject_sha256,requirements_accepted:[]};
await writeFile(output,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt));
process.exitCode=receipt.failed?1:0;
