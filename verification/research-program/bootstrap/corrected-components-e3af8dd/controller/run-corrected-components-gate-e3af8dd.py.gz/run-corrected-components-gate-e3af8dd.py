from pathlib import Path
import hashlib, json, os, subprocess

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
preflight_path = S / 'corrected-components-preflight-e3af8dd/receipt.json'
assert sha(preflight_path) == 'ff4946f4954a2e4c0d9497d8525621838212a572df39447749f61bccb853866b'
cp = json.loads(preflight_path.read_text())
head = cp['head']
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', 'ushso-corrected-components-review-20260911', '--repo', str(R), '--require-writer'], check=True)
assert head == 'e3af8dda1720efd5d29fd1a65683d0f18a412e94'
assert git('rev-parse', 'HEAD') == head and git('rev-parse', 'HEAD^{tree}') == cp['tree'] and not git('status', '--porcelain')
assert cp['status'] == 'ready_for_exact_candidate_gate' and cp['accepted'] is False
assert all(c['exit_code'] == 0 for c in cp['commands']) and cp['artifact_bindings_checked'] == 399
plan_path = S / 'combined-e3af8dd-gate-plan.json'
assert sha(plan_path) == 'cec2fb7c0cb328b5be32b38d0445901cd4ad29d662ac74383d49538fd508d8d5'
plan = json.loads(plan_path.read_text())
assert plan['plan_fingerprint'] == 'd63b3c8f70adc0b6a849f21f947542e0be56442ab8a713822115b2de338f43ae'
assert len(plan['stages']) == 10 and sum(s['kind'] == 'build' for s in plan['stages']) == 1
assert all(s['selected'] and s['retries'] == 0 for s in plan['stages'])
assert sha(R / '.codex/release-gate.toml') == '068273993ddb6692eb5ac77a07d9ab7a10a5ee670efdf3b236ba1064de297478'
listeners = subprocess.run(['ss', '-H', '-tlnp', '( sport = :18787 )'], capture_output=True, text=True, check=True)
assert not listeners.stdout.strip(), 'Gate port 18787 is already in use'
env = dict(os.environ)
env['PATH'] = str(S / 'tooling/node_modules/.bin') + os.pathsep + env['PATH']
env['WRANGLER_LOG_PATH'] = str(S / 'gate-component-e3af8dd-wrangler.log')
assert subprocess.check_output(['npm', '--version'], env=env, text=True).strip() == '11.19.1'
receipt = S / 'gate-component-e3af8dd.json'
assert not receipt.exists()
with (S / 'gate-component-e3af8dd-run.stdout').open('xb') as out, (S / 'gate-component-e3af8dd-run.stderr').open('xb') as err:
    result = subprocess.run(['/home/plumbob/.local/bin/release-gate', 'run', '--repo', str(R), '--receipt', str(receipt)], env=env, stdout=out, stderr=err)
assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
print(json.dumps({'head': head, 'receipt': str(receipt), 'exit_code': result.returncode}), flush=True)
raise SystemExit(result.returncode)
