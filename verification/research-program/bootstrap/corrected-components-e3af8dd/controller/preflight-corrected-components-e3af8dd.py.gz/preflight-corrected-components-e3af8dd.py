from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, time

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
D = S / 'corrected-components-preflight-e3af8dd'
task = 'ushso-corrected-components-review-20260911'
base = '980895daec306d15181de7291ed28a4330d57b6a'
head = 'e3af8dda1720efd5d29fd1a65683d0f18a412e94'
tree = '2e4fce44b99f4838df69b13752e663f3eed856df'
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
sha = lambda b: hashlib.sha256(b).hexdigest()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', task, '--repo', str(R), '--require-writer'], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain')
directory = 'verification/research-program/bootstrap/gate-980895d-artifact-correction/'
old = 'verification/research-program/bootstrap/pr008-review-e433eff/pr008-controller-worktree-create.json'
new = old.removesuffix('.json') + '.log'
index_path = 'verification/research-program/bootstrap/pr008-review-e433eff/index.json'
changed = git('diff', '--name-only', base, head).splitlines()
assert all(p in [old, new, index_path] or p.startswith(directory) for p in changed), changed
subprocess.run(['git', 'merge', '--ff-only', head], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD^{tree}') == tree and not git('status', '--porcelain')
assert not D.exists()
D.mkdir()
cp = json.loads((S / 'corrected-components-final-candidate.json').read_text())
assert cp['head'] == head and cp['tree'] == tree
assert (R / new).read_bytes() == subprocess.check_output(['git', 'show', base + ':' + old])
original_index_raw = subprocess.check_output(['git', 'show', base + ':' + index_path])
assert gzip.decompress((R / directory / 'prior-e433eff-index.json.gz').read_bytes()) == original_index_raw
new_index = json.loads((R / index_path).read_text())
next(a for a in new_index['artifacts'] if a['path'] == new)['path'] = old
assert new_index == json.loads(original_index_raw)
prior_path = S / 'corrected-components-preflight-980895d/receipt.json'
prior_raw = prior_path.read_bytes()
assert sha(prior_raw) == '53b133e611b1592f970aeb6b4ed9a724f2756a5e7da72797393ed8976b7af567'
prior = json.loads(prior_raw)
assert prior['head'] == base and prior['status'] == 'ready_for_exact_candidate_gate'
for p, expected in prior['frozen_sha256'].items():
    assert sha((R / p).read_bytes()) == expected
artifacts = 0
for pr, producer in cp['producer_heads'].items():
    subprocess.run(['git', 'merge-base', '--is-ancestor', producer, head], check=True)
    h = json.loads((R / 'docs/research-program/handoffs' / (pr + '.json')).read_text())
    for a in h['artifacts']:
        b = (R / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256'], a['path']
        artifacts += 1
for index in [cp['index'], *cp['additional_indices']]:
    b = (R / index['path']).read_bytes()
    assert len(b) == index['bytes'] and sha(b) == index['sha256']
    idx = json.loads(b)
    for a in idx['artifacts']:
        b = (R / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256']
        raw = gzip.decompress(b)
        assert len(raw) == a['decoded']['bytes'] and sha(raw) == a['decoded']['sha256']
        artifacts += 1
    for a in idx['metadata_files']:
        b = (R / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256']
        artifacts += 1
json_count = 0
for p in (R / 'verification').rglob('*.json'):
    if 'node_modules' not in p.parts:
        json.loads(p.read_bytes())
        json_count += 1
node = '/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
checks = [('external-authorization-artifacts', [node, '--test', 'verification/external-authorization/v1.1.0/tests/register.test.mjs'])]
checks += [(pr.lower() + '-handoff', [node, 'scripts/research-program/check-handoff.mjs', 'docs/research-program/handoffs/' + pr + '.json']) for pr in ['PR-006', 'PR-008', 'PR-086']]
commands = []
for label, args in checks:
    started = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    result = subprocess.run(args, capture_output=True, timeout=120)
    streams = {}
    for name, b in [('stdout', result.stdout), ('stderr', result.stderr)]:
        filename = label + '.' + name + '.log'
        (D / filename).write_bytes(b)
        streams[name] = {'path': filename, 'bytes': len(b), 'sha256': sha(b)}
    commands.append({'label': label, 'argv': args, 'started_at': started, 'duration_seconds': time.monotonic() - timer, 'exit_code': result.returncode, 'streams': streams})
    print(json.dumps({'label': label, 'exit_code': result.returncode}), flush=True)
assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
ok = all(c['exit_code'] == 0 for c in commands)
receipt = {'format': 'ushso.corrected-components-preflight.v3', 'recorded_at': datetime.now(timezone.utc).isoformat(), 'head': head, 'tree': tree, 'repo': str(R), 'task': task, 'commands': commands, 'artifact_bindings_checked': artifacts, 'verification_json_files_parsed': json_count, 'frozen_sha256': prior['frozen_sha256'], 'fresh_managed_locked_install': True, 'prior_preflight': {'head': base, 'path': str(prior_path), 'sha256': sha(prior_raw)}, 'behavior_evidence': prior['behavior_evidence'], 'metadata_delta': {'paths': changed, 'product_tests_policy_and_dependencies_unchanged': True, 'log_bytes_unchanged': True, 'old_index_archived_unchanged': True, 'only_current_index_artifact_locator_changed': True}, 'prior_gate_failure': cp['prior_failed_gate'], 'status': 'ready_for_exact_candidate_gate' if ok else 'changes_requested', 'peer_metadata_review_pending': True, 'gate_pending': True, 'hosted_ci_pending': True, 'accepted': False, 'requirements_accepted': []}
p = D / 'receipt.json'
p.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'path': str(p), 'sha256': sha(p.read_bytes()), 'status': receipt['status'], 'artifact_bindings_checked': artifacts}), flush=True)
raise SystemExit(0 if ok else 1)
