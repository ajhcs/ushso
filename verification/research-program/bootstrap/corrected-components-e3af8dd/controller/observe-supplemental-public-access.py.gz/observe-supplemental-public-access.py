from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, time, urllib.request, urllib.error

S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
D = S / 'supplemental-access-observations-20260911'
assert not D.exists()
D.mkdir()
sha = lambda b: hashlib.sha256(b).hexdigest()
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None
opener = urllib.request.build_opener(NoRedirect())
probes = [
    {'id': 'usaspending-reference-agencies', 'url': 'https://api.usaspending.gov/api/v2/references/toptier_agencies/', 'documentation': 'https://api.usaspending.gov/docs/endpoints', 'expected_resource_role': 'reference_agency_metadata', 'maximum_rows_requested': None, 'row_bound_basis': 'No row-limit parameter documented for this reference list; one response capped at 262144 bytes.', 'claim_limit': 'Access to a reference list does not demonstrate health-related awards access, agency coverage completeness, award schema stability, comparability or scientific suitability.'},
    {'id': 'federal-register-document-list', 'url': 'https://www.federalregister.gov/api/v1/documents.json?per_page=1&order=newest', 'documentation': 'https://www.federalregister.gov/reader-aids/developer-resources/rest-api', 'expected_resource_role': 'published_document_metadata', 'maximum_rows_requested': 1, 'row_bound_basis': 'Exactly one page requested with per_page=1; no next-page or document-body requests.', 'claim_limit': 'Access to one document-metadata result does not qualify healthcare policy linkage, legal authority, completeness, effective-date interpretation or scientific suitability.'}
]
observations = []
for probe in probes:
    started = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    record = {'format': 'ushso.supplemental-bounded-access-observation.v1', **probe, 'recorded_at': started, 'request': {'method': 'GET', 'headers': {'Accept': 'application/json', 'Accept-Encoding': 'identity', 'User-Agent': 'USHSO-public-source-review/1.0'}, 'credentials_sent': False, 'cookies_sent': False, 'origin_header_sent': False}, 'bounds': {'requests': 1, 'redirects': 0, 'retries': 0, 'timeout_seconds': 20, 'body_bytes': 262144}, 'approved_recipe': False, 'scientific_fitness': 'unverified', 'catalog_publication': False, 'cohort_change': False}
    response = None
    try:
        request = urllib.request.Request(probe['url'], headers=record['request']['headers'], method='GET')
        try:
            response = opener.open(request, timeout=20)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw = response.read(262145)
            truncated = len(raw) > 262144
            if truncated:
                raw = raw[:262144]
            headers = {name.lower(): response.headers.get(name) for name in ['Content-Type', 'Content-Encoding', 'Date', 'Access-Control-Allow-Origin'] if response.headers.get(name) is not None}
            status = response.status
            body_path = D / (probe['id'] + '.body.gz')
            encoded = gzip.compress(raw, mtime=0)
            body_path.write_bytes(encoded)
            record['response'] = {'status': status, 'final_url': response.geturl(), 'redirect_count': 0, 'headers': headers, 'bytes_read': len(raw), 'sha256': sha(raw), 'truncated': truncated, 'body_complete': not truncated, 'byte_scope': 'HTTP response representation with Accept-Encoding identity; no decoded content claim if Content-Encoding is present', 'body_artifact': {'path': body_path.name, 'bytes': len(encoded), 'sha256': sha(encoded), 'encoding': 'gzip'}}
            record['browser_cors_tested'] = False
            record['outcome'] = 'http_failure' if status != 200 else 'content_unqualified'
            if status == 200 and not truncated and not headers.get('content-encoding'):
                try:
                    value = json.loads(raw)
                    results = value.get('results') if isinstance(value, dict) else None
                    record['payload_shape'] = {'root_type': type(value).__name__, 'top_level_keys': sorted(value) if isinstance(value, dict) else None, 'results_is_array': isinstance(results, list), 'observed_result_count': len(results) if isinstance(results, list) else None, 'first_result_keys': sorted(results[0]) if isinstance(results, list) and results and isinstance(results[0], dict) else None}
                    record['outcome'] = 'bounded_json_payload_observed'
                    if probe['maximum_rows_requested'] is not None:
                        record['requested_row_bound_observed'] = isinstance(results, list) and len(results) <= probe['maximum_rows_requested']
                    if probe['id'].startswith('usaspending') and isinstance(results, list):
                        record['hhs_reference_matches'] = [{k: row.get(k) for k in ['agency_id', 'toptier_code', 'abbreviation', 'agency_name']} for row in results if isinstance(row, dict) and row.get('agency_name') == 'Department of Health and Human Services']
                except (ValueError, UnicodeError) as error:
                    record['content_parse_error'] = type(error).__name__
    except Exception as error:
        record['outcome'] = 'transport_error'
        record['error_type'] = type(error).__name__
    record['duration_seconds'] = time.monotonic() - timer
    p = D / (probe['id'] + '.json')
    p.write_text(json.dumps(record, indent=2) + '\n')
    observations.append({'id': probe['id'], 'path': p.name, 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size, 'outcome': record['outcome'], 'status': record.get('response', {}).get('status'), 'body_bytes': record.get('response', {}).get('bytes_read')})
    print(json.dumps(observations[-1]), flush=True)
index = {'format': 'ushso.supplemental-access-observation-index.v1', 'recorded_at': datetime.now(timezone.utc).isoformat(), 'directory_revision': '7ee71f04dd42720f7f4130aa70f804aa95c53164', 'observations': observations, 'documentation_statements': [{'source': 'https://api.usaspending.gov/docs/endpoints', 'statement': 'Publisher endpoint documentation states that authorization is not currently required.'}, {'source': 'https://www.federalregister.gov/reader-aids/developer-resources/rest-api', 'statement': 'Publisher documentation describes JSON/CSV, no API keys, pagination within the first 2000 results, and CORS support. Those general statements are distinct from these server-side observations; browser requests and rate-limit behavior were not tested.'}], 'requirements_accepted': [], 'frozen_cohorts_changed': False, 'candidate_publication_authorized_by_this_record': False}
(D / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
