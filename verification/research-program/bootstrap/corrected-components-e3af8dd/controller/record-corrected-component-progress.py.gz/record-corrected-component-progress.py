from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
C = Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911')
base = '1b343b98173949480bd52929b9207725f6ca8f8c'
candidate = 'e3af8dda1720efd5d29fd1a65683d0f18a412e94'
task = 'ushso-research-program-20260910'
directory = 'verification/research-program/bootstrap/corrected-components-e3af8dd'
D = R / directory
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
now = lambda: datetime.now(timezone.utc).isoformat()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', task, '--repo', str(R), '--require-writer'], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain')
assert subprocess.check_output(['git', '-C', str(C), 'rev-parse', 'HEAD'], text=True).strip() == candidate
assert not subprocess.check_output(['git', '-C', str(C), 'status', '--porcelain'], text=True).strip()
gate_path = S / 'gate-component-e3af8dd.json'
gate_raw = gate_path.read_bytes()
gate = json.loads(gate_raw)
assert gate['candidate']['head_sha'] == candidate and gate['candidate']['tree_sha'] == '2e4fce44b99f4838df69b13752e663f3eed856df'
outcome = gate['classification'] or gate['verdict']
assert outcome in ['passed', 'product_test_failed', 'environment_blocked']
assert gate['evidence_independent'] is True
passed = gate['verdict'] == 'passed'
assert not D.exists()
D.mkdir(parents=True)
artifacts = []
def retain(name, source, origin):
    data = source.read_bytes() if isinstance(source, Path) else source
    p = D / name
    p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(source, Path) and source.name.endswith('.gz'):
        packed, raw = data, gzip.decompress(data)
    else:
        raw, packed = data, gzip.compress(data, mtime=0)
    p.write_bytes(packed)
    artifacts.append({'path': p.relative_to(R).as_posix(), 'bytes': len(packed), 'sha256': sha(packed), 'decoded': {'bytes': len(raw), 'sha256': sha(raw), 'encoding': 'gzip'}, 'origin': origin})

retain('local-gate.json.gz', gate_raw, 'exact first normal gate on ' + candidate)
for stage in gate['stages']:
    for attempt in stage.get('attempts', []):
        if attempt.get('log_path'):
            p = Path(attempt['log_path'])
            retain('local-gate-logs/' + p.name + '.gz', p, stage['name'] + ' attempt ' + str(attempt['attempt']))
for name in ['combined-e3af8dd-gate-plan.json', 'run-corrected-components-gate-e3af8dd.py', 'preflight-corrected-components-e3af8dd.py', 'controller-metadata-peer-review-e3af8dd.json', 'corrected-components-final-candidate.json', 'gate-e3af8dd-receipt-readback.json', 'record-corrected-component-progress.py', 'pr010-grok-scope-auto-review-rejection.json', 'pr009-public-pricing-preparation-20260911.json', 'observe-supplemental-public-access.py']:
    retain('controller/' + name + '.gz', S / name, 'controller evidence, procedure, or prepared input; no peer review or provider dispatch implied')
for p in sorted((S / 'corrected-components-preflight-e3af8dd').iterdir()):
    assert p.is_file()
    retain('preflight/' + p.name + '.gz', p, 'exact candidate preflight')
for scan_dir in ['publication-review-corrected-combined-980895d', 'publication-review-corrected-combined-delta-e3af8dd', 'publication-review-pr006-corrected-8a9b921', 'publication-review-pr008-corrected-911aff5', 'publication-review-pr086-current-input-8cc74ed']:
    for name in ['payload-manifest.json', 'scan.json', 'gitleaks.json', 'gitleaks-history.json', 'scan.log', 'history-scan.log', 'finding-disposition.json']:
        p = S / scan_dir / name
        if p.exists():
            retain('publication-scans/' + scan_dir + '/' + name + '.gz', p, 'local exact-payload or history scan; no publication')
for p in sorted((S / 'supplemental-access-observations-20260911').iterdir()):
    assert p.is_file()
    retain('supplemental-access/' + p.name + ('' if p.name.endswith('.gz') else '.gz'), p, 'bounded public metadata observation or body replay; not recipe or scientific approval')
for p in sorted((S / 'pr011-epa-destination-observation-20260911').iterdir()):
    assert p.is_file()
    retain('epa-destination/' + p.name + ('' if p.name.endswith('.gz') else '.gz'), p, 'actual EPA documentation redirect/resource-role observation')
for name in ['verification/research-program/bootstrap/pr086-current-input-review-20260911/metadata-correction.json', 'verification/research-program/bootstrap/pr008-source-capture-correction-20260911/metadata-correction.json', 'verification/research-program/bootstrap/gate-980895d-artifact-correction/correction.json']:
    retain('candidate-corrections/' + name.split('/')[-2] + '.json.gz', C / name, candidate + ':' + name)

gate_summary = {'format': 'ushso.corrected-components-gate-summary.v1', 'recorded_at': now(), 'head': candidate, 'tree': gate['candidate']['tree_sha'], 'run_id': gate['run_id'], 'classification': gate['classification'], 'verdict': gate['verdict'], 'outcome': outcome, 'duration_seconds': gate['duration_seconds'], 'gate_receipt_sha256': sha(gate_raw), 'stages': [{'name': x['name'], 'status': x['status'], 'attempts': len(x.get('attempts', []))} for x in gate['stages']], 'build_attempts': sum(len(x.get('attempts', [])) for x in gate['stages'] if x['kind'] == 'build'), 'first_pass_failures': gate['first_pass_failures'], 'peer_metadata_review_pending': True, 'hosted_ci_pending': True, 'publication_pending': True, 'root_integration_unchanged': True, 'accepted': False, 'requirements_accepted': []}
(D / 'gate-summary.json').write_text(json.dumps(gate_summary, indent=2) + '\n')

old_log = 'verification/research-program/bootstrap/pr008-review-e433eff/pr008-controller-worktree-create.json'
new_log = old_log.removesuffix('.json') + '.log'
review_index = 'verification/research-program/bootstrap/pr008-review-e433eff/index.json'
assert (R / old_log).read_bytes() == (C / new_log).read_bytes()
root_prior_index = (R / review_index).read_bytes()
expected_index = json.loads(root_prior_index)
next(a for a in expected_index['artifacts'] if a['path'] == old_log)['path'] = new_log
assert expected_index == json.loads((C / review_index).read_text())
retain('prior-root-e433eff-index.json.gz', root_prior_index, base + ':' + review_index)
(R / old_log).rename(R / new_log)
(R / review_index).write_bytes((C / review_index).read_bytes())

ledger_path = R / 'docs/research-program/execution-ledger.json'
ledger = json.loads(ledger_path.read_text())
retain('prior-root-ledger.json.gz', ledger_path, base + ':docs/research-program/execution-ledger.json')
controller = ledger['controller']
controller.setdefault('provider_dispatch_boundary_history', []).append(controller.get('provider_dispatch_boundary'))
provider_observation = json.loads((S / 'pr010-grok-scope-auto-review-rejection.json').read_text())
controller['provider_dispatch_boundary'] = {'observed_at': provider_observation['observed_at'], 'state': 'automatic_disclosure_review_rejected_before_dispatch', 'prompt_dispatched': False, 'provider_started': False, 'readiness': provider_observation['readiness'], 'evidence': directory + '/controller/pr010-grok-scope-auto-review-rejection.json.gz', 'next_action': 'Await the pending explicit Grok payload-disclosure authorization before any retry. The earlier 3.4.2 runtime failure is historical.'}
controller['current_review'] = directory + '/index.json'
controller['latest_publication_preparation'] = {'candidate': candidate, 'status': 'local_payload_scans_complete_publication_blocked_by_automatic_review', 'credential_findings_after_disposition': 0, 'provider_or_publisher_started': False, 'next_action': 'Await the existing explicit public ajhcs/ushso payload-and-destination authorization before publishing any prepared branch or draft update.'}
controller['previous_active_assignment_observation'] = controller.get('active_assignments')
controller['active_assignments'] = []
controller['current_active_corrections'] = []
controller['next_component_candidate'] = {'head': candidate, 'tree': gate['candidate']['tree_sha'], 'branch': 'codex/ushso-pr006-pr008-combined-20260911', 'worktree': str(C), 'components': {'PR-006': '8a9b921fa4be059624606116ed5ad33c238bb9ab', 'PR-008': '911aff5588ea59b12b81b58f1d5e07ce09a987d3', 'PR-086': '8cc74ed2ffbaab5b6b009770930dbf0e6fef0f3d'}, 'status': 'local_gate_passed_peer_review_and_hosted_ci_pending' if passed else 'local_gate_failed_changes_requested', 'evidence': directory + '/index.json', 'gate': directory + '/gate-summary.json', 'peer_review_request': directory + '/controller/controller-metadata-peer-review-e3af8dd.json.gz', 'accepted': False, 'root_code_integrated': False}
controller['latest_corrected_component_gate'] = gate_summary
controller['pending_controller_metadata_reviews'] = {'candidate': candidate, 'commits': ['fdeed22bc052dbc88544001a2270fe79df32ddc9', '980895daec306d15181de7291ed28a4330d57b6a', candidate], 'status': 'blocked_by_native_agent_limit_and_pending_grok_disclosure_authorization', 'request': directory + '/controller/controller-metadata-peer-review-e3af8dd.json.gz'}
for t in ledger['tasks']:
    if t['pr_id'] in ['PR-006', 'PR-008']:
        for blocker in t['blockers']:
            if isinstance(blocker, dict) and blocker.get('id') == 'JOINT-GATE-PENDING':
                blocker['id'] = 'JOINT-INTEGRATION-PENDING'
                blocker['detail'] = 'Exact candidate local gate ' + outcome + '; separate controller-metadata review and actual hosted CI remain pending.'
        t['latest_joint_candidate'] = candidate
        t['latest_joint_gate'] = directory + '/gate-summary.json'
    if t['pr_id'] == 'PR-086':
        t['current_input_correction'].update({'status': 'behavior_verified_pending_metadata_peer_review_and_hosted_ci' if passed else 'behavior_verified_combined_gate_failed', 'producer_final_head': '8cc74ed2ffbaab5b6b009770930dbf0e6fef0f3d', 'candidate': candidate, 'evidence': directory + '/index.json', 'local_gate_classification': gate['classification'], 'local_gate_verdict': gate['verdict'], 'separate_metadata_review_pending': True, 'next_action': 'Complete the prepared separate metadata review and hosted CI before integrating the continuation. Original accepted PR086 base/head/binding remain unchanged in this root checkout.'})
ledger['updated_at'] = now()
ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')

proposal_path = R / 'docs/research-program/supplemental-source-proposals.json'
proposals = json.loads(proposal_path.read_text())
retain('prior-supplemental-register.json.gz', proposal_path, base + ':docs/research-program/supplemental-source-proposals.json')
proposals['follow_up_observations'] = {'recorded_at': now(), 'scope': 'The original top-level documentation-review fields and dates above describe the initial 2026-09-10 review. These later bounded observations do not select a candidate or qualify a recipe, payload schema, join, legal interpretation, or scientific use.', 'endpoint_requests_performed': 2, 'browser_cors_requests_performed': 0, 'review': directory + '/supplemental-access/qualification-review.json.gz', 'usa_spending': 'One reference-agency response returned 111 entries, including HHS. Health-related awards and organizational linkage remain unverified.', 'federal_register': 'One request for per_page=1 returned 20 document-metadata entries. Retain this bound mismatch; cause unresolved. No bypass or repeated request was used.', 'epa': 'One documented developer URL redirected once with HTTP301 to /developers/widgets, then returned HTTP200 HTML titled Widgets | US EPA. This is a resource-role mismatch, not an API payload test.', 'epa_evidence': directory + '/epa-destination/observation.json.gz', 'requirements_accepted': [], 'frozen_cohorts_changed': False}
proposal_path.write_text(json.dumps(proposals, indent=2) + '\n')
intake_path = R / 'docs/research-program/supplemental-source-intake.md'
text = intake_path.read_text()
text = text.replace('the current review encountered an access-check page.', 'the initial documentation review encountered an access-check page; a later bounded observation is recorded below.')
text += '\n## Follow-up observations on September 11, 2026\n\nThe [retained bounded-access review](../../' + directory + '/supplemental-access/qualification-review.json.gz) records one server-side request per API. USAspending returned 111 reference-agency records including HHS. Federal Register returned 20 document-metadata records despite `per_page=1`; the request therefore remains unsuitable as a bounded recipe until that behavior is explained. The checks sent no credentials, cookies or browser Origin header. JSON access does not establish the proposed healthcare use, complete schemas, joins or scientific fitness.\n\nThe [EPA observation](../../' + directory + '/epa-destination/observation.json.gz) retains the single 301 redirect and complete 200 HTML response at the Widgets page. This advances the dated evidence available to PR011/076; it does not implement their validator or an actionable API recipe. The initial directory review and all frozen cohorts remain preserved.\n'
intake_path.write_text(text)
for label, command in [('plan-validation', ['python3', 'docs/master-plan/2026-09-10/validate.py']), ('external-authorization-artifacts', ['/home/plumbob/.nvm/versions/node/v24.14.0/bin/node', '--test', 'verification/external-authorization/v1.1.0/tests/register.test.mjs'])]:
    result = subprocess.run(command, capture_output=True, timeout=120)
    retain('root-checks/' + label + '.stdout.log.gz', result.stdout, 'actual root metadata check')
    retain('root-checks/' + label + '.stderr.log.gz', result.stderr, 'actual root metadata check')
    retain('root-checks/' + label + '.json.gz', (json.dumps({'argv': command, 'exit_code': result.returncode, 'recorded_at': now()}, indent=2) + '\n').encode(), 'actual root metadata check receipt')
    assert result.returncode == 0, label
index = {'format': 'ushso.independent-review-portable-index.v1', 'recorded_at': now(), 'candidate': candidate, 'candidate_tree': gate['candidate']['tree_sha'], 'artifacts': artifacts, 'metadata_files': [{'path': directory + '/gate-summary.json', 'bytes': (D / 'gate-summary.json').stat().st_size, 'sha256': sha((D / 'gate-summary.json').read_bytes())}], 'peer_metadata_review_pending': True, 'accepted': False}
(D / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for p, expected in json.loads((S / 'corrected-components-preflight-e3af8dd/receipt.json').read_text())['frozen_sha256'].items():
    if p != 'package-lock.json':
        assert sha((R / p).read_bytes()) == expected
allowed = ['docs/research-program/execution-ledger.json', 'docs/research-program/supplemental-source-proposals.json', 'docs/research-program/supplemental-source-intake.md', old_log, review_index]
assert set(git('diff', '--name-only').splitlines()) == set(allowed)
subprocess.run(['git', 'diff', '--check'], check=True)
subprocess.run(['git', 'add', '--', *allowed, directory], check=True)
subprocess.run(['git', 'add', '-f', '--', new_log], check=True)
subprocess.run(['git', 'commit', '-m', 'Record corrected component gate and bounded source observations'], check=True)
assert not git('status', '--porcelain')
result = {'format': 'ushso.corrected-components-root-progress.v1', 'recorded_at': now(), 'root_head': git('rev-parse', 'HEAD'), 'root_tree': git('rev-parse', 'HEAD^{tree}'), 'candidate': candidate, 'candidate_tree': gate['candidate']['tree_sha'], 'gate_classification': gate['classification'], 'gate_verdict': gate['verdict'], 'gate_outcome': outcome, 'evidence_index': directory + '/index.json', 'index_sha256': sha((D / 'index.json').read_bytes()), 'root_code_integrated': False, 'published': False, 'deployed': False, 'accepted': False, 'requirements_accepted': []}
p = S / 'corrected-components-root-progress-e3af8dd.json'
assert not p.exists()
p.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
