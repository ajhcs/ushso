from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, time

R=Path.cwd(); S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910'); D=S/'pr006-controller-review-7e58195'
node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
task='ushso-pr006-final-review-20260911'
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
head='7e5819515b2f625d63de82efdd13571af096fbf6'; base='c58787297fc543b3fdd31736e1c96ed1af29ffd8'
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')=='554137e2c615ef74bb9bc0cf4a1690141e003cc0'
assert not git('status','--porcelain') and not D.exists()
D.mkdir()
packet=json.loads((S/'pr006-native-dispatch-packet.json').read_text())
assert sha((S/'pr006-native-dispatch-packet.json').read_bytes())=='416e75a5fcccd8d63b7d494ba50915c207b9f06763fbc876d36214ab84367c89'
changed=git('diff','--name-only',base,head).splitlines()
assert all(any(p==owned or owned.endswith('/') and p.startswith(owned) for owned in packet['owned_paths']) for p in changed)
frozen=['packages/retrieval/schemas/discovery-result.schema.json','apps/web/src/types/discovery.ts','tests/fixtures/direct-base-control.mjs','packages/retrieval/fixtures/retrieval-core-before-lexical-index.txt','evaluation/research-program/cohorts.json','evaluation/research-program/tasks.json','docs/research-program/acceptance.md']
frozen_hashes={}
for p in frozen:
    old=subprocess.check_output(['git','show',base+':'+p]); new=(R/p).read_bytes(); assert old==new,p
    frozen_hashes[p]=sha(new)
handoff_path=R/'docs/research-program/handoffs/PR-006.json'; handoff=json.loads(handoff_path.read_text()); artifacts=[]
for a in handoff['artifacts']:
    b=(R/a['path']).read_bytes(); assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path']; artifacts.append(a)
receipts=[]
def run(label,args):
    at=datetime.now(timezone.utc).isoformat(); start=time.monotonic()
    result=subprocess.run(args,capture_output=True)
    streams={}
    for kind,b in [('stdout',result.stdout),('stderr',result.stderr)]:
        name=label+'.'+kind+'.log'; (D/name).write_bytes(b); streams[kind]={'path':name,'bytes':len(b),'sha256':sha(b)}
    receipts.append({'label':label,'command':args,'started_at':at,'duration_seconds':time.monotonic()-start,'exit_code':result.returncode,'streams':streams})
    print(json.dumps({'label':label,'exit_code':result.returncode}),flush=True)
    return result

run('controller-engine',[node,str(S/'pr006-controller-facet-cases.mjs'),str(R)])
run('controller-ui',[node,str(S/'pr006-controller-ui-cases.mjs'),str(R),str(D/'ui')])
run('controller-browser',[node,str(S/'pr006-controller-browser-v6.mjs'),str(R),str(D/'browser')])
commands=[('lexical',[node,'--test','packages/retrieval/tests/lexical-index.test.mjs']),('direct-base',[node,'--test','tests/direct-base-regression.test.mjs']),('isolation-facets',[node,'--test','tests/research-program/isolation-and-facets.test.mjs']),('web-typecheck',['npm','run','typecheck','--workspace','@ushso/observatory-web']),('web-full',['npm','run','test:web']),('retrieval-full',['npm','run','test:retrieval']),('handoff',[node,'scripts/research-program/check-handoff.mjs','docs/research-program/handoffs/PR-006.json'])]
for label,args in commands:run(label,args)
assert not git('status','--porcelain') and git('rev-parse','HEAD')==head
scripts=['pr006-controller-facet-cases.mjs','pr006-controller-ui-cases.mjs','pr006-controller-browser-v6.mjs','pr006-controller-browser-entry.tsx']
receipt={'format':'ushso.pr006.independent-controller-review.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'controller':'Astra/root','head':head,'tree':git('rev-parse','HEAD^{tree}'),'base':base,'packet_sha256':sha((S/'pr006-native-dispatch-packet.json').read_bytes()),'handoff_sha256':sha(handoff_path.read_bytes()),'changed_paths':changed,'frozen_sha256':frozen_hashes,'artifact_bindings_checked':len(artifacts),'artifact_binding_errors':[],'scripts':{p:sha((S/p).read_bytes()) for p in scripts},'commands':receipts,'checks_passed':sum(r['exit_code']==0 for r in receipts[3:]),'checks_failed':sum(r['exit_code']!=0 for r in receipts[3:]),'acceptance':'pending controller inspection of independent case results and source review','scope':'Exact corrected immutable producer head. Browser v6 corrects the documented v4 escaping bug and was negatively verified against the preserved original head before this run. Browser tests use real Chrome, React, providers and engine with controller synthetic offline records; not participants, scientific qualification or publisher payload access.'}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for label,p in [('engine',D/'controller-engine.stdout.log'),('ui',D/'ui/receipt.json'),('browser',D/'browser/receipt.json')]:
    if p.exists():
        try:
            data=json.loads(p.read_text()); print(json.dumps({'probe':label,'passed':data['passed'],'failed':data['failed'],'failures':[c for c in data['cases'] if c.get('status')=='failed' or c.get('passed') is False]}),flush=True)
        except (KeyError,json.JSONDecodeError): print(json.dumps({'probe':label,'unparsed_result':str(p)}),flush=True)
print(json.dumps({'receipt':str(D/'receipt.json'),'checks_passed':receipt['checks_passed'],'checks_failed':receipt['checks_failed'],'artifact_bindings_checked':len(artifacts)}),flush=True)
