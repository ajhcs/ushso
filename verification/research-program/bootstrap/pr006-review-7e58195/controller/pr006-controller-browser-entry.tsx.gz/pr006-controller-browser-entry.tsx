// Local controller harness only. The actual pages and providers are imported
// from the reviewed worktree. Fixture requests are not publisher access checks.
import { useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom'
import { DiscoveryProviderBoundary } from './apps/web/src/providers/DiscoveryProviderContext'
import { ApiDiscoveryProvider, FixtureDiscoveryProvider } from './apps/web/src/providers/discoveryProvider'
import { SearchResultsPage } from './apps/web/src/pages/SearchResultsPage'
import { SourcesPage } from './apps/web/src/pages/SourcesPage'
import './apps/web/src/styles.css'

async function mount() {
  const parameters = new URLSearchParams(window.location.search)
  const scenario = parameters.get('scenario') ?? 'mixed'
  const mode = parameters.get('provider') ?? 'api'
  const initial = parameters.get('route') ?? '/search?q=registry'
  const audit = { mode, scenario, requests: [] as unknown[], responses: [] as unknown[], route: initial }
  ;(window as any).__ushsoControllerAudit = audit
  const underlying = mode === 'fixture'
    ? new FixtureDiscoveryProvider(async () => (await fetch(`/fixture/${scenario}.json`)).json(), 'accepted')
    : new ApiDiscoveryProvider(`/api/${scenario}/discover`)
  const provider = {
    kind: underlying.kind,
    promotionState: underlying.promotionState,
    async discover(query: any, options: any) {
      audit.requests.push({ method: 'discover', query, traversal: options?.traversal })
      const response = await underlying.discover(query, options)
      audit.responses.push(structuredClone(response))
      return response
    },
    async browse(options: any) {
      audit.requests.push({ method: 'browse', traversal: options?.traversal })
      const response = await underlying.browse(options)
      audit.responses.push(structuredClone(response))
      return response
    },
    async dataset(id: string, options: any) {
      audit.requests.push({ method: 'dataset', id })
      const response = await underlying.dataset(id, options)
      audit.responses.push(structuredClone(response))
      return response
    },
  }
  function RouteObservation() {
    const location = useLocation()
    useEffect(() => { audit.route = location.pathname + location.search }, [location])
    return null
  }
  const element = document.getElementById('root')
  if (!element) throw new Error('CONTROLLER_ROOT_MISSING')
  createRoot(element).render(
    <MemoryRouter initialEntries={[initial]}>
      <DiscoveryProviderBoundary provider={provider}>
        <RouteObservation />
        <Routes>
          <Route path="/search" element={<SearchResultsPage />} />
          <Route path="/sources" element={<SourcesPage />} />
        </Routes>
      </DiscoveryProviderBoundary>
    </MemoryRouter>,
  )
}
mount().catch(error => {
  ;(window as any).__ushsoControllerError = String(error?.stack ?? error)
  document.getElementById('root')!.textContent = String(error)
})
