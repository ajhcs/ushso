from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, time

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
D = S / 'pr006-controller-browser-corrected-5d8a8dd-v6'
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', 'ushso-pr006-controller-review-20260911', '--repo', str(R), '--require-writer'], check=True)
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
assert git('rev-parse', 'HEAD') == '5d8a8dd6d2e9d60d5b18fa1f69a09533c7e0d9e9' and not git('status', '--porcelain')
assert not D.exists()
at = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
args = ['/home/plumbob/.nvm/versions/node/v24.14.0/bin/node', str(S / 'pr006-controller-browser-v6.mjs'), str(R), str(D)]
r = subprocess.run(args, capture_output=True)
D.mkdir(exist_ok=True)
(D / 'command.stdout').write_bytes(r.stdout)
(D / 'command.stderr').write_bytes(r.stderr)
receipt = {'format': 'ushso.controller-browser-extended-command.v1', 'head': git('rev-parse', 'HEAD'), 'started_at': at, 'duration_seconds': time.monotonic() - clock, 'command': args, 'exit_code': r.returncode, 'scripts': {f: hashlib.sha256((S / f).read_bytes()).hexdigest() for f in ['pr006-controller-browser-v6.mjs', 'pr006-controller-browser-entry.tsx']}, 'streams': {f: {'bytes': len((D / f).read_bytes()), 'sha256': hashlib.sha256((D / f).read_bytes()).hexdigest()} for f in ['command.stdout', 'command.stderr']}, 'interpretation': 'Expanded Sources and mobile evaluation on the immutable reviewed PR006 head; not overall PR006 acceptance.'}
(D / 'command-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert not git('status', '--porcelain')
if (D / 'receipt.json').exists():
    report = json.loads((D / 'receipt.json').read_text())
    print(json.dumps({'exit_code': r.returncode, 'passed': report['passed'], 'failed': report['failed'], 'cases': report['cases'], 'receipt': str(D / 'command-receipt.json')}))
else:
    print(json.dumps({'exit_code': r.returncode, 'stderr_tail': r.stderr.decode()[-4000:], 'receipt': str(D / 'command-receipt.json')}))
