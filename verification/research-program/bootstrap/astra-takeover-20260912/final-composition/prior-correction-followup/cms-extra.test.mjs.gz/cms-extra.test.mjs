import test from 'node:test';
import assert from 'node:assert/strict';
import { hash, extractVersionedVariables, verifyVariableIdentity } from '/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911/scripts/research/source-extractors.mjs';

function claimFor(entry, options = {}) {
  const data = { variables: [entry] }, text = JSON.stringify(data);
  const capture = { data, text, url: 'https://example.test/cms-followup.json', sha256: hash(text), status: 'captured', evidence_id: 'evidence:astra:followup-document' };
  const [claim] = extractVersionedVariables(data, 'cms', { ...options, capture });
  assert.equal(verifyVariableIdentity(claim, capture, options), true);
  assert.equal(claim.variable_id, null);
  assert.equal(claim.publication_authorized, false);
  assert.equal(claim.promotion_eligible, false);
  return claim;
}
test('CMS mapping evidence without an explicit wire-name field remains unresolved', () => {
  const claim = claimFor({ name: 'FIELD', mapping: { state: 'exact', documented_name: 'FIELD', wire_name: 'FIELD', candidate_wire_names: [], evidence_ids: ['evidence:astra:mapping'] } });
  assert.equal(claim.mapping.state, 'unmatched'); assert.equal(claim.wire_name, null);
});
test('CMS reviewed-alias mappings without evidence remain unresolved', () => {
  const claim = claimFor({ name: 'Documented field', wire_name: 'API_FIELD', mapping: { state: 'reviewed_alias', documented_name: 'Documented field', wire_name: 'API_FIELD', candidate_wire_names: ['API_FIELD'], evidence_ids: [] } });
  assert.equal(claim.mapping.state, 'unmatched'); assert.equal(claim.wire_name, null);
});
test('CMS explicit mapping callback retains an evidenced alias under replay', () => {
  const mappingFor = () => ({ state: 'reviewed_alias', documented_name: 'Documented field', wire_name: 'API_FIELD', candidate_wire_names: ['API_FIELD'], evidence_ids: ['evidence:astra:mapping'] });
  const claim = claimFor({ name: 'Documented field', wire_name: 'API_FIELD' }, { mappingFor });
  assert.equal(claim.mapping.state, 'reviewed_alias'); assert.equal(claim.wire_name, 'API_FIELD');
});
