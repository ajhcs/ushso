import { it, expect } from '/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911/node_modules/vitest/dist/index.js';
import { readFileSync } from 'node:fs';
import { FixtureDiscoveryProvider } from '/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911/apps/web/src/providers/discoveryProvider.ts';
import { createRetrievalEngine } from '/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911/packages/retrieval/tools/retrieval-core-v1.2.mjs';

const base = '/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911';
const accepted = JSON.parse(readFileSync(base+'/packages/retrieval/fixtures/responses/q-pa-hospital-finance-utilization.json', 'utf8'));
const vocabulary = JSON.parse(readFileSync(base+'/packages/retrieval/fixtures/controlled-vocabulary.json', 'utf8'));
function scenario() {
  const records = [
    ['US-PA', 'topic:claims', 'facility_period', 'public_catalog'],
    ['US-CA', 'topic-claims', 'facility-period', 'public_catalog'],
    ['US-NY', 'topic:quality', 'county_equivalent', 'public_direct'],
  ].map(([geography, topic, unit, access], index) => {
    const r = structuredClone(accepted.results[0].record);
    r.record_id = r.identity.asset.asset_id = 'fixture:astra:followup:'+index;
    r.identity.asset.name = r.title = 'Hospital metadata '+index;
    r.geography.coverage_level = 'state'; r.geography.jurisdictions = [geography];
    r.access.status = access; r.unit_of_analysis = [unit];
    r.capabilities.topics = [{ ...r.capabilities.topics[0], id: topic, label: 'Documented topic' }];
    r.capabilities.use_cases = [];
    return r;
  });
  const engine = createRetrievalEngine({ records, vocabulary, searchDocuments: null, joinRoutes: [], namedSourceRegistry: { sources: [] }, corpus: { corpus_id: 'astra-followup', corpus_version: '1.0.0', record_count: records.length, join_route_count: 0, generation: 'astra-followup' }, catalogValidation: { valid: records, invalid: [] } });
  const response = engine.browse({ page_size: 10 });
  return { engine, records, response, provider: new FixtureDiscoveryProvider(() => response) };
}
const ids = result => result.results.map(item => item.record_id).sort();
function replayBoth(engine, result) {
  expect(result.query.filters.facet_filters).toEqual(result.receipt.filters.facet_filters);
  for (const filters of [result.query.filters.facet_filters, result.receipt.filters.facet_filters]) {
    expect(ids(engine.browse({ page_size: 10, facet_filters: filters }))).toEqual(ids(result));
  }
}
for (const filter of ['data-category:topic-claims', 'reporting-unit:facility-period']) {
  it('replays each exact wire ID selected through legacy normalization: '+filter, async () => {
    const { engine, records, provider } = scenario();
    const result = await provider.browse({ traversal: { filters: [filter] } });
    expect(ids(result)).toEqual(records.slice(0,2).map(r => r.record_id));
    replayBoth(engine, result);
  });
}
it('replays same-dimension canonical/legacy OR with cross-dimension AND', async () => {
  const { engine, records, provider, response } = scenario();
  const result = await provider.discover({ question: response.query.question, facet_filters: { capability: ['topic:quality'] } }, { traversal: { filters: ['data-category:topic-claims', 'access:catalog-metadata-only'] } });
  expect(ids(result)).toEqual(records.slice(0,2).map(r => r.record_id));
  replayBoth(engine, result);
});
it('preserves and replays zero-result canonical near-misses', async () => {
  const { engine, provider, response } = scenario();
  for (const filters of [{ geography: ['pennsylvania'] }, { access_status: ['catalog-metadata-only'] }, { capability: ['Topic:Claims'] }, { unit_of_analysis: ['Facility_Period'] }]) {
    const result = await provider.discover({ question: response.query.question, facet_filters: filters });
    expect(ids(result)).toEqual([]);
    expect(result.query.filters.facet_filters).toEqual(filters);
    replayBoth(engine, result);
  }
});
it('keeps a legacy filter replayable when another dimension yields no records', async () => {
  const { engine, provider } = scenario();
  const result = await provider.browse({ traversal: { filters: ['data-category:topic-claims', 'reporting-unit:facility-period', 'geography:US-TX'] } });
  expect(ids(result)).toEqual([]);
  replayBoth(engine, result);
});
