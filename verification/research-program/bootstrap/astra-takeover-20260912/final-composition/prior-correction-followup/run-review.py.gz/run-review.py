import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).parent
C = Path('/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr006-pr008-combined-20260911')
OLD = Path('/mnt/d/tmp/plumbob/ushso-astra-corrections-review-20260912')
FILES = ['apps/web/src/providers/discoveryProvider.ts', 'apps/web/src/providers/discoveryProvider.test.ts', 'scripts/research/source-extractors.mjs', 'tests/cms-layout.test.mjs']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=C)

def snapshot():
    return {'base_head': git('rev-parse', 'HEAD').decode().strip(),
            'base_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git('status', '--porcelain').decode(),
            'patch_sha256': sha(git('diff', '--binary', '--full-index', 'HEAD')),
            'files': {p: {'bytes': len((C/p).read_bytes()), 'sha256': sha((C/p).read_bytes())} for p in FILES}}

def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2) + '\n')

mode = sys.argv[1]
if mode == 'capture':
    assert sorted(git('diff', '--name-only', 'HEAD').decode().splitlines()) == sorted(FILES)
    assert not git('diff', '--cached', '--name-only').strip()
    write('candidate-before.json', snapshot())
    (OUT/'correction.patch').write_bytes(git('diff', '--binary', '--full-index', 'HEAD'))
    for p in FILES:
        dest = OUT/'reviewed-bytes'/p
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((C/p).read_bytes())
    print(json.dumps({'snapshot': str(OUT/'candidate-before.json'), 'patch_sha256': snapshot()['patch_sha256']}))
    sys.exit(0)

before = json.loads((OUT/'candidate-before.json').read_text())
assert snapshot() == before, 'Candidate changed before review checks'
env = dict(os.environ, USHSO_LIVE_SOURCE_REQUESTS='forbidden', USHSO_ALLOW_LIVE_SOURCE_REQUESTS='0', USHSO_NETWORK_POLICY='authoritative-sources-forbidden', USHSO_ALLOW_RECEIPT_WRITES='0', USHSO_RECEIPT_MODE='verify-only')
commands = {
    'node': [(name, ['node', str(path)]) for name, path in [
        ('original-data', OLD/'data-probes.test.mjs'),
        ('cms-boundary', OLD/'cms-boundary.test.mjs'),
        ('cms-layout', C/'tests/cms-layout.test.mjs'),
        ('source-extractors', C/'tests/research-extractors.test.mjs'),
        ('variable-identity', C/'tests/research-program/variable-identity.test.mjs'),
        ('isolation-facets', C/'tests/research-program/isolation-and-facets.test.mjs'),
        ('subject-shortcircuit', C/'tests/subject-shortcircuit.test.mjs'),
        ('machine-variable-identity', C/'contracts/machine-toolkit/v1.2.0/tests/variable-identity.test.mjs'),
        ('cms-extra', OUT/'cms-extra.test.mjs'),
    ]],
    'web-extra': [('web-extra-corrected-fixture', ['node', 'node_modules/vitest/vitest.mjs', 'run', '--config', str(OUT/'extra-vitest.config.mjs'), '--configLoader', 'native', '--no-cache'])],
    'web': [('web-regressions-and-probes', ['node', 'node_modules/vitest/vitest.mjs', 'run', '--config', str(OUT/'vitest.config.mjs'), '--configLoader', 'native', '--no-cache']),
            ('web-typecheck', ['node_modules/.bin/tsc', '-p', 'apps/web/tsconfig.app.json', '--noEmit', '--tsBuildInfoFile', str(OUT/'typecheck.tsbuildinfo'), '--pretty', 'false'])],
}[mode]
results = []
for name, command in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    out, err = OUT/(name+'.stdout.log'), OUT/(name+'.stderr.log')
    with out.open('xb') as stdout, err.open('xb') as stderr:
        run = subprocess.run(command, cwd=C, env=env, stdout=stdout, stderr=stderr, timeout=120)
    item = {'name': name, 'command': command, 'cwd': str(C), 'node_version': subprocess.check_output(['node', '--version'], text=True).strip(), 'started_at': started, 'ended_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'duration_seconds': round(time.monotonic()-tick, 3), 'exit_code': run.returncode}
    for label, path in [('stdout', out), ('stderr', err)]:
        data = path.read_bytes()
        item[label] = {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
    results.append(item)
    write(mode+'-checks.json', results)
    print(json.dumps({'name': name, 'exit_code': run.returncode, 'duration_seconds': item['duration_seconds']}), flush=True)
assert snapshot() == before, 'Candidate changed during review checks'
write(mode+'-candidate-after.json', snapshot())
