**Astra follow-up review: all three P2 corrections verified on the working patch; no further findings in this scope.**

The reviewed subject is an uncommitted four-file patch over `e3af8dda1720efd5d29fd1a65683d0f18a412e94`, with patch SHA-256 `925de6172894e875072d27c0fbc733bcb91b4fc2b4ee74d78cf4c96a224c14b4`. The corrected source and regression files match their respective PR-006/008 producer copies. The candidate stayed unchanged through all checks. This closes the demonstrated code findings on these bytes; final candidate acceptance remains pending.

| Correction finding | Independent result |
|---|---|
| ASTRA-R2-006-01 — preserve legacy sections | Resolved. Raw `data-category` and `reporting-unit` sections reach the legacy matcher. Canonical sections group same-dimension OR and cross-dimension AND without changing canonical request matching. |
| ASTRA-R2-006-02 — record replayable filters | Resolved. Pennsylvania and catalog-access aliases record `US-PA` and `public_catalog`. Capability/unit aliases record the matching exact wire IDs. Both query and embedded receipt filters replay the displayed records in the retained scenarios. Canonical near-misses remain exact, including zero-result cases. |
| ASTRA-R2-008-01 — require CMS mapping evidence | Resolved. Missing mapping evidence or a missing explicit wire-name field leaves the demonstrated CMS claims unmatched with null wire names. Evidence-bearing exact and reviewed-alias controls, including a supplied mapping callback, work under replay. CDC/Census native-key behavior remains covered by the affected tests. |

Independent checks on Node 24.14.0:

| Check | Result |
|---|---:|
| Existing affected Node tests | 53 passed |
| Existing focused frontend tests | 37 passed |
| Original review cases | 2 data + 3 web passed |
| Correction-review boundary cases | 4 CMS + 6 web passed |
| Additional follow-up cases | 3 CMS + 5 web passed after the reviewer fixture correction described below |
| Frontend TypeScript check | Passed, with build-info output confined to review scratch |

Additional cases cover two distinct wire IDs that normalize to the same legacy capability/unit, replay of both recorded filter objects, mixed canonical/legacy filters, canonical near-misses, zero-result replay, mapping evidence without an explicit CMS wire field, an alias with empty evidence, and a supported mapping callback. These are bounded fixture checks; they do not establish whole-corpus or release acceptance.

The first web command returned exit 1: its 37 existing tests and nine prior reviewer cases passed, while the five added reviewer cases hit an invalid synthetic record before reaching their assertions. I had changed that record to restricted access while retaining a public machine-actionable retrieval recipe. I corrected the review fixture to use `public_direct` as the contrasting access status, then reran only those five cases; all passed. The original fixture, failed command logs and successful focused rerun are retained. No product code was changed to resolve that fixture error.

Evidence: [Node checks](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/node-checks.json), [initial web and typecheck results](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/web-checks.json), [five-case rerun](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/web-extra-checks.json), [candidate file hashes](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/candidate-before.json), and [retained patch](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/correction.patch). The candidate-before and three candidate-after snapshots agree. Command-log hashes were verified. All 36 original-review artifacts and 38 correction-review artifacts still match their existing manifests, recorded in the [prior-evidence check](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/prior-review-artifact-verification.json).

The old `e3af8dd` full gate identifies the uncorrected bytes. No full gate, production build, hosted CI or handoff validation was rerun in this follow-up. Producer evidence and handoff/task bindings still need refresh for the corrected identity. The earlier recorded stale-handoff failures are not converted into passes by these source tests.

| State | Verified observation |
|---|---|
| PR-006 merge SHA | `null` |
| PR-008 merge SHA | `null` |
| Integration HEAD | `7c7ad7f9577507fc294438025ec8c60145e8cb33` |
| Integration tree | `5394d4d45544d61483718789d57aa593bd401361` |
| PR-009 producer HEAD | `80f781d60e970272a0afdacf8985404afa7decec` |
| PR-009 producer tree | `d5c282a2b0b3da51bdebee1af63858320db4ff22` |

Integration and PR-009 remain clean and unchanged. The combined candidate has exactly the four reported uncommitted files; PR-006 and PR-008 have their corresponding two-file corrections. I changed only review/report artifacts, with no candidate, producer, repository handoff, task-binding, execution-ledger or Git metadata writes. No acceptance, integration, publication, merge, deployment or production change occurred.

The next step is producer finalization: refresh the required evidence and bindings, create the final immutable corrected candidate, then independently check that identity and run its applicable gate. Existing focused results can inform that review but do not qualify a different final candidate. Publication, hosted CI and merge retain their authorization boundaries.

PR-009 remains deferred until PR-008 has actually been accepted into integration. Its prepared producer candidate now exists, so the September 11 progress report's description of PR-009 as unimplemented is historical. After the accepted integration exists, select/rebase the successor onto that actual SHA, bind real dependency merge identities and validate against the live ledger. Retain `ushso-canonical-json.v1`; exclude producer `911aff5` from dependency merge identities. This review gives no PR-009 implementation verdict and starts no PR-010 work. R01–R16 and release qualification remain unaccepted.

[Machine-readable review](/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/review.json).
