import original from '/mnt/d/tmp/plumbob/ushso-astra-review-e3af8dd-20260912/vitest.config.mjs';
export default {
  ...original,
  cacheDir: '/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/vite-cache',
  test: {
    ...original.test,
    include: [...original.test.include,
      '/mnt/d/tmp/plumbob/ushso-astra-corrections-review-20260912/web-probes.test.ts',
      '/mnt/d/tmp/plumbob/ushso-astra-corrections-review-20260912/web-boundary.test.ts',
      '/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/web-extra.test.ts'],
  },
};
