import original from './vitest.config.mjs';
export default {
  ...original,
  test: { ...original.test, include: ['/mnt/d/tmp/plumbob/ushso-astra-correction-followup-20260912/web-extra.test.ts'] },
};
