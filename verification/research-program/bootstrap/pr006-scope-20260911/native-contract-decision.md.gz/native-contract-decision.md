# PR006 native facet contract decision

Reviewer model: Codex, GPT-6

Exact read-only input:

- Repository: `/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr005-pr086-controller-combined-20260911`
- HEAD: `e6da2e2d87c95501e5a1b129989e17bdae3cb882`
- tree: `a9d9bca698ffc403a9ad1b82a8c8328af01146aa`
- Prerequisite integration accepted at `0d730aaf07b89bb16fb66fc224841a2d66c80d49`, with the same tree.
- Scope review read: `/mnt/d/tmp/plumbob/ushso-research-program-20260910/pr006-scope-review-full.md`

## Decision

Keep `observatory-discovery-result.v1.0.0` unchanged. UI-derived availability is sufficient for C0062 if it compares only each current facet count with the current `total_matches`. It can truthfully mark unknown-only geography and uniform `public_catalog` access unavailable with scoped explanations, without claiming global absence, national coverage, or payload access.

The include-unknown flow is feasible:

- Add browser-only `geography:unknown` and `access_status:unknown` controls with no count when the current response omits them.
- Preserve selected tokens independently and render removable selected chips/options even when the current facet response hides them.
- Send existing arrays, preserving same-dimension OR and cross-dimension AND semantics. A known geography plus unknown therefore sends `[known, "unknown"]`; returned counts remain the server’s current-scope counts.
- Never reuse an earlier broader count or synthesize disjunctive counts.

## Owned paths

- `apps/web/src/data/facets.ts`: shared live/fallback canonical facet adapter, labels, scoped availability reasons, and no-count unresolved controls. Derive the five shared dimensions from canonical record fields; do not expose fallback aliases such as `other-states`, `catalog-metadata-only`, or `open-data-api` as live filters.
- `apps/web/src/pages/SearchResultsPage.tsx` and `apps/web/src/pages/SourcesPage.tsx`: consume that adapter.
- `apps/web/src/components/FacetSidebar.tsx` and internal UI types in `apps/web/src/types/catalog.ts`: accessible selected/unavailable states and optional count for synthetic controls.
- `apps/web/src/providers/discoveryProvider.ts`: make the fixture fallback honor facet traversal locally with the same grouping semantics. Without this owner, fallback roundtrips are currently a no-op.
- Add focused tests in `apps/web/src/data/facets.test.ts`, `apps/web/src/providers/discoveryProvider.test.ts`, a new `FacetSidebar.test.tsx`, and page-level facet coverage. Add `tests/research-program/isolation-and-facets.test.mjs` for live engine mixed fixtures and C0061.

Keep `apps/web/src/types/discovery.ts`, the frozen discovery schema, machine routes, and `tests/fixtures/direct-base-control.mjs` unchanged. The research test should reuse PR004’s exact `3434/3430/4` accounting and four CDC IDs/hashes; no migration, description invention, or source-byte edits.

The engine already applies facet filters before pagination and computes counts over the post-filter matching set. The UI must retain that `count_basis` and `collection_scope` meaning. For fallback, counts are limited to the returned fixture scope and must not be presented as complete-corpus counts.

## Label-only retrieval-core follow-up

A narrow edit to `packages/retrieval/tools/retrieval-core-v1.2.mjs` that changes only the existing `facets.sections[].options[].label` string is compatible with the frozen v1.0.0 JSON contract. The schema requires a string label but does not require `label === value`; keeping `value`, `count`, section IDs, filter parsing, collection scope, and response shape unchanged does not add a public field or require a successor schema. It can solve the absent-current-page problem because `facetResponse(matches)` has the complete pre-pagination matching records and can resolve source/capability labels from those records.

It still needs an explicit preservation boundary. `tests/direct-base-regression.test.mjs` currently compares complete JSON from the candidate engine with `tests/fixtures/direct-base-control.mjs`; known source/capability/unknown values in that fixture will differ once labels become readable. Preserve the control file and either make the differential assertion compare canonical values/counts while adding dedicated label assertions, or keep the engine labels unchanged and do all presentation mapping in the web layer. Do not silently rewrite the control, published fixture bytes, algorithm fingerprints, or frozen manifest pins. If the release process treats the retrieval source fingerprint as pinned, any engine edit also needs the normal separately authorized artifact/fingerprint refresh.

Thus the label-only addition is not a schema violation, but it is a retrieval-core ownership and differential-test decision. It must not be combined with availability/reason fields; those remain browser-only under this decision. If external API consumers must receive availability/reason metadata, stop and name a successor such as `observatory-discovery-result.v1.1.0` before editing the contract.
