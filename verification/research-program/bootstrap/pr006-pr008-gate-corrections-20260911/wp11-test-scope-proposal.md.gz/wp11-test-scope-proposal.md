# WP11 current file-set test correction proposal

## Review boundary

This is a read-only proposal against immutable commit
`a30cd7730de04200f7cd3ffb75ca83378c9e9a1d` (tree
`401b7e745ab01f3c7883f3b64180ad9294e27ac0`) in
`/mnt/d/worktrees/plumbob/ushso-research-program-20260910`. I used `git show`
for the source files and retained gate artifacts; I did not execute tests,
change the repository, use the network, or inspect private holdouts.

The retained combined-gate failure is an assertion error in
`tests/wp11-attestation.test.mjs:389`: the builder emits 156 current technical
files, while `SEALED_WP11_FILE_COUNT` is the historical 154-file seal. The
failure does not show historical pin, approval, or wrapper-boundary drift.

An independent tree walk using the declarative
`verification/wp11/v1.3.0/scope-paths.json`, the builder's four broad roots,
and its three explicit root files produces 156 paths. The historical snapshot
contains 154 paths. The only current paths absent from that historical set are:

| path | bytes | current SHA-256 |
| --- | ---: | --- |
| `apps/web/src/components/FacetSidebar.test.tsx` | 2828 | `ae40956749a8efa9f00a783e40ccb91d10103d2a63f79545cfd240963b59286b` |
| `apps/web/src/pages/SourcesPage.test.tsx` | 2541 | `41df78394a9b7825de1d68706a10fd7f83383dbc394655bcbe63302ddc82b0e8` |

The historical set has no path absent from the current builder set. This is
separate from the retained 154-pin content comparison, which reports 21
changed historical inputs. That comparison remains 154 files, and current and
wrapper approvals remain null.

## Narrow test-only correction

Own the correction in the existing
`tests/wp11-attestation.test.mjs`. No new tracked fixture is needed.

1. Add a test-local independent current inventory oracle. Read
   `verification/wp11/v1.3.0/scope-paths.json`, recursively walk these roots:
   `verification/wp11/v1.3.0`, `apps/web/src`,
   `packages/retrieval/tools`, and `packages/retrieval/schemas`, and add
   `verification/successor-support.mjs`, `package.json`, and
   `package-lock.json`. Skip the same directory names the builder excludes,
   but implement the walk locally with `readdir`, rather than importing
   `listFiles` or the builder's `implementationPaths` array. Read every
   resulting file and return a sorted `{ path, bytes, sha256 }` list using the
   existing `sha256` helper.

2. Compare the complete sorted oracle list with
   `draft.technical_evidence.files`, including path, byte length, and hash.
   Check uniqueness and exact set equality before the deep comparison. Replace
   only the line-389 assertion with this comparison and
   `expected.length`; never compare the current list length with
   `SEALED_WP11_FILE_COUNT`. Keep all historical 154-file count, total-byte,
   subject, snapshot, and diff assertions unchanged.

3. Make the current fixture helper seed from the independent baseline list in
   addition to `BUILDER_FIXTURE_EXTRA_FILES`. The retained historical pins do
   not contain the two current additions. In the existing temporary fixture,
   keep the current-file mutation case and add focused builder cases that
   remove `apps/web/src/pages/SourcesPage.test.tsx` or add a temporary file
   under `apps/web/src/components`; the independent comparator must reject
   each result against the unchanged baseline. Separately feed cloned evidence
   containing a duplicate path or altered hash/byte record to the comparator
   and assert rejection. The positive case must match the full baseline
   exactly. The existing historical snapshot
   missing/extra/tampered/substituted/incomplete/duplicate/unsafe cases remain
   historical-blob controls; they do not substitute for these current-set
   controls.

4. Preserve the existing pending assertions in the current draft test:
   `approval === null`, `status === 'pending_authorized_review'`,
   `release_gate_pass === false`, and no historical subject equality. A current
   file-set match is technical evidence only.

## Historical package transition fixture

`readNamedPrePr005CurrentFile` must stop reading today’s workspace for the two
named transition files. Bind both to exact local Git objects:

- `package.json`: `bf46d92b0e4fc91457bd3eb78aa1742ae84038f2:package.json`,
  3666 bytes, SHA-256
  `b6c3469c7b10ecb90114199c18c3ebb293d801b8c8a3521cb25ded2fdba8d05e`.
- `package-lock.json`: `4f90157108a92ce9541c340d5536eac31f24a1d:package-lock.json`,
  134511 bytes, SHA-256
  `37e4a9ec1fba9ab254aa7a596e1a0e3f73919cf5358717dc6e06e0478be6b20c`.

The latter is the exact PR085 CI v14 lock currently represented by
`ALLOWED_PACKAGE_LOCK.pr085_ci_v14`; it was verified at the supplied commit.
The named fixture can therefore continue to report exactly the two package
transitions after PR008 changes the workspace lock. Do not add the future lock
to `ALLOWED_PACKAGE_LOCK`, change `lockStateFor`, or repin any historical
snapshot.

Keep `assertCompleteIndependentDiff` strict for a report that passes: a known
named/PR005 package-lock transition must have role
`pr085_ci_v14_workspace_lock`. Add a separate negative assertion that supplies
altered/future lock bytes to `reportCurrentVersusHistoricalInputs` and observes
`WP11_CURRENT_INPUT_UNREVIEWED_DRIFT`, with the changed item classified as
`unreviewed_package_lock` before the throw. Do not turn that case into a
passing complete diff. The existing catch in `currentInputRole` and the
report-level rejection are the intended package-transition guards; no verifier
allowlist or approval change is required.

## Seal and scope consequences

The only tracked implementation path proposed for editing is
`tests/wp11-attestation.test.mjs`, already present in
`WP11_WRAPPER_IMPLEMENTATION_FILES`. Its edit changes the pending wrapper
implementation hash and therefore the recomputed current wrapper subject. It
does not change the v1.3.0 package files, the technical builder, the policy,
the retained inventory/blobs, the historical approval/evidence/receipt, or
the historical subject
`294d8b40bb5a2dbe1f55cdfde4a60205de75ee1ffe48e0108eae69aea2db0f98`.
The current technical file set may remain 156; that number must not be written
into the 154-file historical seal. Temporary add/remove fixtures are cleaned
up and add no repository scope.

This correction can remove the specific 156-versus-154 test failure, but it
does not accept PR009, PR008, or the combined candidate. The retained gate also
has independent `CONTRACT-VERSION-PACKAGE` and `SUBJECT-PARITY-LABELS`
failures, and an additive future package lock remains unreviewed and blocked
until its own exact input review.

## Immutable evidence and source hashes

| item | bytes | SHA-256 |
| --- | ---: | --- |
| gate receipt `/mnt/d/tmp/plumbob/ushso-research-program-20260910/gate-component-a30cd77.json` | 209533 | `3b42fbe4f9098d87abb7e7373b473ddde7f0cb7e942886c886e83ab55f5139d6` |
| retained test log | 241547 | `b04cbf0c4a606ae2109bf2f90d76f7964f5ed6f4d9efa8103a2afb6ea9975d46` |
| `tests/wp11-attestation.test.mjs` | 39335 | `4a48478762c2ea6e3529b865f6cfba02db6f04a0cab5c05849bc66ac5b21bdc9` |
| `verification/wp11/v1.3.0/tools/technical-evidence.mjs` | 19967 | `a49f9b19868ccadfc4bca5b748513ffdaf2f873b77c2da7e3609f7d7fe5b3838` |
| `scripts/verify-wp11-attestation.mjs` | 33143 | `360bdf7b409374e6d85b493667c49e7fcea1022c9defbd56bcb1305cdd326db5` |
| `verification/wp11/v1.3.0/scope-paths.json` | 3569 | `38706146168f766b05c65738da480a80aa6d9a93ba5f6498bc9f842aa8898eae` |
| `verification/research-program/ci-attestation/wp11-v1.3.0/policy.json` | 4861 | `9373939ec21f1e606164a30e4a2e1f55dcd147ec2b22290289b5feec6dcadee8` |
| historical inventory | 41674 | `46fc584ae6b494ca562455968c14ba799970c45237479b7edadb74939cd1a000` |
