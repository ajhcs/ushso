# PR-006 subject-shortcircuit label-only parity report

Review date: 2026-09-11 UTC  
Review interface: native Codex collaboration selection `gpt-5.6-luna/max` (interface selection, not a serving-model attestation)  
Review mode: read-only structural replay

## Decision

The four failures reported by the combined gate at immutable commit
`a30cd7730de04200f7cd3ffb75ca83378c9e9a1d` are intentional facet-label
differences only. The candidate and frozen control produce the same values,
arrays, object keys/order, counts, ranking, pagination, sections, result
records, scores, match states, uncertainty, and reasons. The only changed
JSON paths are `facets.sections[*].options[*].label`.

The owned test amendment may therefore normalize or separately compare only
those option-label fields. It must retain the existing byte comparison for
every other field and must not edit `tests/fixtures/direct-base-control.mjs`,
the frozen corpus input, algorithm fingerprints, or historical pins.

## Immutable inputs and reference hashes

| Item | Identity / result |
| --- | --- |
| Candidate commit | `a30cd7730de04200f7cd3ffb75ca83378c9e9a1d` |
| Candidate tree | `401b7e745ab01f3c7883f3b64180ad9294e27ac0` |
| PR-006 implementation base | `c58787297fc543b3fdd31736e1c96ed1af29ffd8` |
| `tests/fixtures/direct-base-control.mjs` at base and candidate | `9d672c8b8fb9602e820ffafe731db2dfadd9ffb9abb581b8f01a688b8705f14d` |
| `tests/subject-shortcircuit.test.mjs` at base and candidate | `e3caf837ea49e8cde3ec631725b53a51bfe087731f40aa10b5631027716a9507` |
| `tests/fixtures/direct-base-input.json` at candidate | `a86bd3a297528cb02c9018378b22b7da517208c5984fad709bf5fc1f4cc11e04` |
| `packages/retrieval/tools/retrieval-core-v1.2.mjs` at base | `42198deaa9318273aad96b23dc48bd476b6dc46ac6cf1fe4ca990d295ce64b7b` |
| `packages/retrieval/tools/retrieval-core-v1.2.mjs` at candidate | `b42ef12b6efda9e10c02f8b8ef4589fb7c2bcfd1f77e38c321b15081c220d23a` |
| Frozen corpus algorithm fingerprint | `df3891067d6c1d50bf45c7efc7a73c30167486289f8c3039781266f583e0f714` |

`git diff --name-status c58787297fc543b3fdd31736e1c96ed1af29ffd8 a30cd7730de04200f7cd3ffb75ca83378c9e9a1d -- tests/fixtures/direct-base-control.mjs tests/subject-shortcircuit.test.mjs` returned no paths. The corresponding retrieval-core diff was `99` additions and `1` deletion in that file only: label dictionaries, captured-label resolution, and the option-label projection call.

## Exact replay differences

The replay executed all four sorts for each case: `canonical_relevance`,
`title_asc`, `release_newest`, and `observation_latest` (16 comparisons).
Every comparison had `orderDiffs=0`; the listed value differences repeated
identically for all four sorts in a case.

The JSON path mapping is `sections[0]=source`, `sections[1]=geography`,
`sections[2]=access_status`, `sections[3]=unit_of_analysis`, and
`sections[4]=capability`.

### Case: document aliases without capability

Four label-only differences:

```text
$.facets.sections[0].options[0].label
  actual   "Centers for Disease Control and Prevention Data Catalog"
  expected "cdc-socrata"
$.facets.sections[1].options[0].label
  actual   "Geography unresolved"
  expected "unknown"
$.facets.sections[2].options[0].label
  actual   "Public catalog metadata; payload access unresolved"
  expected "public_catalog"
$.facets.sections[3].options[0].label
  actual   "Observation unit unresolved"
  expected "unknown"
```

### Case: contextual capability independently matches

The four common differences above, plus:

```text
$.facets.sections[4].options[0].label
  actual   "Mental health"
  expected "context-health"
```

### Case: identity capability preserves exact reasons

The four common differences above, plus:

```text
$.facets.sections[4].options[0].label
  actual   "Behavioral health"
  expected "behavioral_health"
```

### Case: multiple aliases preserve capability order and ties

The four common differences above, plus:

```text
$.facets.sections[4].options[0].label
  actual   "Mental health"
  expected "first-context"
$.facets.sections[4].options[1].label
  actual   "Addiction"
  expected "second-context"
```

No `value`, `count`, section identity, option order, or capability order
changed. The result's `JSON.stringify` mismatch is fully accounted for by the
allowlisted label paths above.

## Commands actually executed

All commands were local read-only commands from
`/mnt/d/worktrees/plumbob/ushso-research-program-20260910`; no server,
network, private holdout, or repository writer was used.

```text
git show --stat --oneline --decorate --no-renames a30cd7730de04200f7cd3ffb75ca83378c9e9a1d
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:tests/subject-shortcircuit.test.mjs
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:packages/retrieval/tools/retrieval-core-v1.2.mjs
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:tests/fixtures/direct-base-control.mjs
git diff --name-status c58787297fc543b3fdd31736e1c96ed1af29ffd8 a30cd7730de04200f7cd3ffb75ca83378c9e9a1d -- tests/fixtures/direct-base-control.mjs tests/subject-shortcircuit.test.mjs
git diff --numstat c58787297fc543b3fdd31736e1c96ed1af29ffd8 a30cd7730de04200f7cd3ffb75ca83378c9e9a1d -- packages/retrieval/tools/retrieval-core-v1.2.mjs
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:tests/fixtures/direct-base-control.mjs | sha256sum
git show c58787297fc543b3fdd31736e1c96ed1af29ffd8:tests/fixtures/direct-base-control.mjs | sha256sum
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:tests/subject-shortcircuit.test.mjs | sha256sum
git show c58787297fc543b3fdd31736e1c96ed1af29ffd8:tests/subject-shortcircuit.test.mjs | sha256sum
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:tests/fixtures/direct-base-input.json | sha256sum
git show c58787297fc543b3fdd31736e1c96ed1af29ffd8:packages/retrieval/tools/retrieval-core-v1.2.mjs | sha256sum
git show a30cd7730de04200f7cd3ffb75ca83378c9e9a1d:packages/retrieval/tools/retrieval-core-v1.2.mjs | sha256sum
git archive --format=tar a30cd7730de04200f7cd3ffb75ca83378c9e9a1d packages/retrieval/tools tests/fixtures/direct-base-control.mjs tests/fixtures/direct-base-input.json | node --experimental-vm-modules --input-type=module -e "const {readFileSync}=await import('node:fs'); const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor; await new AsyncFunction(readFileSync(3,'utf8').toString())()" 3<<'NODE' ... NODE
rg -n -C 12 "subject short circuit|subject-shortcircuit|behavioral_health|option.label|expected:|actual:" /mnt/d/tmp/plumbob/release-gate-state/repositories/ushso-375cca760f7dab38/runs/20260911T192858Z-ad0e6c695466/logs/tests.attempt-1.log
cat /mnt/d/tmp/plumbob/ushso-research-program-20260910/combined-a30cd77-failure-analysis.json
git status --short --branch
```

The `git archive | node` command loaded the archived modules into an
in-memory VM module graph, constructed the four rows from the archived frozen
input, ran both `direct-base-control` and candidate engines, compared all
16 JSON results recursively, and separately checked object-key order. It
printed the exact paths and values recorded above; it wrote no extraction or
result files.

The retained gate log is
`/mnt/d/tmp/plumbob/release-gate-state/repositories/ushso-375cca760f7dab38/runs/20260911T192858Z-ad0e6c695466/logs/tests.attempt-1.log`,
SHA-256 `b04cbf0c4a606ae2109bf2f90d76f7964f5ed6f4d9efa8103a2afb6ea9975d46`,
241547 bytes. Its four reported failures are the cases classified here.

## Safe amendment boundary

The test owner may preserve the existing `JSON.stringify(actual) ===
JSON.stringify(expected)` assertion for a copy with only
`facets.sections[*].options[*].label` removed or replaced by a sentinel, then
assert the label map separately. A useful negative control is to mutate one
non-label field in the comparison copy and assert that parity still fails;
this demonstrates that the normalization cannot hide counts, values, or
result changes. The frozen control engine, fixture input, algorithm
fingerprint, historical manifests, and reference implementation remain
unchanged.
