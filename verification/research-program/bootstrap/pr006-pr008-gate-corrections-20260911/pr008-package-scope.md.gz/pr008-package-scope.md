# PR-008 v1.2 contract-package scope proposal

**Review mode:** read-only scope review; no repository files, branches, or history changed.  
**Reviewer:** gpt-5.6-luna/max.  
**Reviewed input:** commit `a30cd7730de04200f7cd3ffb75ca83378c9e9a1d`, tree `401b7e745ab01f3c7883f3b64180ad9294e27ac`.  
**Gate evidence:** `/mnt/d/tmp/plumbob/ushso-research-program-20260910/gate-component-a30cd77.json` and the associated failure analysis/logs.

## Decision

Complete the existing `contracts/machine-toolkit/v1.2.0` directory as the private machine-toolkit successor.  Do not create a separately named contract domain/package.  `scripts/run-contract-suites.mjs` uses `discoverContractPackages()` to enumerate every `contracts/<domain>/vX.Y.Z` directory; its latest-version selection applies only to verification suites.  Once v1.2 has a valid package descriptor, the existing runner continues to execute v1.0.0, v1.1.0, and v1.2.0.  The v1.2 schema is self-contained and can remain byte-identical:

`contracts/machine-toolkit/v1.2.0/schemas/variable-identity.schema.json`  
SHA-256: `e6427730b3ad04653c3be13720bd9d7903d51ca7a331b7539493c039d5021c2c`.

This is the smallest remedy for the discovery failure.  It preserves the frozen v1.0 routes/contracts and the v1.1 response-envelope successor, while giving the variable schema an independently verifiable package boundary.

## Exact PR-008 package paths

The amended PR-008 packet should own these new paths, in addition to its already accepted identity/schema paths:

- `contracts/machine-toolkit/v1.2.0/package.json`: private, `type: module`, version `1.2.0`, Node `>=22.15`, unique name such as `@ushso/machine-toolkit-variable-identity-v1.2`, and `ajv` pinned to the repository's selected 8.20.x version.  Required scripts are `test: node --test tests/*.test.mjs` and `validate: node tools/verify.mjs` (a `verify` alias is acceptable).
- `contracts/machine-toolkit/v1.2.0/README.md`: states that this is an additive variable-identity schema, verified locally/offline, with no route/WebMCP registration, attestation, release receipt, publication, or promotion authority; v1.0 and v1.1 remain predecessors.
- `contracts/machine-toolkit/v1.2.0/tools/verify.mjs`: compile the one local schema with Ajv2020 in strict mode, assert the expected `$id`, version, closed top-level boundary, required fields, and no external/network schema resolution.  It must be a read-only validator and must not issue a receipt.
- `contracts/machine-toolkit/v1.2.0/tests/variable-identity.test.mjs`: local Node tests with both valid and invalid representative documents.  Cover closed/additional-property rejection, literal encodings and mapping states, distinct `publisher_concept` versus `definition`, unresolved/ambiguous identity retaining a null `variable_id`, identifier `not_applicable` units, and measure records with omitted or unknown units remaining incomplete/unknown.  Keep the existing root semantic tests as the decisive implementation tests.
- `package-lock.json`: add the v1.2 workspace package entry and its `node_modules/@ushso/machine-toolkit-variable-identity-v1.2` link, without changing the v1.0/v1.1 entries.  The root `package.json` workspace glob already covers `contracts/*/v*` and needs no edit.

No v1.0-style package manifest, fixture corpus, or receipt is needed.  The bounded v1.1 package demonstrates that a private successor can be complete with a descriptor, README, local verifier, and tests; copying the full v1.0 contract surface would expand scope and risk frozen-contract changes.

## Checks and ownership boundary

Run the existing contract suite and inventory checks after the package and lock entry are present.  The acceptance evidence must show separate successful `test` and `validate` executions for all three machine-toolkit versions, with the v1.0 and v1.1 schema/response checks unchanged.  Also run the normal PR-008 semantic tests and the package-lock/CI inventory audit.  No change to `scripts/run-contract-suites.mjs` is required.  Adding v1.2 to the two root `requiredContracts` sets (`tests/contract-package-inventory.test.mjs` and `verification/testing/ci/v1.4.0/tools/ci-inventory.mjs`) is a useful future-presence guard, but it is not required to fix this failure because both checks dynamically enumerate all versions; if adopted, it is a separate root-owned gate change.

The lockfile update is unavoidable cross-owner workspace metadata and must be explicitly included in the amended packet.  If canonical plan validation still enforces the already accepted PR-008 owned-path list and three-commit shape, root must amend `plan-source.py` and regenerate its derived plan/PR metadata and packet hash, or issue a small stable follow-on package-completion assignment.  Do not append these paths silently to the historical PR-008 commits.  A practical correction split is: package descriptor/README/verifier/tests, lockfile workspace metadata, then updated handoff/evidence after the exact checks; the original commits and receipts remain immutable.

The separate WP11 gate failure is not caused by this package and should remain root-owned.  The current evidence list is 156 versus the historical 154 because `apps/web/src/components/FacetSidebar.test.tsx` and `apps/web/src/pages/SourcesPage.test.tsx` are now included.  Do not change `tests/wp11-attestation.test.mjs` as part of PR-008 package completion.

