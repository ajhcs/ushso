# PR-011 / WP5 successor scope proposal

## Review basis

This is a read-only scope review of immutable commit `12e88769677df1cb54022a13c1b429f70fc71346`, tree `7f204ea53e00607f501e41dbea267ae3c2ce8e3f`, in `/mnt/d/worktrees/plumbob/ushso-research-program-20260910`. No repository files were changed, and no tests, network requests, private holdout reads, runtime work, or implementation dispatch was performed.

Reviewed inputs were `README.md`, `docs/ARCHITECTURE.md`, `docs/EVALUATION.md`, `docs/master-plan/2026-09-10/EXECUTION.md`, `docs/master-plan/2026-09-10/prs/PR-011.md`, `scripts/run-contract-suites.mjs`, `package.json`, `package-lock.json`, the execution ledger, the complete `verification/wp5/v1.0.0` package, and the PR-085/086 packets, handoffs, and public evidence indexes.

## Disposition

An additive `verification/wp5/v1.1.0` package requires a separately named bounded assignment. It should consume an exact PR-011 implementation candidate and be composed with that candidate in one final integration gate. It should not be silently added to PR-011's current three commits.

The provisional next stable assignment is **PR-087 — WP5 v1.1 successor verification**, with parent requirement `R03` and findings `F03`, `F13`, and `F32`. The controller must add and validate that plan/ledger entry before dispatch. PR-011 remains the producer of connector behavior; PR-087 is its one-way verification consumer. PR-011 must not depend on PR-087.

The reason for the split is operational as well as ownership-related. PR-011 currently owns only `packages/connectors/src/`, `scripts/research/document-integrity.mjs`, and `tests/research-program/http-outcomes.test.mjs`. WP5 v1.1 adds a complete versioned package, a second test/tool surface, receipts, a package-lock workspace entry, and a separate current-candidate evidence boundary. The runner selects the highest WP5 version and requires a package, both required scripts, and at least one Node test. A partial v1.1 directory would therefore break discovery. Each PR-011 connector commit also changes the v1.0 fingerprint. Folding both concerns together would require rebuilding the full fingerprint-bound receipt set in every connector commit and would make verification ownership unclear. A successor branch based on the final PR-011 candidate keeps the package complete from its first commit and leaves v1.0 immutable.

The dependency and integration order is:

```text
accepted PR-008 -> accepted PR-009 -> accepted PR-010 -> PR-011 candidate
                                                               |
                                                               v
                                             PR-087 WP5 v1.1 candidate
                                                               |
                                                               v
                                      root composed candidate and final gate
```

PR-011 may be tested as a producer candidate before PR-087 exists. Once its connector bytes change, its `--suite wp5` result will remain blocked by the intentionally stale v1.0 fingerprint. Root should avoid integrating PR-011 alone; a PR-087 branch based on the exact PR-011 head can carry both changes into the final candidate. That retains an acyclic graph without treating a temporary stale-suite result as acceptance.

## Existing contracts and reusable implementation

PR-011's three commits are narrowly defined:

* C-011-1 classifies MIME, parse shape, redirects, documented login/error pages, authentication, unavailable, content-mismatch, and transient outcomes.
* C-011-2 applies time, raw-byte, expanded-byte, row, and redirect bounds before parsing.
* C-011-3 records sanitized headers, hashes, expected/actual content, next action, and last-good state.

The existing WP5 package at `verification/wp5/v1.0.0` contains exactly `README.md`, `evidence-ledger.json`, `package.json`, seven receipts (`activation-status`, `delivery-wave-fixtures`, `fixture-matrix`, `legacy-lane-parity`, `r2-capture-protocol`, `request-capture-reconciliation`, and `zero-payload-proof`), `tests/wp5-verification.test.mjs`, `tools/common.mjs`, and `tools/validate-wp5.mjs`. Its package is private, Node `>=22`, and exposes `test` and `validate` scripts. The v1.0 expected connector fingerprint is `df5fb94f4f3f3468ca2631a63768a4bf7711696657c88c4b7df57830e7031b99`; every v1.0 receipt and the evidence ledger carry that value.

The v1.0 fingerprint hashes every file below `packages/connectors`, sorted by relative path with path/NUL/content/NUL framing, excluding only `node_modules` and a `manifests/package-manifest.json` if present. There is no connector manifest at the reviewed commit. The v1.1 helper must preserve this algorithm and compute the digest from the exact PR-011 candidate; a digest is an identity check, not an approval.

The successor can reuse these existing exports without adding a transport subsystem:

* `packages/connectors/src/index.mjs`: `classifyResponse`, `mediaTypeFromHeaders`, `compileManifestRequest`, `matchManifestRedirect`, `resolveManifestRedirectLocation`, `assertRawRedirectPath`, `routeManifestInventory`, `validateDescriptor`, `R2CaptureProtocol`, `DeterministicConnectorRunner`, `deliveryWaveManifest`, `validateDeliveryWaveRegistry`, and `buildLegacyLaneParity`.
* `packages/connectors/src/testing/index.mjs` (or the existing direct module paths): `runFixtureMatrix`, `runDeliveryWaveFixtureMatrix`, and `runReconciliationAudit`.
* `contracts/ingestion/v1.1.0/tools/index.mjs`: the already-used `validateIngestionRecord`, `validateRecordSet`, and `validateTransition` helpers. No `packages/ingestion` export or byte needs to change.

`scripts/research/document-integrity.mjs` does not exist at this input head. The successor must not guess an API for it. If PR-011 exposes a pure named helper, PR-087 may bind that helper only after PR-011's handoff records its exact export and hash; otherwise v1.1 should test the existing connector exports directly.

## Proposed PR-087 owned paths

The implementation assignment should own exactly:

```text
package-lock.json                         # only the new private workspace links
verification/wp5/v1.1.0/README.md
verification/wp5/v1.1.0/package.json
verification/wp5/v1.1.0/evidence-ledger.json
verification/wp5/v1.1.0/receipts/activation-status.json
verification/wp5/v1.1.0/receipts/delivery-wave-fixtures.json
verification/wp5/v1.1.0/receipts/fixture-matrix.json
verification/wp5/v1.1.0/receipts/legacy-lane-parity.json
verification/wp5/v1.1.0/receipts/r2-capture-protocol.json
verification/wp5/v1.1.0/receipts/request-capture-reconciliation.json
verification/wp5/v1.1.0/receipts/zero-payload-proof.json
verification/wp5/v1.1.0/receipts/v1.0-package-pins.json
verification/wp5/v1.1.0/receipts/pr011-http-outcomes.json
verification/wp5/v1.1.0/tests/wp5-verification.test.mjs
verification/wp5/v1.1.0/tests/http-outcomes-successor.test.mjs
verification/wp5/v1.1.0/tools/common.mjs
verification/wp5/v1.1.0/tools/validate-wp5.mjs
verification/research-program/pr-087-wp5-successor/**
docs/research-program/handoffs/PR-087.json
```

The v1.1 package should use the unique workspace name `@ushso/verification-wp5-v1-1`, with version `1.1.0`, `private: true`, `type: module`, Node `>=22`, and the same `test`/`validate` script shape. Reusing the v1.0 name `@ushso/verification-wp5` would create duplicate workspace names because both version directories match the root workspace glob. The lock change must contain only the deterministic links for the new package; no dependency resolution or unrelated lock update is implied.

There is no `verification/wp5/v1.0.0/manifests/` path at this head. Do not invent one. The `v1.0-package-pins.json` receipt should pin every v1.0 file's path, byte count, and hash to the reviewed commit, so the old package remains demonstrably unchanged. The v1.1 receipts may carry a new `wp5-...v1.1.0` receipt version and the exact PR-011 candidate fingerprint, but must retain all v1.0 controls, scenarios, negative cases, and activation boundaries.

The controller-owned plan amendment and execution-ledger record are scheduling inputs, not implementation paths. The assignment must not own `packages/connectors`, `packages/ingestion`, `scripts/run-contract-suites.mjs`, any v1.0 file, runtime/configuration, database, queue, workflow, R2, or live-source path.

## Three PR-087 commits

### C-087-1 — Add a complete immutable WP5 successor package

Start from the exact PR-011 candidate head/tree. Add the complete v1.1 package in one commit by adapting the v1.0 tests, validator, common fingerprint helper, evidence ledger, and seven baseline receipts. Add `v1.0-package-pins.json`, set the candidate fingerprint only from the actual candidate tree, and add the unique lock workspace entries. The package must be complete enough for latest-version discovery immediately; no placeholder package or empty test directory is acceptable. Do not edit v1.0.

The package remains `fixture_only`/`local_integration`; `live_shadow`, `index_shadow`, `canary`, and `active` remain `PENDING_EXTERNAL_AUTHORIZATION`. No receipt may imply source activation, live R2, credentials, payload transport, healthcare-row capture, or external actions.

### C-087-2 — Add PR-011 outcome verification without changing transport

Add `http-outcomes-successor.test.mjs`, the `pr011-http-outcomes.json` receipt, and the corresponding strict validator/evidence-ledger controls. Retain the entire v1.0 matrix and parity checks while covering the actual PR-011 behavior:

* A captured Census Missing Key response with status 200 and HTML content fails the expected JSON/API role; status 200 alone cannot become payload access.
* The captured EPA developer destination resolving to a Widgets page fails the requested API/documentation role while preserving reachability and a typed next action.
* MIME/parse-shape mismatch, wrong or unapproved redirect destination, login/error content, interrupted response, raw-byte cap, expanded-byte cap, and row/cardinality cap remain typed and fail closed.
* A failed refresh updates attempt/staleness evidence and retains the last qualified observation. Sanitized headers, hashes, expected/actual classifications, redirect context, and next action contain no credentials, signed locators, or full private bodies.

Use only the PR-011 handoff's exact retained fixtures and the reusable connector/contract exports. Do not fetch, store, enqueue, persist to a database, or call production R2. Do not add a guessed `document-integrity` interface.

### C-087-3 — Publish candidate-bound evidence and handoff

Add the sanitized evidence index, task binding, command receipts, candidate input head/tree, v1.0 pin review, expected/actual outcomes, and unresolved claims below `verification/research-program/pr-087-wp5-successor/`, plus `docs/research-program/handoffs/PR-087.json`. Bind the final exact candidate externally after the documentation commit; do not self-approve it. Record any interim stale-v1.0 result from the PR-011 producer candidate as a blocker that the composed candidate resolves.

## Checks and acceptance cases

The successor's focused commands are:

```bash
npm test --prefix verification/wp5/v1.1.0
npm run validate --prefix verification/wp5/v1.1.0
node scripts/run-contract-suites.mjs --list
node scripts/run-contract-suites.mjs --suite wp5
node --test tests/research-program/http-outcomes.test.mjs
```

The final root-owned candidate gate remains `npm test`, `npm run build`, `npm run cf:dry-run`, and applicable hosted CI. The focused commands are planned checks for the future assignment and were not run in this review.

Positive cases must show that the runner selects `verification/wp5/v1.1.0`, executes its real test and validate scripts, and reports nonzero test counts; all v1.0 package files match `v1.0-package-pins.json`; the candidate connector fingerprint matches every v1.1 receipt and the evidence ledger; all original fixture, delivery-wave, legacy-parity, reconciliation, R2-fake, zero-payload, credential, deletion, checkpoint, and crash/resume controls remain present; and activation is still false with `AUTH-04` pending.

Negative cases must fail closed for a one-byte connector change, a stale or wrong candidate head/tree, a manually changed fingerprint, a missing or altered v1.0 pin, a duplicate workspace package name, a missing required script, a malformed or zero-test suite, a v1.0 receipt edit, Census HTML presented as JSON success, EPA Widgets presented as an API recipe, wrong-role or unapproved redirect, ignored byte/expansion/row/redirect limits, interrupted reads, last-good deletion, credential/signed-locator/body leakage, live DNS/network/R2 use, or any activation/approval claim. Existing v1.0 expected fingerprint bytes remain unchanged even though direct v1.0 validation against the changed connector candidate is expected to reject the stale subject; that rejection is evidence of the boundary, not a reason to repin v1.0.

## Required inputs and approval semantics

Dispatch is blocked until PR-008 is accepted, then PR-009 and PR-010 have actual merge SHAs and validated handoffs, and PR-011 supplies an exact candidate head/tree with its connector and fixture hashes. The Census negative may be consumed only through the retained PR-009/PR-011 handoff; no fresh request or fabricated route identity is allowed. The EPA fixture and any `document-integrity` API must be present and hash-bound in the PR-011 handoff before PR-087 can claim those cases.

The candidate fingerprint must be generated from the PR-011 candidate, recorded as an identity, and independently reviewed by Astra/controller. It is not a model self-attestation, an approval, or a release qualification. Approval remains absent/null; source-specific `AUTH-04` authorization, credentials, live routes, production observability, reconciliation cycles, rights, and release qualification remain outside this assignment. PR-085/086 evidence cannot satisfy any of those WP5 successor inputs.

## PR-085/086 boundary and gate interactions

PR-085 owns CI/WP0 and WP11 current-attestation paths, including `verification/testing/ci/v1.4.0` and `verification/research-program/ci-attestation/wp11-v1.3.0`; it does not own connector code or WP5. Its public handoff is `producer_checked`, current subjects remain pending, and its retained full npm chain failed at the stale WP11 v1.3 subject. The execution ledger labels the historical component integrated, but that bookkeeping does not turn the pending current draft into approval.

PR-086 owns the separate WP11 historical preimage/current-wrapper boundary. Its retained 154-file historical proof is offline and exact; its current technical and wrapper subjects have `approval=null`; direct successor `--validate` and `--issue` reject `SUCCESSOR_APPROVAL_STALE_SUBJECT` without writing receipts; and its README explicitly says it is not combined PR005/PR086 acceptance or release qualification. These are useful precedents for preserving old bytes and separating current evidence, but their receipts, model/provider facts, and WP11 approval workflow must not be reused as WP5 v1.1 evidence.

`run-contract-suites.mjs` already registers the `wp5` alias at `verification/wp5`, discovers semver version directories, selects the highest version, checks private package identity/scripts/test presence, and then runs `test` and `validate`. No registration edit is needed for a complete v1.1 directory. The root workspace glob does discover both v1.0 and v1.1, so the unique package name and lock entries are required. No change to `run-contract-suites.mjs` or `packages/connectors` package exports is proposed.

## Immutable input hashes

All hashes below are SHA-256 of the exact Git blob at the reviewed commit; byte counts are decimal.

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| `README.md` | 4002 | `e46f4c12a25ae9ed628002e6b0380feebdd4f9b60a23cefca41b66f3eaed8d6d` |
| `docs/ARCHITECTURE.md` | 6191 | `f70fe0b4c35dfc5f4d64790f5eb0b4941a88c869586c4ddec63c86ebc87e0f70` |
| `docs/EVALUATION.md` | 2859 | `4fe2c290c2adaea7a2b859e34c65997a478824a0a1722480f2873798c131d389` |
| `docs/master-plan/2026-09-10/EXECUTION.md` | 12861 | `4118d4f46a7ebec45749676881c753529593842792a439cfb5e53e50bc1fdfc3` |
| `docs/master-plan/2026-09-10/prs/PR-011.md` | 4747 | `d7a68918daacbe5063d6b1c3c158792cbe2b715dbcf17c7029a8e32b8ffa482c` |
| `scripts/run-contract-suites.mjs` | 29025 | `3a13c51986e1cd90b530465d4e8fc30cc3763a86189d06930c4dbf6f65c5e261` |
| `package.json` | 3666 | `b6c3469c7b10ecb90114199c18c3ebb293d801b8c8a3521cb25ded2fdba8d05e` |
| `package-lock.json` | 134511 | `37e4a9ec1fba9ab254aa7a596e1a0e3f73919cf5358717dc6e06e0478be6b20c` |
| `docs/research-program/execution-ledger.json` | 165244 | `174a5433f8b37730d3eed32089be36e556f59be586de586c65082bdb7c9e7779` |
| `docs/master-plan/2026-09-10/prs/PR-085.md` | 12316 | `55f6e390ae59a28b00c6138628396fcfd8315f2dabe36e8ee0d474a82fb50bd0` |
| `docs/master-plan/2026-09-10/prs/PR-086.md` | 7935 | `a2cfd9747adf877763cc630b5f7aa6a34fdd9c9de6741871a64274fad65ac12c` |
| `docs/research-program/handoffs/PR-085.json` | 85319 | `91dcae95ec1216bf6396c5ae9299c1eb4780790ef752324f9f3bb7aa733bb9d1` |
| `docs/research-program/handoffs/PR-086.json` | 29229 | `e56eb8aded3a10da45b1ef81e98cbafd18887260152b56f9ec8fc9d46fd026a4` |
| `verification/research-program/pr-085/evidence-index.json` | 19861 | `ec0722290556a0dddf7305ecb983ae2633b5d6d436d39abc4da184999023e3b9` |
| `verification/research-program/pr-085/task-binding.json` | 10792 | `6597fe693f9c2a26ae1da3a44b6255286302180708c16c71ee6ec16c5be514a2` |
| `verification/research-program/pr-086/evidence-index.json` | 9730 | `bd5fdd8f778d61e8f13c76fac7414111e3f8a8395908e7385387dbb798e4390c` |
| `verification/research-program/pr-086/task-binding.json` | 4783 | `5c24e81113a117d4655a663cf4876123364eea14ccbe43a10fce91d852660db2` |
| `verification/wp5/v1.0.0/README.md` | 2281 | `a0bf03119af1157e1243d987530f7702bd3c1a97413666bf36d00075e8a6454d` |
| `verification/wp5/v1.0.0/evidence-ledger.json` | 13024 | `74fd2fd92ddcbd85841e7b81c4ad6ae08c420bdfd9d37feda93059dba0bab2e5` |
| `verification/wp5/v1.0.0/package.json` | 250 | `f08c6e657f17a50459c0e09a011b984e507de6a9b68f85941f3f42b20ab6631c` |
| `verification/wp5/v1.0.0/tests/wp5-verification.test.mjs` | 7731 | `60b4c1bbc2da3e7b3e62b788c0bf05e22e4bc1f8beb99146e83eb6be0ae05222` |
| `verification/wp5/v1.0.0/tools/common.mjs` | 1489 | `3a8c6c619271600daf16d98377c7ca0ab1c39728c7bd3aa31d48d7ba1b916e39` |
| `verification/wp5/v1.0.0/tools/validate-wp5.mjs` | 6329 | `96d3653a8b9500f0b8d5f8d8d298b591058a39788fea247584acb03d94dd0991` |
| `packages/connectors/package.json` | 390 | `0a8a1f416280705e85e80e5da2f6d816834c08f5bf23f9762dfd0c48ef932f6c` |
| `packages/connectors/src/index.mjs` | 2538 | `be4a019f4d99d373cfc176dcdd2509e54207defb28e72f79e96c33f911f22824` |
| `packages/connectors/tools/validate-package.mjs` | 5120 | `bd2f57ea47fbdf975fb044a11162e1b38554385ec87af16bc260c117f18cc367` |
| `packages/ingestion/package.json` | 416 | `52f6f2d8cd754575b098933b98bc253adfb8602bfe2cb61997d70db620802501` |

The seven v1.0 receipt blobs are also pinned for the proposed `v1.0-package-pins.json`: `activation-status.json` 1666 bytes / `439b258fc261f8e537ccaf72a8c07efe08c03d239a73e07591b0fb41e813c9cc`; `delivery-wave-fixtures.json` 1889 / `8d68a1b1ddf138e7e44d7c0b24bf9c51fbce6a6f6bab3d60e6e10a6e8479cd35`; `fixture-matrix.json` 1149 / `94414bd4b9eabcca81e07bea90b340b3b37efade18416a16cedd9d29abb6bf1c`; `legacy-lane-parity.json` 821 / `d47143f458631d109b88f5655ec9398ed6f00b298f615297a40f70d8509d76ed`; `r2-capture-protocol.json` 1080 / `48696a9225a91e8cf75a4915bd85f322535dfc66723a6a783e8c55e906a93547`; `request-capture-reconciliation.json` 733 / `7751e80f77f7b5c90832294ada4868320c9bd1b99339bb0bbd8bc31dd7eafc88`; `zero-payload-proof.json` 1112 / `a6f5c89704a66de71f0037c366ff174546b03e185d79b343d1d8c384ca6b100f`.

**Conclusion:** hold PR-087 until accepted PR-008 through PR-011 candidate inputs exist; then implement the complete additive v1.1 verifier on the exact PR-011 candidate and integrate both together. Keep WP5 v1.0 and PR-085/086 historical/current evidence unchanged and unrepinned.
