# Amended PR-011 / WP5 successor scheduling proposal

## Provenance and review basis

This amendment preserves the original proposal at `/mnt/d/tmp/plumbob/ushso-research-program-20260910/pr011-wp5-successor-scope-proposal.md` unchanged: 20,263 bytes, SHA-256 `b48fd0534c29f68ee13582f62cb4463c2de3aaa4128a4a58dd440069d447cfd1`.

The amendment reviews the same immutable PR-011 input, commit `12e88769677df1cb54022a13c1b429f70fc71346`, tree `7f204ea53e00607f501e41dbea267ae3c2ce8e3f`, and compares the accepted component-composition records at root commit `9e00d4e09514e1dd30672e19a3cbef4171955b00`, tree `9c6aef6daa3e6dbd5b03217cf466d30364295ee7`. This remains a read-only scope review. No repository edit, implementation dispatch, test, network request, private holdout read, or external action was performed.

## Corrected disposition

Keep the separately named WP5 successor assignment, provisionally PR-087, but change its scheduling input from an unmerged PR-011 candidate to the actual independently reviewed PR-011 component merge and handoff. PR-011 does not wait for PR-087 to be implemented or accepted. PR-087 is a downstream integration consumer; it is not a back-edge prerequisite for PR-011.

The exact state model is:

```text
accepted PR-008
      -> accepted PR-009 (M009)
      -> accepted PR-010 (M010)
      -> PR-011 component dispatch and review
      -> PR-011 component merge M011, focused acceptance only
           |  integration_prerequisites_satisfied=false
           |  integration_dependency_pending=[PR-087]
           v
      PR-087 dispatch from M011 and its validated handoff
      -> PR-087 component merge M087, successor acceptance
      -> root composes M011 + M087 as integration head I
      -> joint full gate and final acceptance
```

PR-011's own packet remains bounded by its existing three commits and focused `R03` acceptance. Once connector bytes change, the old WP5 v1.0 fingerprint failure is retained in the PR-011 handoff as an explicit downstream integration blocker. It is not hidden, waived, or fixed by repinning. A producer component can therefore be independently reviewed and merged with `integration_prerequisites_satisfied=false`, as the accepted PR-005/086 composition pattern demonstrates; it is not a qualified final product until the successor is composed and the root gate passes.

## What the PR-005/086 pattern establishes

At root `9e00d4e`, the controller handoffs for PR-005 and PR-086 separately record each component's producer head, component merge, and later root integration merge:

* PR-005: component head `afb90565456a429e73527f2bb99daf9cf174aa3c`, component merge `4fa2e0b5c8ee210cff9750a59e69df4b4a527fdc`, final integration merge `0d730aaf07b89bb16fb66fc224841a2d66c80d49`.
* PR-086: component head `fc246d03463bb85e3892b443120c60b6206aae4a`, component merge `e6da2e2d87c95501e5a1b129989e17bdae3cb882`, the same final integration merge `0d730aaf07b89bb16fb66fc224841a2d66c80d49`.

Each handoff has its own `dependency_merge_shas`; the later root composition records `integration_dependency_merge_shas` and `integration_merge_sha`. PR-005's producer dependency remains PR-004 while PR-086 is recorded as an integration dependency. That is the required distinction here: PR-011's own dependency map contains PR-009 and PR-010; PR-087 is recorded only as a downstream integration dependency until root composes both components. PR-087's own dependency map contains PR-011 once M011 exists.

The same records show why this does not grant product acceptance. The component acceptance record is `status: independently_verified`, while the composition record retains `accepted: false` and all `R01`–`R16` requirements as unaccepted. Use the pattern for immutable heads, component merges, and joint root gating; do not copy its historical evidence or infer a requirement approval.

## Exact dependency and dispatch-gate wording

The following wording can be placed in the controller's PR-011/PR-087 scheduling packets without adding a circular edge.

### PR-011 dispatch

> **Dispatch gate:** Dispatch PR-011 only after PR-008 is accepted and PR-009 and PR-010 each have actual component `merge_sha` values, validated handoffs, and dependency hashes bound in the execution ledger. Record those values in PR-011 `dependency_merge_shas` and `base_sha`/`base_tree`. PR-087 is not a PR-011 dependency and must not be added to this gate. PR-011 focused acceptance may complete while the first connector byte edit leaves WP5 v1.0's fixed fingerprint stale; retain that exact failure as `integration_dependency_pending: ["PR-087"]` and leave `integration_prerequisites_satisfied: false`.

### PR-011 component completion

> **Component merge boundary:** After PR-011's three commits, focused tests, independent review, and handoff pass, bind its actual component `head_sha`, `head_tree`, and `merge_sha` as M011. Do not claim `integrated`, `qualified`, or final root acceptance while the WP5 v1.0 stale-fingerprint blocker remains. The component handoff must name PR-087 as the next consumer and include the exact connector candidate tree, retained fixture hashes, changed exports, and the expected stale-v1.0 result.

### PR-087 dispatch

> **Dispatch gate:** Dispatch PR-087 only when PR-011 has an actual independently reviewed component `merge_sha` M011 and `head_tree`, a validated `docs/research-program/handoffs/PR-011.json`, and an explicit `integration_dependency_pending` WP5 successor blocker. Set PR-087 `dependencies: ["PR-011"]`, `dependency_merge_shas: {"PR-011": M011}`, `base_sha: M011`, and `base_tree` to M011's exact tree. Validate that PR-008 acceptance, PR-009/M009, and PR-010/M010 are transitive inputs; do not dispatch from a floating branch tip, producer-only log, or unbound candidate SHA. PR-011 does not depend on PR-087.

### Joint root integration

> **Integration gate:** After PR-087 has its own component `head_sha`, `head_tree`, `merge_sha` M087, focused checks, independent review, and handoff, root composes the exact M011 and M087 components into one integration head I. Record `integration_merge_sha: I` and `integration_dependency_merge_shas` for M009, M010, M011, and M087 in the controller handoffs. Run the latest WP5 suite, PR-011 focused checks, `npm test`, `npm run build`, `npm run cf:dry-run`, and applicable hosted CI on I. No component merge, fingerprint identity, producer PASS, or handoff validity alone is final acceptance. All existing thresholds and strict v1.0 bytes remain unchanged.

## Revised PR-087 scope

The original owned paths, three successor commits, v1.0 immutability pins, unique workspace package name, and no-transport boundary remain correct. The only scheduling correction is the base and gate:

* C-087-1 starts at M011, not at an unmerged PR-011 branch tip. It adds a complete `verification/wp5/v1.1.0` package and only the required lock entries. The v1.1 fingerprint is computed from M011's exact `packages/connectors` tree.
* C-087-2 adds the PR-011 outcome tests and receipt while retaining every v1.0 matrix, receipt, negative case, and activation boundary. It uses the exact PR-011 handoff fixtures and exports.
* C-087-3 records M011/M087 inputs, command results, v1.0 pin verification, and unresolved claims. Root, not the successor package, binds the final integration SHA and runs the joint gate.

The implementation-owned paths remain:

```text
package-lock.json
verification/wp5/v1.1.0/**
verification/research-program/pr-087-wp5-successor/**
docs/research-program/handoffs/PR-087.json
```

PR-087 must not edit PR-011 connector files, `packages/ingestion`, `scripts/run-contract-suites.mjs`, WP5 v1.0, runtime/configuration, queues, workflows, databases, R2, or live-source paths. No runner registration change is needed: `run-contract-suites.mjs` already selects the highest complete semver package under `verification/wp5`.

## Validation example

The accompanying file `pr011-wp5-successor-dispatch-validation-example.json` is an illustrative, unexecuted state check. It shows the required M011 handoff before PR-087 dispatch and rejects the two common invalid states: dispatch with no actual PR-011 merge, and a circular PR-011 dependency on PR-087. It uses placeholders for future immutable SHAs and makes no evidence claim.

The validator should require, at minimum:

```text
PR-011 dispatch:  PR009/M009 + PR010/M010 + validated handoffs
PR-087 dispatch:  M011 + exact M011 tree + validated PR-011 handoff
final acceptance: M011 + M087 + integration head I + full gate
cycle check:      PR-011 dependencies must not contain PR-087
```

No state that has only `head_sha`, a provider log, or a producer PASS may satisfy the PR-087 dispatch gate.

## Compared immutable file hashes

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| Reviewed PR-009/PR-011 input commit | — | `12e88769677df1cb54022a13c1b429f70fc71346` |
| Reviewed PR-009/PR-011 input tree | — | `7f204ea53e00607f501e41dbea267ae3c2ce8e3f` |
| Original proposal | 20263 | `b48fd0534c29f68ee13582f62cb4463c2de3aaa4128a4a58dd440069d447cfd1` |
| Composition comparison commit | — | `9e00d4e09514e1dd30672e19a3cbef4171955b00` |
| Composition comparison tree | — | `9c6aef6daa3e6dbd5b03217cf466d30364295ee7` |
| `components-e6da2e2/acceptance.json` | 5144 | `016f761f3d4b65f9f46c29426f02c0f9253a810b426af030115dd7dcf4e5524f` |
| `components-e6da2e2/composition.json` | 685 | `60deb4b66848f117d23bdc28e36404c61ea5309ee15a6942b28d397e42f4b90b` |
| `components-e6da2e2/index.json` | 38582 | `b1803cb16a6c1124ce91cf4459877208dd23c6096be8d55304709e0ef08eff7e` |
| `components-e6da2e2/pr-005-integration-handoff.json` | 2372 | `d165404a795a051a2e1e195e9e1ee7a4ec2dfdd6a307f281a0883cf06b26c95e` |
| `components-e6da2e2/pr-086-integration-handoff.json` | 2414 | `38f5eed314bec947f48927d035c343c005d46cadcd04466a279e0413b635d081` |

## Conclusion

Do not dispatch PR-087 now. First accept PR-008, then complete and independently review PR-009, PR-010, and PR-011. Bind PR-011's actual component merge M011 and handoff, then dispatch PR-087 from M011. Root composes M011 and M087 and owns the joint final gate. This preserves the existing dispatch gates, all thresholds, strict v1.0 fingerprint semantics, and an acyclic plan.
