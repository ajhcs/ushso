from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys

R=Path('/mnt/d/worktrees/plumbob/ushso-research-program-20260910');S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
head=sys.argv[1];expected_handoff=sys.argv[2]
assert len(head)==40 and len(expected_handoff)==64
implementation='0ddacd2be49f8d8df4a43bf8272385311e65722b';base='a30cd7730de04200f7cd3ffb75ca83378c9e9a1d';authority='96431eca22ddb9f33ad0244538d198624228d37a'
git=lambda *a:subprocess.check_output(['git','-C',str(R),*a],text=True).strip()
def blob(h,p):
 assert p and not p.startswith('/') and '..' not in p.split('/')
 return subprocess.check_output(['git','-C',str(R),'show',h+':'+p])
sha=lambda b:hashlib.sha256(b).hexdigest()
subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',implementation,head],check=True)
producer='8cc74ed2ffbaab5b6b009770930dbf0e6fef0f3d'
changed=git('diff','--name-only',producer,head).splitlines()
allowed_correction=['verification/research-program/pr-086/source/authority-pr086.md','verification/research-program/pr-086/source/manifest.json','docs/research-program/handoffs/PR-086.json']
assert [p for p in changed if p.startswith('verification/research-program/pr-086/') or p=='docs/research-program/handoffs/PR-086.json']==sorted(allowed_correction)
protected=['scripts/verify-wp11-attestation.mjs','tests/wp11-attestation.test.mjs','verification/research-program/ci-attestation/wp11-v1.3.0/','verification/wp11/','scripts/run-contract-suites.mjs','verification/successor-support.mjs']
assert not git('diff','--name-only',implementation,head,'--',*protected)
raw=blob(head,'docs/research-program/handoffs/PR-086.json');assert sha(raw)==expected_handoff;handoff=json.loads(raw)
packet_raw=(S/'pr086-current-input-correction-dispatch.json').read_bytes();packet=json.loads(packet_raw)
assert handoff['base_sha']==base and handoff['dependency_merge_shas']==packet['dependency_merge_shas'] and handoff['branch']==packet['branch']
binding=json.loads(blob(head,'verification/research-program/pr-086/task-binding.json'))
assert binding['binding']['base_sha']==base and binding['binding']['base_tree']==packet['base_tree']
assert binding['binding']['prompt_sha256']==sha(packet_raw) and binding['owned_paths']==packet['owned_paths']
assert handoff['status']=='producer_checked' and handoff['head_sha'] is None
artifacts=[]
for a in handoff['artifacts']:
 b=blob(head,a['path']);assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path'];artifacts.append(a['path'])
archive=json.loads(blob(head,'verification/research-program/pr-086/archive/original-r2/manifest.json'))
for a in archive['records']:
 b=blob(head,a['archive_path']);assert b==blob(base,a['original_path']);assert len(b)==a['bytes'] and sha(b)==a['sha256']
source=json.loads(blob(head,'verification/research-program/pr-086/source/manifest.json'))
for a in source['records']:
 b=blob(head,a['path']);assert len(b)==a['bytes'] and sha(b)==a['sha256']
assert blob(head,'verification/research-program/pr-086/source/authority-pr086.md')==blob(authority,'docs/master-plan/2026-09-10/prs/PR-086.md')
assert blob(head,'verification/research-program/pr-086/source/authority-decision.json')==blob(authority,'verification/research-program/bootstrap/pr086-current-inventory-scope-20260911/decision.json')
assert blob(head,'verification/research-program/pr-086/source/dispatch.json')==packet_raw
command_bindings=[]
for c in handoff['commands']:
 ref=c['event_source'];event_bytes=blob(head,ref['path']);assert len(event_bytes)==ref['bytes'] and sha(event_bytes)==ref['sha256']
 event=json.loads(event_bytes);assert event['exit_code']==c['exit_code'] and event['command']==c['command']
 stem=ref['path'].removesuffix('.json')
 for stream in ['stdout','stderr']:
  b=blob(head,stem+'.'+stream);assert len(b)==event[stream]['bytes'] and sha(b)==event[stream]['sha256']
 command_bindings.append({'id':c['id'],'exit_code':c['exit_code'],'event_source':ref})
source_receipt=S/'pr086-current-input-review-0ddacd2/receipt.json';assert sha(source_receipt.read_bytes())=='c5469dd676cc36ea9593caae8725345c74d2089be9b53e74d53d793408ba8f36'
receipt={'format':'ushso.pr086-controller-metadata-verification.v1','producer_head':producer,'controller_authored_correction':True,'independent_peer_review':'pending','recorded_at':datetime.now(timezone.utc).isoformat(),'reviewer':'Astra/root','head':head,'tree':git('rev-parse',head+'^{tree}'),'base':base,'source_implementation_head':implementation,'source_review_receipt_sha256':sha(source_receipt.read_bytes()),'source_bytes_unchanged_after_independent_review':True,'metadata_paths_changed':changed,'handoff_sha256':sha(raw),'artifact_bindings_checked':len(artifacts),'artifact_paths':artifacts,'original_packet_archive_files_verified':len(archive['records']),'authority_source_files_verified':len(source['records']),'command_event_and_stream_bindings':command_bindings,'status':'PASS_exact_source_and_artifact_bindings','live_handoff_checker':'pending fresh combined preflight execution','historical_acceptance_preserved':True,'current_approval_issued':False,'combined_acceptance':False,'requirements_accepted':[]}
out=S/('pr086-controller-metadata-verification-'+head[:7]+'.json');assert not out.exists();out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'status':receipt['status'],'artifacts':len(artifacts)}))
