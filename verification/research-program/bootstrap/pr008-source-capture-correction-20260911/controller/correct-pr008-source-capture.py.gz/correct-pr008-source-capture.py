from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
task = 'ushso-pr006-pr008-combined-20260911'
base = 'fdeed22bc052dbc88544001a2270fe79df32ddc9'
producer = '911aff5588ea59b12b81b58f1d5e07ce09a987d3'
original_base = 'a00630c712e3a4e64354a77d268cb168fa3f528a'
destination = 'verification/research-program/bootstrap/pr008-source-capture-correction-20260911'
D = R / destination
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
now = lambda: datetime.now(timezone.utc).isoformat()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', task, '--repo', str(R), '--require-writer'], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain')
assert not D.exists()
D.mkdir(parents=True)
artifacts = []
def retain(name, raw, origin):
    p = D / name
    p.parent.mkdir(parents=True, exist_ok=True)
    encoded = gzip.compress(raw, mtime=0)
    p.write_bytes(encoded)
    artifacts.append({'path': p.relative_to(R).as_posix(), 'bytes': len(encoded), 'sha256': sha(encoded), 'decoded': {'bytes': len(raw), 'sha256': sha(raw), 'encoding': 'gzip'}, 'origin': origin})

old_cp = (S / 'corrected-components-final-candidate.json').read_bytes()
assert json.loads(old_cp)['head'] == base
retain('prior-composition.json.gz', old_cp, 'controller exact prior composition receipt')
for p in sorted((S / 'corrected-components-preflight-fdeed22').iterdir()):
    assert p.is_file()
    retain('failed-preflight/' + p.name + '.gz', p.read_bytes(), 'actual first preflight on ' + base)
for name in ['preflight-corrected-components-fdeed22.py', 'verify-pr086-controller-metadata-correction.py', 'pr086-controller-metadata-verification-fdeed22.json', 'correct-pr008-source-capture.py']:
    retain('controller/' + name + '.gz', (S / name).read_bytes(), 'controller procedure or exact observed result; not separate peer review')

hp = 'docs/research-program/handoffs/PR-008.json'
prior = (R / hp).read_bytes()
assert sha(prior) == 'a4e95054c6c3b0a3bebd220b91af8878a023c6f674ad0080aff195d6182a0f83'
retain('prior-producer-handoff.json.gz', prior, producer + ':' + hp)
assignment = 'docs/master-plan/2026-09-10/prs/PR-008.md'
original = subprocess.check_output(['git', 'show', original_base + ':' + assignment])
assert original == subprocess.check_output(['git', 'show', producer + ':' + assignment])
assert sha(original) == '3cbe2a930913f90734294ffe3c9b1e76fad03d55795dd833c10e59b0cf8627d1'
current = subprocess.check_output(['git', 'show', base + ':' + assignment])
assert current == (R / assignment).read_bytes()
assert sha(current) == 'c822187d88e97c6a494a2e4df2dfabbb46aa3ae10da2d97f6958f1c364b63b83'
captures = [('original-assignment.md', original, original_base), ('amended-assignment.md', current, base)]
for name, raw, _ in captures:
    (D / name).write_bytes(raw)

h = json.loads(prior)
source = next(x for x in h['source_identities'] if x['id'] == assignment)
source['id'] = destination + '/original-assignment.md'
source['version'] = original_base + ':' + assignment + '; exact original assignment bytes, preserved separately from the later package-completion amendment'
h['source_identities'].append({'kind': 'local-pr008-package-completion-amended-assignment', 'id': destination + '/amended-assignment.md', 'location': 'local', 'sha256': sha(current), 'version': base + ':' + assignment + '; exact amended controller assignment; does not replace historical dispatch'})
for name, raw, _ in captures:
    h['artifacts'].append({'id': 'controller-pr008-' + name.replace('.', '-'), 'path': destination + '/' + name, 'bytes': len(raw), 'sha256': sha(raw)})
h['unresolved_claims'].append({'id': 'controller-assignment-source-portability-review', 'status': 'pending', 'detail': 'Controller copied the exact original and amended assignments from named Git objects and changed only the original local source locator. The first combined preflight failure and original producer handoff remain retained. Separate review of this controller-authored metadata correction is pending; no product, test, policy, package lock, producer command, or scientific acceptance claim changed.'})
(R / hp).write_text(json.dumps(h, indent=2) + '\n')

ledger_path = R / 'docs/research-program/execution-ledger.json'
retain('prior-ledger.json.gz', ledger_path.read_bytes(), base + ':docs/research-program/execution-ledger.json')
ledger = json.loads(ledger_path.read_text())
t = next(x for x in ledger['tasks'] if x['pr_id'] == 'PR-008')
t['status'] = 'independent_review'
t['controller_metadata_correction'] = destination + '/metadata-correction.json'
t['blockers'].append({'id': 'CONTROLLER-SOURCE-METADATA-REVIEW', 'kind': 'independent_review', 'detail': 'Exact original/amended assignment snapshots correct the stale live-source locator; separate review remains pending.'})
controller = ledger['controller']
controller['next_component_candidate']['status'] = 'local_composition_source_metadata_corrected_gate_and_peer_review_pending'
controller['next_component_candidate']['prior_preflight_failure'] = destination + '/failed-preflight/receipt.json.gz'
controller['next_component_candidate']['source_metadata_correction'] = destination + '/metadata-correction.json'
ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')
correction = {'format': 'ushso.pr008-controller-source-correction.v1', 'recorded_at': now(), 'author': 'Astra/root', 'candidate_before': base, 'producer_head': producer, 'original_assignment_commit': original_base, 'amended_assignment_commit': base, 'original_assignment_path': assignment, 'captures': [{'path': destination + '/' + name, 'source_commit': commit, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw, commit in captures], 'failure': 'stale_source_identity_sha: original PR008 assignment reference resolved to the later amended assignment in the combined checkout', 'changed_producer_files': [hp], 'prior_handoff': destination + '/prior-producer-handoff.json.gz', 'product_test_policy_and_package_bytes_changed': False, 'separate_peer_review': 'pending', 'accepted': False}
(D / 'metadata-correction.json').write_text(json.dumps(correction, indent=2) + '\n')
metadata_files = [{'path': destination + '/' + name, 'bytes': (D / name).stat().st_size, 'sha256': sha((D / name).read_bytes())} for name in ['original-assignment.md', 'amended-assignment.md', 'metadata-correction.json']]
index = {'format': 'ushso.independent-review-portable-index.v1', 'recorded_at': now(), 'producer_head': producer, 'artifacts': artifacts, 'metadata_files': metadata_files, 'peer_metadata_review_pending': True, 'accepted': False}
(D / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for a in h['artifacts']:
    b = (R / a['path']).read_bytes()
    assert len(b) == a['bytes'] and sha(b) == a['sha256']
subprocess.run(['git', 'diff', '--check'], check=True)
changed = git('diff', '--name-only').splitlines()
assert set(changed) == {hp, 'docs/research-program/execution-ledger.json'}, changed
subprocess.run(['git', 'add', '--', hp, 'docs/research-program/execution-ledger.json', destination], check=True)
subprocess.run(['git', 'commit', '-m', 'Preserve exact PR008 assignment source versions'], check=True)
assert not git('status', '--porcelain')
cp = json.loads(old_cp)
cp.update({'recorded_at': now(), 'base': base, 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'additional_indices': [{'path': destination + '/index.json', 'bytes': (D / 'index.json').stat().st_size, 'sha256': sha((D / 'index.json').read_bytes())}], 'pr008_handoff_sha256': sha((R / hp).read_bytes()), 'prior_preflight': destination + '/failed-preflight/receipt.json.gz', 'fresh_dependency_install_required': False, 'metadata_only_since_fresh_install': True, 'preflight_pending': True})
archive = S / 'corrected-components-final-candidate-fdeed22.json'
assert not archive.exists()
archive.write_bytes(old_cp)
(S / 'corrected-components-final-candidate.json').write_text(json.dumps(cp, indent=2) + '\n')
print(json.dumps(cp), flush=True)
