from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,gzip,subprocess,time

R=Path.cwd();S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910');D=S/'corrected-components-preflight-fdeed22'
task='ushso-corrected-components-review-20260911';head='fdeed22bc052dbc88544001a2270fe79df32ddc9';tree='4545c7ad3622f929b9762fbaea2d68b2d7449e22'
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
cp=json.loads((S/'corrected-components-final-candidate.json').read_text());assert cp['head']==head and cp['tree']==tree
assert not D.exists();D.mkdir()
artifacts=0
for pr,producer in cp['producer_heads'].items():
 subprocess.run(['git','merge-base','--is-ancestor',producer,head],check=True)
 h=json.loads((R/'docs/research-program/handoffs'/f'{pr}.json').read_text())
 for a in h['artifacts']:
  b=(R/a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path'];artifacts+=1
index=cp['index'];b=(R/index['path']).read_bytes();assert len(b)==index['bytes'] and sha(b)==index['sha256'];idx=json.loads(b)
for a in idx['artifacts']:
 b=(R/a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'];raw=gzip.decompress(b);assert len(raw)==a['decoded']['bytes'] and sha(raw)==a['decoded']['sha256'];artifacts+=1
for a in idx['metadata_files']:
 b=(R/a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'];artifacts+=1
frozen={'evaluation/research-program/cohorts.json':'89130236f7a4c59d3d03a8c1c9aa3a3af93bef8289b1f337c2e52baca52fa543','evaluation/research-program/tasks.json':'4fc5c7fe2a5b51da4bf5ae8e348949a33f26c1758d7a18065e7c5611d1efcedc','docs/research-program/acceptance.md':'625271093e73108959d56f7647107b96ea3398c8555c59a654a53717721a4cc7','docs/master-plan/2026-09-10/plan.json':'a30e035fc1cf883e7e789487cb3ec0aebde1ddb58177556b9b16f9811d271ef8','package-lock.json':'f90550e267d390cb7fc328319f0d2cf849b76a9e52b5e83f6eefc4a045d58ec8'}
for p,h in frozen.items():assert sha((R/p).read_bytes())==h,p
assert not git('diff','--name-only','8a9b921fa4be059624606116ed5ad33c238bb9ab',head,'--','apps/web/src/','packages/search/static-search-backend.mjs','packages/retrieval/tools/retrieval-core-v1.2.mjs')
node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
checks=[
 ('facet-engine',[node,str(S/'pr006-controller-facet-cases.mjs'),str(R)]),
 ('variable-semantics',[node,str(S/'pr008-controller-cases.mjs'),str(R),str(D/'variable-semantics.json')]),
 ('variable-parent-chain',[node,str(S/'pr008-controller-parent-chain-cases-v3.mjs'),str(R),str(D/'variable-parent-chain.json')]),
 ('wp11-current-inputs',[node,str(S/'pr086-controller-current-input-cases.mjs'),str(R),str(D/'wp11-current-inputs.json')]),
 ('subject-shortcircuit',[node,'--test','tests/subject-shortcircuit.test.mjs']),
 ('contract-inventory',[node,'--test','tests/contract-package-inventory.test.mjs']),
 ('variable-contract-tests',['npm','test','--workspace','contracts/machine-toolkit/v1.2.0']),
 ('variable-contract-validation',['npm','run','validate','--workspace','contracts/machine-toolkit/v1.2.0']),
 *[(pr.lower()+'-handoff',[node,'scripts/research-program/check-handoff.mjs','docs/research-program/handoffs/'+pr+'.json']) for pr in ['PR-006','PR-008','PR-086']],
]
commands=[]
for label,args in checks:
 started=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 try:
  p=subprocess.run(args,capture_output=True,timeout=240);code=p.returncode;streams={'stdout':p.stdout,'stderr':p.stderr}
 except subprocess.TimeoutExpired as e:code=124;streams={'stdout':e.stdout or b'','stderr':(e.stderr or b'')+b'\nController timeout240s\n'}
 bindings={}
 for name,b in streams.items():
  filename=label+'.'+name+'.log';(D/filename).write_bytes(b);bindings[name]={'path':filename,'bytes':len(b),'sha256':sha(b)}
 commands.append({'label':label,'argv':args,'started_at':started,'duration_seconds':time.monotonic()-t,'exit_code':code,'streams':bindings});print(json.dumps({'label':label,'exit_code':code}),flush=True)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
ok=all(c['exit_code']==0 for c in commands)
receipt={'format':'ushso.corrected-components-preflight.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'head':head,'tree':tree,'repo':str(R),'task':task,'commands':commands,'artifact_bindings_checked':artifacts,'frozen_sha256':frozen,'fresh_managed_locked_install':True,'prior_browser_evidence':'PR0067e58195 plus a30 combined browser checks remain prior-head evidence; frontend bytes are proven unchanged. No new Chrome run claimed in this preflight. The full new gate includes its own candidate E2E stage.','status':'ready_for_exact_candidate_gate' if ok else 'changes_requested','peer_metadata_review_pending':True,'gate_pending':True,'hosted_ci_pending':True,'accepted':False,'requirements_accepted':[]}
p=D/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p.read_bytes()),'status':receipt['status'],'artifact_bindings_checked':artifacts}),flush=True)
raise SystemExit(0 if ok else 1)
