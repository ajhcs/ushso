Independently confirmed the live facet path, the 3434/3430/4 isolated-record accounting, and the frozen discovery-result contract. PR006 is not ready to dispatch as originally scoped.

## Git identity

| Field | Value |
|---|---|
| HEAD / base | `7e64de95fe78013a954cca49543498d6d9ebbbdb` |
| tree | `eecf9d62024f0c725e3dc54a7c30a711883eca6e` |
| branch | `codex/ce-ushso-pr006-scope-review-pr006-scope-and-absence--4baf2ecefd03-bf99da51` |
| worktree | clean |
| plan.json SHA-256 | `380f3bed7fc5c9135d2000ba8f4a477e7348819f222298b441ff254ea99625f3` |

Matches the assigned root checkpoint. No source edits, commits, PRs, pushes, live collection, holdout labels, deployment, requirement acceptance, or implementation approval.

Local catalog-contract replay of the frozen v1.2.0 shards: **3434 / 3430 / 4**. The four CDC IDs fail **only** `description must be a non-empty string`. Shard hashes match PR002/PR006 pins.

## 1. Additional owned paths for live + fallback facets

Original PR-006 owned scope (`catalog-contract.mjs`, `packages/coverage/`, `FacetSidebar.tsx`, `data/facets.ts`) cannot fix live labels or availability.

Live path:

- `packages/retrieval/tools/retrieval-core-v1.2.mjs:400-416` builds API facets **before pagination**, with `label: value` (canonical IDs copied into visible copy). Source values are `source_id`; capability values are topic/use-case **ids**.
- `apps/web/src/pages/SearchResultsPage.tsx:152-154` maps `discovery.result.facets.sections` into `FacetSidebar` and calls `buildFacetSections` **only when API facets are absent**.
- `apps/web/src/providers/discoveryProvider.ts:122-137` validates section `id`/`label` and option `value`/`label`/`count` only. No availability, disabled, or explanation.
- `apps/web/src/types/discovery.ts:32-49` has the same gap. `FacetOption.disabled` exists only on the UI type (`apps/web/src/types/catalog.ts:102-115`).
- `FacetSidebar.tsx:22-33` renders supplied labels and per-option `disabled` only. No section availability, no explanation, no explicit selected/unavailable accessible name (native checkbox + `{label} ({count})`).

Fallback path (still required, not the live default):

- `apps/web/src/data/facets.ts:33-64,75-107` and `apps/web/src/lib/catalogAdapter.ts:173-185,261-271,301` build different section IDs (`access` vs live `access_status`; `data-category` vs live `capability`) and map `US` → `national` **and** `other-states`.

**Minimal added owned paths**

| Path | Why |
|---|---|
| `packages/retrieval/tools/retrieval-core-v1.2.mjs` | Live labels, unknown-only/unavailable, include-unknown matching, pre-pagination counts |
| `apps/web/src/providers/discoveryProvider.ts` + `.test.ts` | Actual response contract |
| `apps/web/src/pages/SearchResultsPage.tsx` + `.test.tsx` | Live propagation; current tests have **no** facet cases |
| `apps/web/src/types/discovery.ts`, `apps/web/src/types/catalog.ts` | Additive availability only if the API grows those fields |
| `apps/web/src/data/facets.ts` + existing `facets.test.ts` | Fallback only |
| `apps/web/src/components/FacetSidebar.tsx` + a focused test | Unavailable explanation; selected/unavailable names |
| `apps/web/src/lib/catalogAdapter.ts` | Fallback geography/access only; **not** the live label path |
| `tests/research-program/isolation-and-facets.test.mjs` | New isolation/facet regressions (does not exist) |

**Shared-contract ownership (must resolve before editing)**

- `packages/retrieval/schemas/discovery-result.schema.json:74` (`$id` `.../v1.0.0/discovery-result.schema.json`, `contract_version` `observatory-discovery-result.v1.0.0`) sets facet section/option `additionalProperties: false` and required `{value,label,count}` only. Adding availability/disabled/explanation needs a **new versioned discovery-result successor**, not a silent extra field and not a rewrite of the frozen pin (`packages/retrieval/manifests/corpus-manifest.json:120-123`, historical 143-record corpus).
- Label-only changes can stay inside the existing `label` string. Availability cannot.
- `apps/web/src/pages/SourcesPage.tsx:45-51` already displays live `source` option labels; regression-test it, do not treat it as a second label mapper.
- `worker/index.mjs:175-189` and `searchParams.ts` keep canonical `section:value`. Leave them unless encoding changes.
- `tests/fixtures/direct-base-control.mjs:395-412` duplicates `facetResponse`; keep in sync or it will drift. Not a production owner.

`packages/coverage/` as a whole is too broad. PR-004 already published the four IDs in `verification/research-program/pr-004/completeness-view.json.gz` (`membership.record_count=3434`, `isolated_count=4`, `isolation_reason=description must be a non-empty string`). PR-006 should consume that accounting, not republish coverage.

## 2. What typed accounting of the four IDs can do without a new publication/schema migration

The four IDs are already retained:

- Frozen PR-002: `evaluation/research-program/cohorts.json` corpus `isolated_record_ids` (lines 25-30), `baseline_records` length **3434** with **4** `isolated: true`. They are **not** among the 100-product representative IDs.
- Catalog-contract: `browserRecordErrors` at `catalog-contract.mjs:87`; `validateCatalogRecords` emits `invalid_catalog_record` (`137-158`). Retrieval then searches only `catalogValidation.valid` (`retrieval-core-v1.2.mjs:457-461,523,596`).
- PR-004 evidence.json and completeness-view already name the same four IDs and the same sole error.

Without inventing descriptions, changing source bytes, or relaxing the current browser contract, typed accounting can:

- Keep identity, publisher, native ID, authoritative URL, hashes, and the exact error.
- Keep **3434 enumerated / 3430 searchable / 4 isolated**.
- Keep them out of search/facets while remaining in the baseline denominator.
- Add regression tests that those four IDs still fail only nonempty description, still appear in `partial_results`, and never vanish from PR-002 baseline membership.

It cannot: make them searchable, repair missing source text, prove payload access, or change frozen PR-002 product/baseline IDs.

## 3. Missing-description migration is not required under PR-006 / R01

R01 is disposition of all **3434** baseline IDs with no silent loss (`MASTER-PLAN.md:31`), not promotion into the searchable set. PR-006’s stated outcome is “Source defects are visible without making missing values useful filters.” C-006-1’s “if appropriate” already makes a versioned missing-description **state** optional.

A migration is **not** necessary for R01. Current isolation already is a typed failed/incompatible disposition. C-006-1’s “before and after migration” wording overreaches.

Do **not** treat `observatory-record-compatibility.v1.0.1` as authority to empty `description`. That schema allows `description: {type: string}` with no `minLength` (`observatory-record-compatibility.v1.0.1.schema.json:31`) and validates the distinct historical **143**-record corpus (`legacy-schema-compatibility.test.mjs:29-30`; ADR 0006). Current browser contract still requires nonempty description (`browser-record.schema.json:12`; `catalog-contract.mjs:87`).

If a missing-description representation is later proposed, name a **new current** boundary before any edit, for example a successor `$id` such as `browser-record.v1.1.0` / a current observatory-record missing-description state, with an explicit compatibility receipt. Do **not** repin:

- historical `observatory-record.schema.json` digest `2d778a3125ba03c7504aad92e7154fdedf686db66619e439a6259ba883e162d9`
- `observatory-record-compatibility.v1.0.1`
- frozen `discovery-result.schema.json` / 143-record corpus
- frozen PR-002 `cohorts.json` IDs/denominators or v1.2.0 record shards

## 4. Decisive tests

1. **No row loss.** Frozen PR-002 3434 baseline IDs remain; the four isolated IDs stay present with `isolated: true` / `invalid_catalog_record` / nonempty-description error; 3434/3430/4 reconciles; record SHA-256s unchanged (`073c287c…`, `6003e6e4…`, `d2ada7f1…`, `53289cfe…`). Do not invent descriptions.
2. **Discriminability vs unknowns.** Live corpus geography is `coverage_level=unknown`, `jurisdictions=[]` on **all 3434** rows. Live access is `public_catalog` on **all 3434**. Both live facets are non-discriminating. Unknown-only geography must be unavailable with an explanation and must not imply national coverage. Uniform `public_catalog` must not pretend to narrow the catalog or prove payload access. Mixed known/unknown fixtures need a real include-unknown option whose counts/IDs do not change when unknown is excluded vs included as specified. Filtering `geography:unknown` today would keep every valid row (`retrieval-core-v1.2.mjs:579-586`).
3. **Canonical round-trips.** URL/API `filter` values stay canonical (`source:cdc-socrata`, not the display name). Source labels may use captured names (`cdc-socrata` → `Centers for Disease Control and Prevention Data Catalog`, etc.). Capability labels may use captured `capability.label`, never use-case IDs as visible copy. Same record IDs before/after filter round-trip; `count_basis=records`, `collection_scope=all_matching_records_before_pagination`.
4. **Truthful geography.** Do not map unresolved geography or publisher jurisdiction to national/PA/`other-states`. Fallback `catalogAdapter.ts:177-179` currently does. Live path currently emits raw `unknown`.
5. **Accessible selected/unavailable.** Screen-reader names must identify meaning, selected state, and unavailable-with-reason. Current `FacetSidebar` has none of that beyond a native checkbox and `label (count)`.

Keep existing `npm run test:web` and `npm run test:retrieval`. `facets.test.ts` only covers the fallback `buildFacetSections` path.

## Mistakes in the root scope note

- Filename: `PR-006-SCOPE-PREPARATION.md:5` cites `pr006-readonly-readiness-preparation.json`; the file is `pr006-readonly-preparation.json` (format id uses “readiness”).
- SHA mix: note `a11c675b…`, JSON head `3355015b…`, this checkout `7e64de95…`. Pinned source bytes still match this HEAD.
- JSON gap that live labels “flow through catalogAdapter” is wrong. Live path is `SearchResultsPage.tsx:152-154`.
- Proposed additions omit the frozen `discovery-result.schema.json` `additionalProperties: false` boundary. Availability needs a named successor, not an in-place edit.
- Live access is uniformly `public_catalog`, not an unknown token. Unavailability is discriminability, which the note states later but the JSON/fixtures language underspecifies.
- Original C-006-1 “after migration” is not required for R01; the note prefers isolated disposition but should say migration is out of scope unless a new current schema is named.
- `packages/coverage/` remains too broad; PR-004 already accounted for the four IDs.

## Scope recommendation

**Do not dispatch or implement PR-006.** PR-005 remains unaccepted pending PR-086/combined acceptance. Do not mark those prerequisites satisfied.

Amend the packet before any implementation assignment:

- Add the live facet owners and the discovery-result **successor** ownership question.
- Keep C-006-1 as typed isolated accounting + regression tests on the four frozen IDs; **no** source publication, **no** description invention, **no** current browser-schema relaxation.
- Keep C-006-2/C-006-3 on **both** live `facetResponse` and fallback `buildFacetSections`, with canonical values unchanged.
- Preserve every frozen PR-002 ID/denominator (100 products, 3434 baseline, 4 isolated IDs, shard hashes).
- Do not use historical compatibility, frozen 143-record artifacts, or current discovery-result pins as generic repin targets.

This is a scope review only. It does not accept R01/R02, close F04/F17/F24, or authorize PR-006 implementation.