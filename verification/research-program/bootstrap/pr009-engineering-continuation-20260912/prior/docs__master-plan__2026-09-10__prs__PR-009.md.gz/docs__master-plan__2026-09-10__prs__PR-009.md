# PR-009 — Set evidence storage and verification operating bounds

Phase **P1**, sub-phase **1C**. Status: planned.

Collection, sample retention and infrastructure decisions are explicit and cost bounded.

**Dependencies:** PR-003, PR-004, PR-007, PR-008

**Implementer:** Luna Max, Grok or DeepSeek; assign one owner at dispatch. **Reviewer:** Astra; named human domain/owner decision when required.

**Acceptance requirements:** R03, R14, R15, R16. **Audit findings:** F03, F13, F32, F33.

## Before editing

Read [EXECUTION.md](../EXECUTION.md), the dependency handoffs and the current repository instructions. Start from the merged integration SHA selected in PR-001, not the stale original workspace. Confirm the paths below in that release; create a new path only when it is named here. If an existing package supplies the required behavior, extend it instead of creating a parallel subsystem.

**Owned scope:**

- `docs/adr/0008-operating-bounds-and-evidence-receipts.md`
- `docs/adr/README.md`
- `scripts/research-program/policy.json`
- `scripts/research-program/operating-bounds.mjs`
- `scripts/research-program/receipts/v1.0.0/evidence-receipt.schema.json`
- `scripts/research-program/receipts/v1.0.0/README.md`
- `tests/research-program/operating-bounds.test.mjs`
- `tests/research-program/fixtures/pr009-census-negative/`

If a shared contract or another owner’s file must change, record the proposed interface change and resolve ownership before editing it. Keep each commit independently understandable and passing the checks appropriate to that change.

## Atomic commits

### C-009-1 — Reconcile the architecture decisions

Write a successor ADR for the cheapest measured control-plane/publication topology using existing PostgreSQL interfaces. Compare retained publication measurements and timestamped public prices with explicit workload, rights and recovery constraints; mark missing actual usage, bill and capacity facts as unresolved rather than inventing a cheapest result. Preserve the current static public runtime. Identify retained metadata storage versus a separately gated aggregate sample store; do not create paid resources or production bindings. A partial policy/receipt implementation does not by itself satisfy the measured topology decision.

**Verify:** List exact earlier ADR clauses superseded; no paid resource or production binding is created by a documentation decision.

### C-009-2 — Define request and retention budgets

Define scripts/research-program/policy.json and a pure operating-bounds.mjs validator/composer using existing connector and ingestion exports as read-only dependencies. Specify descriptor/route IDs, per-source concurrency, timeout, redirect, raw/expanded-byte, row, retry and retention limits. Keep activation false; reject arbitrary user URLs and unauthorized operation classes. Ninety days is the active raw metadata/documentation default, with explicit evidenced shorter/longer source-policy overrides; retain existing dependency-aware GC and 365-day security/audit protections. Keep aggregate/sample rights and privacy decisions separate. No connector/ingestion code, live request, receipt persistence, DB, queue, workflow or deletion activation is owned here.

**Verify:** Policy fixtures reject missing/foreign route identities, arbitrary URLs, unbounded limits, unauthorized retention classes and activation. Use actual current descriptor, response-bound, retry and retention semantics without creating duplicate execution logic. Underlying strict ingestion records validate unchanged; no matching contract version may be assumed without schema validation.

### C-009-3 — Implement the evidence receipt contract

Add a self-contained strict JSON Schema 2020-12 receipt at scripts/research-program/receipts/v1.0.0/evidence-receipt.schema.json plus its boundary README and registered operating-bounds.test.mjs. Compose request type/expected-content basis, safe final locator, scoped actual bytes/hash, source/parser identity, attempt outcome and next action without secrets or body content. Preserve all released ingestion contracts, connector/ingestion packages and WP5 v1.0.0 bytes. Consume the retained Census fixture as an unmatched historical negative observation: do not fabricate approved metadata route IDs, original expectations, connector execution or an unrecorded redirect count. Durable persistence remains PR010/011 scope.

**Verify:** Replay the committed retained Census 200-HTML body/hash as an access/content failure with unknown redirect count, not capture/payload/schema success. Test accepted capture, 304 reuse, access-only, pre-egress, typed failure and truncation separately. Truncated bytes never imply complete schema validation. Independently validate underlying strict records, identity/hash/size consistency and absent-secret/body boundaries; no transport or persistent side effect occurs.

## PR acceptance

- Infrastructure plan includes measured costs and unresolved external facts.
- Current no-source-egress public request boundary remains enforced.

Use the existing affected package tests plus the specific fixtures described below. Add meaningful regression/integration tests for behavior changes; documentation-only commits use link, schema or artifact checks. Full npm test/build/cf:dry-run run at the integration/release gate.

Run these commands from the isolated repository root after implementing the specified tests. They are planned verification commands, not checks executed by this planning task:

```bash
node --test tests/research-program/operating-bounds.test.mjs
```

The implementation must demonstrate the behavior above using actual fixtures or retained execution evidence. A source capture is not a payload test; a passing schema is not scientific approval; a successful tool envelope is not a completed research task.

## Handoff and independent review

Write the sanitized evidence index under `verification/research-program/pr-009/` and the task-specific handoff under `docs/research-program/handoffs/PR-009.json`. Follow the [handoff template](../templates/handoff.json). Include exact base/head and dependency SHAs; commands with exit statuses; fixtures and expected/actual results; changed public behavior; source/generation identity; artifact hashes; failures; remaining questions; and the next consumer.

Push the task branch to GitHub and open/update a draft PR using the [PR body template](../templates/pr-body.md). Do not mark it ready until producer checks and handoff validation pass. Astra independently inspects the diff and replays the decisive acceptance checks; producer logs alone are not approval. Retain a failing result when blocked and identify the exact missing input. Do not auto-merge or deploy.
