# PR-077 — Measure indexing, delivery capacity and operating cost

Phase **P8**, sub-phase **8A**. Status: planned.

Runtime and storage choices are justified by current-cardinality measurements.

**Dependencies:** PR-024, PR-030, PR-053, PR-063, PR-074, PR-076

**Implementer:** Luna Max, Grok or DeepSeek; assign one owner at dispatch. **Reviewer:** Astra; named human domain/owner decision when required.

**Acceptance requirements:** R14, R15, R16. **Audit findings:** F30, F32.

## Before editing

Read [EXECUTION.md](../EXECUTION.md), the dependency handoffs and the current repository instructions. Start from the merged integration SHA selected in PR-001, not the stale original workspace. Confirm the paths below in that release; create a new path only when it is named here. If an existing package supplies the required behavior, extend it instead of creating a parallel subsystem.

**Owned scope:**

- `packages/search/`
- `scripts/research-program/capacity.mjs`
- `verification/research-program/performance/`
- `docs/research-program/costs.md`

If a shared contract or another owner’s file must change, record the proposed interface change and resolve ownership before editing it. Keep each commit independently understandable and passing the checks appropriate to that change.

## Atomic commits

### C-077-1 — Define the real workload and budgets

Pin corpus/dictionary sizes, query mix, cold/warm definitions, concurrency, regions, response sizes and source-job contention. Compare existing deployment requirements with proposed SLOs explicitly.

**Verify:** No accepted old performance gate is silently weakened; targets and cost ceilings are named before measurement.

### C-077-2 — Benchmark bounded indexed delivery

Measure actual candidate query/detail/variables/MRF metadata paths at current and twice planned load. Profile memory/CPU/storage/asset counts and compare any proposed index/cache topology.

**Verify:** A small fixture or warm-only average cannot qualify cold starts or production capacity; output parity remains exact.

### C-077-3 — Choose and document the measured topology

Retain the lowest-cost option satisfying quality, capacity and rollback requirements. Prepare any required ADR/procurement change with evidence instead of assuming premium infrastructure.

**Verify:** Report steady and burst costs, provider fees, storage and review operations; failed targets remain unresolved until fixed.

## PR acceptance

- Performance results distinguish browser time, edge/network latency and upstream collection.
- No source acquisition happens during a user search.

Use the existing affected package tests plus the specific fixtures described below. Add meaningful regression/integration tests for behavior changes; documentation-only commits use link, schema or artifact checks. Full npm test/build/cf:dry-run run at the integration/release gate.

The implementation must demonstrate the behavior above using actual fixtures or retained execution evidence. A source capture is not a payload test; a passing schema is not scientific approval; a successful tool envelope is not a completed research task.

## Handoff and independent review

Write the sanitized evidence index under `verification/research-program/pr-077/` and the task-specific handoff under `docs/research-program/handoffs/PR-077.json`. Follow the [handoff template](../templates/handoff.json). Include exact base/head and dependency SHAs; commands with exit statuses; fixtures and expected/actual results; changed public behavior; source/generation identity; artifact hashes; failures; remaining questions; and the next consumer.

Push the task branch to GitHub and open/update a draft PR using the [PR body template](../templates/pr-body.md). Do not mark it ready until producer checks and handoff validation pass. Astra independently inspects the diff and replays the decisive acceptance checks; producer logs alone are not approval. Retain a failing result when blocked and identify the exact missing input. Do not auto-merge or deploy.
