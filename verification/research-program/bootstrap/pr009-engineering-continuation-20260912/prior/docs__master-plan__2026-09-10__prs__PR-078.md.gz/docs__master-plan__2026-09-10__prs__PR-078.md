# PR-078 — Verify recovery, retention and production configuration

Phase **P8**, sub-phase **8A**. Status: planned.

The system can recover without losing evidence or silently changing public truth.

**Dependencies:** PR-009, PR-030, PR-059, PR-076, PR-077

**Implementer:** Luna Max, Grok or DeepSeek; assign one owner at dispatch. **Reviewer:** Astra; named human domain/owner decision when required.

**Acceptance requirements:** R02, R15, R16. **Audit findings:** F31, F32.

## Before editing

Read [EXECUTION.md](../EXECUTION.md), the dependency handoffs and the current repository instructions. Start from the merged integration SHA selected in PR-001, not the stale original workspace. Confirm the paths below in that release; create a new path only when it is named here. If an existing package supplies the required behavior, extend it instead of creating a parallel subsystem.

**Owned scope:**

- `infra/recovery/`
- `docs/research-program/operations.md`
- `verification/research-program/recovery/`
- `worker/index.mjs`

If a shared contract or another owner’s file must change, record the proposed interface change and resolve ownership before editing it. Keep each commit independently understandable and passing the checks appropriate to that change.

## Atomic commits

### C-078-1 — Exercise evidence and publication recovery

Restore a staged evidence/accepted-metadata snapshot and return to N−1 publication using existing recovery ports. Preserve attempts and review histories.

**Verify:** Measure actual restore/rollback time; a configuration file or backup listing alone is not a recovery drill.

### C-078-2 — Verify retention and key operation

Check sample/metadata retention classes, quota behavior, job stop/replay, credential rotation and cursor invalidation through scoped tests. Keep secrets out of logs.

**Verify:** Deletion/rotation tests use fixtures or staging; historical approved evidence is not erased to make integrity checks pass.

### C-078-3 — Resolve configuration and console inconsistencies

Decide whether the unwanted Insights injection should be removed or intentionally configured under the site’s privacy/CSP policy. Align health/readiness signals with actual dependencies.

**Verify:** Fresh browser captures show the selected behavior without unexpected script errors; CSP is not broadly weakened as a shortcut.

## PR acceptance

- Operational documentation matches actual tested configuration.
- Failure recovery cannot publish pending scientific claims.

Use the existing affected package tests plus the specific fixtures described below. Add meaningful regression/integration tests for behavior changes; documentation-only commits use link, schema or artifact checks. Full npm test/build/cf:dry-run run at the integration/release gate.

Run these commands from the isolated repository root after implementing the specified tests. They are planned verification commands, not checks executed by this planning task:

```bash
npm run test:worker
```

The implementation must demonstrate the behavior above using actual fixtures or retained execution evidence. A source capture is not a payload test; a passing schema is not scientific approval; a successful tool envelope is not a completed research task.

## Handoff and independent review

Write the sanitized evidence index under `verification/research-program/pr-078/` and the task-specific handoff under `docs/research-program/handoffs/PR-078.json`. Follow the [handoff template](../templates/handoff.json). Include exact base/head and dependency SHAs; commands with exit statuses; fixtures and expected/actual results; changed public behavior; source/generation identity; artifact hashes; failures; remaining questions; and the next consumer.

Push the task branch to GitHub and open/update a draft PR using the [PR body template](../templates/pr-body.md). Do not mark it ready until producer checks and handoff validation pass. Astra independently inspects the diff and replays the decisive acceptance checks; producer logs alone are not approval. Retain a failing result when blocked and identify the exact missing input. Do not auto-merge or deploy.
