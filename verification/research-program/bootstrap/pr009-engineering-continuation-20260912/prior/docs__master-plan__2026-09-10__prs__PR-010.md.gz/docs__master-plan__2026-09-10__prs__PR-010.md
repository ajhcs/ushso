# PR-010 — Connect durable collection jobs to existing ingestion ports

Phase **P2**, sub-phase **2A**. Status: planned.

Bounded collection jobs resume safely and have durable outcomes.

**Dependencies:** PR-009

**Implementer:** Luna Max, Grok or DeepSeek; assign one owner at dispatch. **Reviewer:** Astra; named human domain/owner decision when required.

**Acceptance requirements:** R03, R15. **Audit findings:** F32.

## Before editing

Read [EXECUTION.md](../EXECUTION.md), the dependency handoffs and the current repository instructions. Start from the merged integration SHA selected in PR-001, not the stale original workspace. Confirm the paths below in that release; create a new path only when it is named here. If an existing package supplies the required behavior, extend it instead of creating a parallel subsystem.

**Owned scope:**

- `packages/ingestion/`
- `services/scheduler-worker/`
- `services/harvest-worker/`
- `tests/research-program/job-lifecycle.test.mjs`

If a shared contract or another owner’s file must change, record the proposed interface change and resolve ownership before editing it. Keep each commit independently understandable and passing the checks appropriate to that change.

## Atomic commits

### C-010-1 — Add a collection job specification

Reuse ingestion run/outbox/lease primitives and add source ID, exact configuration hash, selected record IDs, capture class and budget reservation. Keep scheduling separate from execution.

**Verify:** Duplicate schedule deliveries create one logical job; changing configuration produces a distinct job identity.

### C-010-2 — Implement the collector port adapter

Connect existing research collector entry points through injected storage/network/clock ports. Checkpoint after bounded units and close database work between steps.

**Verify:** Interrupt after a successful capture and resume without duplicate source requests or losing the capture reference.

### C-010-3 — Expose dry-run and local execution commands

Add a CLI that lists selected jobs and estimated limits before running. Emit terminal statuses and resumable checkpoint locations.

**Verify:** An intern can run a fixture job through selected, running, partial and complete states; production composition stays disabled.

## PR acceptance

- No process crash can convert an uncompleted job into successful coverage.
- Each attempt has one durable outcome and exact configuration identity.

Use the existing affected package tests plus the specific fixtures described below. Add meaningful regression/integration tests for behavior changes; documentation-only commits use link, schema or artifact checks. Full npm test/build/cf:dry-run run at the integration/release gate.

Run these commands from the isolated repository root after implementing the specified tests. They are planned verification commands, not checks executed by this planning task:

```bash
node --test tests/research-program/job-lifecycle.test.mjs
```

The implementation must demonstrate the behavior above using actual fixtures or retained execution evidence. A source capture is not a payload test; a passing schema is not scientific approval; a successful tool envelope is not a completed research task.

## Handoff and independent review

Write the sanitized evidence index under `verification/research-program/pr-010/` and the task-specific handoff under `docs/research-program/handoffs/PR-010.json`. Follow the [handoff template](../templates/handoff.json). Include exact base/head and dependency SHAs; commands with exit statuses; fixtures and expected/actual results; changed public behavior; source/generation identity; artifact hashes; failures; remaining questions; and the next consumer.

Push the task branch to GitHub and open/update a draft PR using the [PR body template](../templates/pr-body.md). Do not mark it ready until producer checks and handoff validation pass. Astra independently inspects the diff and replays the decisive acceptance checks; producer logs alone are not approval. Retain a failing result when blocked and identify the exact missing input. Do not auto-merge or deploy.
