# PR-082 — Build and qualify the exact release candidate

Phase **P8**, sub-phase **8C**. Status: planned.

The final release artifact is reproducible, independently gated and ready for a concrete decision.

**Dependencies:** PR-001, PR-002, PR-003, PR-004, PR-005, PR-006, PR-007, PR-008, PR-009, PR-010, PR-011, PR-012, PR-013, PR-014, PR-015, PR-016, PR-017, PR-018, PR-019, PR-020, PR-021, PR-022, PR-023, PR-024, PR-025, PR-026, PR-027, PR-028, PR-029, PR-030, PR-031, PR-032, PR-033, PR-034, PR-035, PR-036, PR-037, PR-038, PR-039, PR-040, PR-041, PR-042, PR-043, PR-044, PR-045, PR-046, PR-047, PR-048, PR-049, PR-050, PR-051, PR-052, PR-053, PR-054, PR-055, PR-056, PR-057, PR-058, PR-059, PR-060, PR-061, PR-062, PR-063, PR-064, PR-065, PR-066, PR-067, PR-068, PR-069, PR-070, PR-071, PR-072, PR-073, PR-074, PR-075, PR-076, PR-077, PR-078, PR-079, PR-080, PR-081, PR-085, PR-086

**Implementer:** Astra. **Reviewer:** Astra verifies the final candidate; a separate reviewer or owner reviews any substantive code Astra authored.

**Acceptance requirements:** R16. **Audit findings:** F01, F30, F32.

## Before editing

Read [EXECUTION.md](../EXECUTION.md), the dependency handoffs and the current repository instructions. Start from the merged integration SHA selected in PR-001, not the stale original workspace. Confirm the paths below in that release; create a new path only when it is named here. If an existing package supplies the required behavior, extend it instead of creating a parallel subsystem.

**Owned scope:**

- `verification/research-program/release/`
- `docs/research-program/release-runbook.md`

If a shared contract or another owner’s file must change, record the proposed interface change and resolve ownership before editing it. Keep each commit independently understandable and passing the checks appropriate to that change.

## Atomic commits

### C-082-1 — Capture the immutable candidate

Use the repository release-gate skill and dev-storage wrapper on the integrated head. Pin Node/lockfile/configuration and build once into retained artifacts.

**Verify:** Run required npm test, build, Cloudflare dry-run and declared release checks on the exact subject; skipped checks are not passes.

### C-082-2 — Verify staging with retained bytes

Deploy only to the authorized staged target and run data/API/browser/crawler/client acceptance against the retained artifact. Verify hashes and source generation.

**Verify:** A rebuild creates a new candidate; old approvals and receipts cannot be copied onto changed bytes.

### C-082-3 — Prepare the concrete release decision packet

Provide artifact identity, changes, remaining accepted limitations, costs, operational changes, smoke tests and exact rollback target. Resolve existing successor approvals for this subject.

**Verify:** The owner reviews a complete artifact/plan; no public traffic, paid resource or secret change occurs before its required authorization.

## PR acceptance

- The release evidence includes all R01–R16 statuses and independent reviewer identity.
- A release-gate failure is repaired and requalified, not waived by regenerating a receipt.

Use the existing affected package tests plus the specific fixtures described below. Add meaningful regression/integration tests for behavior changes; documentation-only commits use link, schema or artifact checks. Full npm test/build/cf:dry-run run at the integration/release gate.

The implementation must demonstrate the behavior above using actual fixtures or retained execution evidence. A source capture is not a payload test; a passing schema is not scientific approval; a successful tool envelope is not a completed research task.

## Handoff and independent review

Write the sanitized evidence index under `verification/research-program/pr-082/` and the task-specific handoff under `docs/research-program/handoffs/PR-082.json`. Follow the [handoff template](../templates/handoff.json). Include exact base/head and dependency SHAs; commands with exit statuses; fixtures and expected/actual results; changed public behavior; source/generation identity; artifact hashes; failures; remaining questions; and the next consumer.

Push the task branch to GitHub and open/update a draft PR using the [PR body template](../templates/pr-body.md). Do not mark it ready until producer checks and handoff validation pass. Astra independently inspects the diff and replays the decisive acceptance checks; producer logs alone are not approval. Retain a failing result when blocked and identify the exact missing input. Do not auto-merge or deploy.
