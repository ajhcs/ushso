from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,time
R=Path.cwd();S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
head=sys.argv[1];task=sys.argv[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
audit_path=S/('pr008-lock-review-'+head[:7]+'.json');audit=json.loads(audit_path.read_text())
assert audit['source_commit']==head and audit['source_tree']==git('rev-parse','HEAD^{tree}') and audit['status']=='PASS'
for p in audit['source_bindings']:
    b=(R/p['path']).read_bytes();assert len(b)==p['bytes'] and sha(b)==p['sha256']
out=S/('pr008-package-independent-review-'+head[:7]);assert not out.exists();out.mkdir()
node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node';npm=str(S/'tooling/node_modules/.bin/npm')
commands=[]
checks=[
    ('v1.2-test',[npm,'test','--prefix','contracts/machine-toolkit/v1.2.0']),
    ('v1.2-validate',[npm,'run','validate','--prefix','contracts/machine-toolkit/v1.2.0']),
    ('all-contract-versions',[npm,'run','test:contracts']),
    ('contract-inventory',[node,'--test','tests/contract-package-inventory.test.mjs']),
    ('controller-semantics',[node,str(S/'pr008-controller-cases.mjs'),str(R),str(out/'semantics.json')]),
    ('controller-parent-chain',[node,str(S/'pr008-controller-parent-chain-cases-v3.mjs'),str(R),str(out/'parent-chain.json')]),
]
for label,args in checks:
    start=time.monotonic();at=datetime.now(timezone.utc).isoformat()
    try:
        result=subprocess.run(args,capture_output=True,timeout=240)
        rc=result.returncode;stdout=result.stdout;stderr=result.stderr;timed_out=False
    except subprocess.TimeoutExpired as e:
        rc=None;stdout=e.stdout or b'';stderr=e.stderr or b'';timed_out=True
    streams={}
    for kind,b in [('stdout',stdout),('stderr',stderr)]:
        name=label+'.'+kind+'.log';(out/name).write_bytes(b);streams[kind]={'path':name,'bytes':len(b),'sha256':sha(b)}
    commands.append({'label':label,'argv':args,'cwd':str(R),'started_at':at,'duration_seconds':time.monotonic()-start,'exit_code':rc,'timed_out':timed_out,'streams':streams})
    print(json.dumps({'label':label,'exit_code':rc,'timed_out':timed_out}),flush=True)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
passed=all(c['exit_code']==0 and not c['timed_out'] for c in commands)
receipt={'format':'ushso.pr008-package-independent-execution.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'reviewer':'Astra/root','head':head,'tree':git('rev-parse','HEAD^{tree}'),'structural_review':{'path':str(audit_path),'sha256':sha(audit_path.read_bytes())},'commands':commands,'status':'PASS' if passed else 'FAIL','worktree_clean':True,'current_approval_issued':False,'historical_approval_transferred':False,'combined_acceptance':False,'release_qualified':False,'scope':'Independent package and unchanged variable semantics replay from the exact committed component. This may supply the reviewed current-lock input; it does not accept a final handoff or combined release.'}
p=out/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(p),'sha256':sha(p.read_bytes()),'status':receipt['status']}),flush=True)
raise SystemExit(0 if passed else 1)
