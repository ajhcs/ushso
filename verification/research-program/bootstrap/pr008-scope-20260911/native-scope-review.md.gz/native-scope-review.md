# PR-008 Native Scope and Compatibility Review

- Reviewer model: `gpt-5.6-luna/max`
- Review mode: read-only scope and compatibility review
- Reviewed input worktree: `/mnt/d/worktrees/plumbob/.ushso-research-program-20260910-worktrees/ushso-pr005-pr086-controller-combined-20260911`
- Input HEAD: `e6da2e2d87c95501e5a1b129989e17bdae3cb882`
- Input tree: `a9d9bca698ffc403a9ad1b82a8c8328af01146aa`
- Plan SHA: `380f3bed7fc5c9135d2000ba8f4a477e7348819f222298b441ff254ea99625f3`
- PR-007 dependency: `fa624903123dac858650730ee71bf7f8cb3c34ef`
- No network, private holdouts, servers, repository edits, commits, pushes, or deployment were used.

## Findings

- **P1 — Frozen machine contract conflict.** `contracts/machine-toolkit/v1.0.0/schemas/result-types.schema.json:228-257` and v1.1 `:850-968` define `variableField` and `variablesResult` with `additionalProperties:false`. The runtime repeats this at `packages/machine-toolkit/src/response-schema.mjs:530-561`; `get_variables` remains the frozen route at `contracts/machine-toolkit/v1.0.0/contracts/toolkit-manifest.json:139-159`. Adding PR-008 fields there breaks schema/runtime/parity tests. Add a separate strict versioned model, preferably `contracts/machine-toolkit/v1.2.0/schemas/variable-identity.schema.json`, with its own tests/receipt; leave v1.0/v1.1 bytes and routes unchanged.

- **P1 — Identity package seal is omitted from owned scope.** Editing `packages/identity/src/schema-catalog.mjs` changes the sealed tree. `packages/identity/src/artifact-seal.mjs:44-60` requires the manifest and receipt; current values are pinned in `packages/identity/manifests/package-manifest.json:7-18` and `packages/identity/validation/validation-receipt.json:6-22`. Add both paths to PR-008 ownership and run `npm test --prefix packages/identity` plus `npm run validate --prefix packages/identity`.

- **P1 — Catalog IDs are globally keyed.** `packages/identity/src/schema-catalog.mjs:7-39` stores fields by `schema_field_id`, so reusing an ID across release/distribution/snapshot contexts with changed content throws `immutable_record_conflict`. `resolveEndpoint` only checks release, distribution, snapshot, and field revision (`:51-60`), not source or object identity. Mint context-scoped variable/field IDs, or add a separate context validator; do not add `source_id` to frozen join endpoints, whose strict schema excludes it (`contracts/identity/v1.0.0/schemas/join-route.schema.json:64-77`).

- **P1 — Historical replay compatibility.** `scripts/research/source-extractors.mjs:111-140` replays `cdc_columns` and `census_variables` via deep equality. Keep those transformations and output shapes byte-compatible. Add a separately versioned variable-identity transformation/function. Direct shape changes require ownership of `scripts/research/prepare-catalog-update.mjs:35-46`, `scripts/research/dictionary-proposal-verification.mjs:33-45`, and `tests/update-cycle.test.mjs:8-60`.

- **P1 — Census concept is currently mislabeled.** `scripts/research/source-extractors.mjs:41-44` copies `v.concept` into `description`; downstream code then rewrites it into `publisher_concept` (`prepare-catalog-update.mjs:35-40`, `dictionary-proposal-verification.mjs:33-39`). The new model must use separate nullable `definition` and `publisher_concept` fields. Preserve the legacy projection for replay.

- **P2 — CMS scope mismatch.** PR-008 claims CMS adaptation, but the actual parsers are `scripts/research/cms-variable-layout.mjs:1-20` and `scripts/research/cms-typed-layout.mjs:1-20`, tested by `tests/cms-layout.test.mjs:4-30`; none are owned. Either add those exact paths to scope or limit PR-008 to an adapter and defer parser changes.

## Recommended versioned boundary

Use a dedicated strict variable identity schema with:

- resolved `context`: `source_id`, `asset_id`, `release_id`, `distribution_id`, `schema_snapshot_id`, `schema_field_id`, `field_revision_id`; unresolved context carries explicit nulls/reason and cannot mint a public schema-field ID;
- exact `wire_name`, `publisher_label`, nullable `definition`, separate nullable `publisher_concept`;
- literal `source_type` and evidence-backed `observed_type` state;
- unit union: `documented`, `not_applicable` with rationale for identifiers, `missing`/`unknown` for measurements without units;
- separate literal `code_values` and `missingness` encodings;
- mapping object with `exact`, `reviewed_alias`, `ambiguous`, or `unmatched` plus evidence and candidates;
- provenance containing URL, capture hash, exact pointer, raw-value hash, and transformation name/version.

## Decisive checks

Add `tests/research-program/variable-identity.test.mjs` coverage for:

- literal `"01"`, `"-1"`, `"N/A"`, Unicode and escaped pointers;
- Census concept-only versus definition text;
- identifier N/A units versus incomplete measurement units;
- all four mapping states;
- 117 HCRIS fields with the supplied 11 mismatches remaining unresolved;
- distinct IDs for identical wire names in different release/distribution/schema contexts;
- replay of legacy transformations.

## Read-only scope and compatibility conclusion

The minimal safe PR-008 implementation is an additive, versioned variable identity model and extractor path. Existing v1.0/v1.1 machine responses, frozen routes, identity contracts, source transformation IDs, historical proposals, cohorts, and source artifacts must remain unchanged. If implementation changes any omitted consumer or CMS parser listed above, ownership and handoff scope must be amended before editing.

