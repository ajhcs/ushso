from pathlib import Path
import hashlib, json, os, subprocess

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
preflight_path = S / 'corrected-components-preflight-980895d/receipt.json'
assert sha(preflight_path) == '53b133e611b1592f970aeb6b4ed9a724f2756a5e7da72797393ed8976b7af567'
cp = json.loads(preflight_path.read_text())
head = cp['head']
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', 'ushso-corrected-components-review-20260911', '--repo', str(R), '--require-writer'], check=True)
assert head == '980895daec306d15181de7291ed28a4330d57b6a'
assert git('rev-parse', 'HEAD') == head and git('rev-parse', 'HEAD^{tree}') == cp['tree'] and not git('status', '--porcelain')
assert cp['status'] == 'ready_for_exact_candidate_gate' and cp['accepted'] is False
assert all(c['exit_code'] == 0 for c in cp['commands']) and cp['artifact_bindings_checked'] == 373
plan_path = S / 'combined-980895d-gate-plan.json'
assert sha(plan_path) == '797f01bea2ccaa05df4ca19bc85f7f06296dbc89fe706a846f60793d9378999a'
plan = json.loads(plan_path.read_text())
assert plan['plan_fingerprint'] == 'd63b3c8f70adc0b6a849f21f947542e0be56442ab8a713822115b2de338f43ae'
assert len(plan['stages']) == 10 and sum(s['kind'] == 'build' for s in plan['stages']) == 1
assert all(s['selected'] and s['retries'] == 0 for s in plan['stages'])
assert sha(R / '.codex/release-gate.toml') == '068273993ddb6692eb5ac77a07d9ab7a10a5ee670efdf3b236ba1064de297478'
listeners = subprocess.run(['ss', '-H', '-tlnp', '( sport = :18787 )'], capture_output=True, text=True, check=True)
assert not listeners.stdout.strip(), 'Gate port 18787 is already in use'
env = dict(os.environ)
env['PATH'] = str(S / 'tooling/node_modules/.bin') + os.pathsep + env['PATH']
env['WRANGLER_LOG_PATH'] = str(S / 'gate-component-980895d-wrangler.log')
assert subprocess.check_output(['npm', '--version'], env=env, text=True).strip() == '11.19.1'
receipt = S / 'gate-component-980895d.json'
assert not receipt.exists()
with (S / 'gate-component-980895d-run.stdout').open('xb') as out, (S / 'gate-component-980895d-run.stderr').open('xb') as err:
    result = subprocess.run(['/home/plumbob/.local/bin/release-gate', 'run', '--repo', str(R), '--receipt', str(receipt)], env=env, stdout=out, stderr=err)
assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
print(json.dumps({'head': head, 'receipt': str(receipt), 'exit_code': result.returncode}), flush=True)
raise SystemExit(result.returncode)
