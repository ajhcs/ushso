from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
base = '980895daec306d15181de7291ed28a4330d57b6a'
task = 'ushso-pr006-pr008-combined-20260911'
directory = 'verification/research-program/bootstrap/gate-980895d-artifact-correction'
D = R / directory
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
now = lambda: datetime.now(timezone.utc).isoformat()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', task, '--repo', str(R), '--require-writer'], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain')
assert not D.exists()
D.mkdir(parents=True)
artifacts = []
def retain(name, raw, origin):
    p = D / name
    p.parent.mkdir(parents=True, exist_ok=True)
    encoded = gzip.compress(raw, mtime=0)
    p.write_bytes(encoded)
    artifacts.append({'path': p.relative_to(R).as_posix(), 'bytes': len(encoded), 'sha256': sha(encoded), 'decoded': {'bytes': len(raw), 'sha256': sha(raw), 'encoding': 'gzip'}, 'origin': origin})

gate_path = S / 'gate-component-980895d.json'
gate_raw = gate_path.read_bytes()
assert sha(gate_raw) == '6d2a572f0026b536117782dcb5e9f2c042812ea33c960391add37253c5813915'
gate = json.loads(gate_raw)
assert gate['candidate']['head_sha'] == base and gate['classification'] == 'product_test_failed'
retain('failed-gate.json.gz', gate_raw, 'actual first normal gate receipt on ' + base)
for stage in gate['stages']:
    for attempt in stage.get('attempts', []):
        if attempt.get('log_path'):
            p = Path(attempt['log_path'])
            retain('gate-logs/' + p.name + '.gz', p.read_bytes(), 'actual ' + stage['name'] + ' attempt ' + str(attempt['attempt']))
for name in ['combined-980895d-gate-plan.json', 'run-corrected-components-gate-980895d.py', 'preflight-corrected-components-980895d.py', 'controller-metadata-peer-review-980895d.json', 'correct-bootstrap-log-extension.py']:
    retain('controller/' + name + '.gz', (S / name).read_bytes(), 'controller procedure or prepared review; no peer review claimed')
for p in sorted((S / 'corrected-components-preflight-980895d').iterdir()):
    assert p.is_file()
    retain('passed-preflight/' + p.name + '.gz', p.read_bytes(), 'actual preflight on ' + base)
for name in ['scan.json', 'gitleaks.json', 'gitleaks-history.json', 'finding-disposition.json']:
    retain('publication-scan/' + name + '.gz', (S / 'publication-review-corrected-combined-980895d' / name).read_bytes(), 'local publication scan; original findings retained; no publication')

original_path = 'verification/research-program/bootstrap/pr008-review-e433eff/pr008-controller-worktree-create.json'
new_path = original_path.removesuffix('.json') + '.log'
raw = (R / original_path).read_bytes()
assert len(raw) == 630 and sha(raw) == '904ff9fe234da12a504e562238cabc247089f7851e4f2a52034830b3cdf52ee9'
index_path = R / 'verification/research-program/bootstrap/pr008-review-e433eff/index.json'
old_index = index_path.read_bytes()
retain('prior-e433eff-index.json.gz', old_index, base + ':' + index_path.relative_to(R).as_posix())
assert not (R / new_path).exists()
(R / original_path).rename(R / new_path)
index = json.loads(old_index)
matches = [a for a in index['artifacts'] if a['path'] == original_path]
assert len(matches) == 1 and matches[0]['sha256'] == sha(raw)
matches[0]['path'] = new_path
index_path.write_text(json.dumps(index, indent=2) + '\n')
correction = {'format': 'ushso.bootstrap-evidence-extension-correction.v1', 'recorded_at': now(), 'author': 'Astra/root', 'candidate_before': base, 'failed_gate_sha256': sha(gate_raw), 'failure': 'The immutable external-authorization test enumerates verification/**/*.json and rejected the unframed npm/bootstrap stdout saved with a JSON extension.', 'old_path': original_path, 'new_path': new_path, 'bytes': len(raw), 'sha256': sha(raw), 'source_bytes_preserved': True, 'old_index_archive': directory + '/prior-e433eff-index.json.gz', 'current_index_change': 'Only the command-log artifact path changed from .json to .log; its bytes/hash and every other artifact/disposition are unchanged.', 'released_test_or_policy_changed': False, 'product_bytes_changed': False, 'separate_metadata_peer_review': 'pending', 'accepted': False}
(D / 'correction.json').write_text(json.dumps(correction, indent=2) + '\n')
correction_raw = (D / 'correction.json').read_bytes()
retained_index = {'format': 'ushso.independent-review-portable-index.v1', 'recorded_at': now(), 'artifacts': artifacts, 'metadata_files': [{'path': directory + '/correction.json', 'bytes': len(correction_raw), 'sha256': sha(correction_raw)}], 'accepted': False, 'peer_metadata_review_pending': True}
(D / 'index.json').write_text(json.dumps(retained_index, indent=2) + '\n')
for p in (R / 'verification').rglob('*.json'):
    if 'node_modules' not in p.parts:
        json.loads(p.read_bytes())
subprocess.run(['git', 'diff', '--check'], check=True)
subprocess.run(['git', 'add', '--', original_path, new_path, str(index_path.relative_to(R)), directory], check=True)
subprocess.run(['git', 'commit', '-m', 'Retain bootstrap stdout as a log and preserve failed gate'], check=True)
assert not git('status', '--porcelain')
cp_path = S / 'corrected-components-final-candidate.json'
old_cp = cp_path.read_bytes()
assert json.loads(old_cp)['head'] == base
archive = S / 'corrected-components-final-candidate-980895d.json'
assert not archive.exists()
archive.write_bytes(old_cp)
cp = json.loads(old_cp)
cp.update({'recorded_at': now(), 'base': base, 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'prior_failed_gate': directory + '/failed-gate.json.gz', 'artifact_extension_correction': directory + '/correction.json', 'preflight_pending': True, 'gate_pending': True})
index_raw = (D / 'index.json').read_bytes()
cp['additional_indices'].append({'path': directory + '/index.json', 'bytes': len(index_raw), 'sha256': sha(index_raw)})
cp_path.write_text(json.dumps(cp, indent=2) + '\n')
print(json.dumps({'head': cp['head'], 'tree': cp['tree'], 'index': cp['additional_indices'][-1], 'metadata_review_pending': True, 'accepted': False}), flush=True)
