from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, time

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
D = S / 'corrected-components-preflight-980895d'
task = 'ushso-corrected-components-review-20260911'
base = 'fdeed22bc052dbc88544001a2270fe79df32ddc9'
head = '980895daec306d15181de7291ed28a4330d57b6a'
tree = 'ae4d6c77f3774702e6439d7e556b1182da5f9b19'
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
sha = lambda b: hashlib.sha256(b).hexdigest()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', task, '--repo', str(R), '--require-writer'], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD') == base and not git('status', '--porcelain')
changed = git('diff', '--name-only', base, head).splitlines()
delta_dir = 'verification/research-program/bootstrap/pr008-source-capture-correction-20260911/'
assert len(changed) == 39
assert all(p in ['docs/research-program/handoffs/PR-008.json', 'docs/research-program/execution-ledger.json'] or p.startswith(delta_dir) for p in changed), changed
subprocess.run(['git', 'merge', '--ff-only', head], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD^{tree}') == tree and not git('status', '--porcelain')
assert not D.exists()
D.mkdir()
cp = json.loads((S / 'corrected-components-final-candidate.json').read_text())
assert cp['head'] == head and cp['tree'] == tree
prior_path = S / 'corrected-components-preflight-fdeed22/receipt.json'
prior_raw = prior_path.read_bytes()
assert sha(prior_raw) == '6f4b18cca6bede24329998b42160f510158f3d89b86cd3a644666edcf69b4aee'
prior = json.loads(prior_raw)
assert prior['head'] == base and prior['status'] == 'changes_requested'
assert [c['label'] for c in prior['commands'] if c['exit_code'] != 0] == ['pr-008-handoff']
for c in prior['commands']:
    for a in c['streams'].values():
        b = (prior_path.parent / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256']
artifacts = 0
for pr, producer in cp['producer_heads'].items():
    subprocess.run(['git', 'merge-base', '--is-ancestor', producer, head], check=True)
    h = json.loads((R / 'docs/research-program/handoffs' / (pr + '.json')).read_text())
    for a in h['artifacts']:
        b = (R / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256'], a['path']
        artifacts += 1
for index in [cp['index'], *cp['additional_indices']]:
    b = (R / index['path']).read_bytes()
    assert len(b) == index['bytes'] and sha(b) == index['sha256']
    idx = json.loads(b)
    for a in idx['artifacts']:
        b = (R / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256']
        raw = gzip.decompress(b)
        assert len(raw) == a['decoded']['bytes'] and sha(raw) == a['decoded']['sha256']
        artifacts += 1
    for a in idx['metadata_files']:
        b = (R / a['path']).read_bytes()
        assert len(b) == a['bytes'] and sha(b) == a['sha256']
        artifacts += 1
for p, expected in prior['frozen_sha256'].items():
    assert sha((R / p).read_bytes()) == expected, p
hp = 'docs/research-program/handoffs/PR-008.json'
old = json.loads(subprocess.check_output(['git', 'show', base + ':' + hp]))
new = json.loads((R / hp).read_text())
original_assignment = 'docs/master-plan/2026-09-10/prs/PR-008.md'
for name, commit in [('original-assignment.md', old['base_sha']), ('amended-assignment.md', base)]:
    assert (R / delta_dir / name).read_bytes() == subprocess.check_output(['git', 'show', commit + ':' + original_assignment])
assert new['artifacts'][:-2] == old['artifacts'] and new['unresolved_claims'][:-1] == old['unresolved_claims']
original_sources = new['source_identities'][:-1]
relocated = next(s for s in original_sources if s['id'] == delta_dir + 'original-assignment.md')
relocated['id'] = original_assignment
del relocated['version']
assert original_sources == old['source_identities']
for key in set(old) - {'artifacts', 'unresolved_claims', 'source_identities'}:
    assert new[key] == old[key], key
node = '/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
checks = [(pr.lower() + '-handoff', [node, 'scripts/research-program/check-handoff.mjs', 'docs/research-program/handoffs/' + pr + '.json']) for pr in ['PR-006', 'PR-008', 'PR-086']]
checks.append(('plan-validation', ['python3', 'docs/master-plan/2026-09-10/validate.py']))
commands = []
for label, args in checks:
    started = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    result = subprocess.run(args, capture_output=True, timeout=120)
    streams = {}
    for name, b in [('stdout', result.stdout), ('stderr', result.stderr)]:
        filename = label + '.' + name + '.log'
        (D / filename).write_bytes(b)
        streams[name] = {'path': filename, 'bytes': len(b), 'sha256': sha(b)}
    commands.append({'label': label, 'argv': args, 'started_at': started, 'duration_seconds': time.monotonic() - timer, 'exit_code': result.returncode, 'streams': streams})
    print(json.dumps({'label': label, 'exit_code': result.returncode}), flush=True)
assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
ok = all(c['exit_code'] == 0 for c in commands)
receipt = {'format': 'ushso.corrected-components-preflight.v2', 'recorded_at': datetime.now(timezone.utc).isoformat(), 'head': head, 'tree': tree, 'repo': str(R), 'task': task, 'commands': commands, 'artifact_bindings_checked': artifacts, 'frozen_sha256': prior['frozen_sha256'], 'fresh_managed_locked_install': True, 'behavior_evidence': {'head': base, 'receipt': str(prior_path), 'sha256': sha(prior_raw), 'passing_command_labels': [c['label'] for c in prior['commands'] if c['exit_code'] == 0], 'carry_basis': 'Exact complete Git changed-path proof: all 39 files since the prior preflight are PR008 handoff, execution ledger, or newly retained bootstrap evidence. Product, tests, dependencies, gate policy and runtime inputs are unchanged.', 'prior_failed_command': 'pr-008-handoff', 'prior_failure_preserved': cp['prior_preflight']}, 'metadata_correction_checks': ['exact original and amended assignment Git bytes', 'only intended PR008 source locator and additive artifacts/unresolved claim changed', 'complete producer and controller evidence bindings', 'default live handoff checks on exact corrected tree'], 'status': 'ready_for_exact_candidate_gate' if ok else 'changes_requested', 'peer_metadata_review_pending': True, 'gate_pending': True, 'hosted_ci_pending': True, 'accepted': False, 'requirements_accepted': []}
p = D / 'receipt.json'
p.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'path': str(p), 'sha256': sha(p.read_bytes()), 'status': receipt['status'], 'artifact_bindings_checked': artifacts}), flush=True)
raise SystemExit(0 if ok else 1)
