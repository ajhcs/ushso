from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

R = Path.cwd()
S = Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
task = 'ushso-pr006-pr008-combined-20260911'
base = '980895daec306d15181de7291ed28a4330d57b6a'
directory = 'verification/research-program/bootstrap/gate-980895d-artifact-correction'
D = R / directory
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], text=True).strip()
now = lambda: datetime.now(timezone.utc).isoformat()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap', 'verify', task, '--repo', str(R), '--require-writer'], check=True, stdout=subprocess.DEVNULL)
assert git('rev-parse', 'HEAD') == base
correction = json.loads((D / 'correction.json').read_text())
old, new = correction['old_path'], correction['new_path']
assert not (R / old).exists()
assert (R / new).read_bytes() == subprocess.check_output(['git', 'show', base + ':' + old])
allowed = {old, new, 'verification/research-program/bootstrap/pr008-review-e433eff/index.json'}
assert all(p in allowed or p.startswith(directory + '/') for p in git('diff', '--name-only', 'HEAD').splitlines())
index_path = D / 'index.json'
index = json.loads(index_path.read_text())
for name, raw in [('finish-bootstrap-log-correction.py.gz', (S / 'finish-bootstrap-log-correction.py').read_bytes()), ('gitignore-interruption.json.gz', (json.dumps({'format': 'ushso.controller-command-interruption.v1', 'recorded_at': now(), 'command': 'git add -- [exact correction paths]', 'exit_code': 1, 'observation': 'The intended retained .log artifact matched the existing .gitignore; staging stopped before any commit. The original text bytes and the other staged correction files remained available.', 'resolution': 'Explicitly force-add only this intended evidence log, then finish the same correction commit.', 'scope': 'Git staging only; not a product failure or a release-gate rerun.'}, indent=2) + '\n').encode())]:
    p = D / 'controller' / name
    assert not p.exists()
    encoded = gzip.compress(raw, mtime=0)
    p.write_bytes(encoded)
    index['artifacts'].append({'path': p.relative_to(R).as_posix(), 'bytes': len(encoded), 'sha256': sha(encoded), 'decoded': {'bytes': len(raw), 'sha256': sha(raw), 'encoding': 'gzip'}, 'origin': 'controller Git staging interruption and exact continuation'})
index_path.write_text(json.dumps(index, indent=2) + '\n')
subprocess.run(['git', 'add', '--', directory], check=True)
subprocess.run(['git', 'add', '-f', '--', new], check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
assert all(p in allowed or p.startswith(directory + '/') for p in git('diff', '--cached', '--name-only').splitlines())
subprocess.run(['git', 'commit', '-m', 'Retain bootstrap stdout as a log and preserve failed gate'], check=True)
assert not git('status', '--porcelain')
cp_path = S / 'corrected-components-final-candidate.json'
old_cp = cp_path.read_bytes()
assert json.loads(old_cp)['head'] == base
archive = S / 'corrected-components-final-candidate-980895d.json'
assert not archive.exists()
archive.write_bytes(old_cp)
cp = json.loads(old_cp)
cp.update({'recorded_at': now(), 'base': base, 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'prior_failed_gate': directory + '/failed-gate.json.gz', 'artifact_extension_correction': directory + '/correction.json', 'preflight_pending': True, 'gate_pending': True})
index_raw = index_path.read_bytes()
cp['additional_indices'].append({'path': directory + '/index.json', 'bytes': len(index_raw), 'sha256': sha(index_raw)})
cp_path.write_text(json.dumps(cp, indent=2) + '\n')
print(json.dumps({'head': cp['head'], 'tree': cp['tree'], 'index': cp['additional_indices'][-1], 'metadata_review_pending': True, 'accepted': False}), flush=True)
