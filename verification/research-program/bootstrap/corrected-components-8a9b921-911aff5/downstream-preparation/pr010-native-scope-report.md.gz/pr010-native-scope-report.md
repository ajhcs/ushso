# PR-010 provisional native scope report

Review date: 2026-09-11 (UTC)

Review interface: native Codex collaboration selection `gpt-5.6-luna/max`. This records the selected interface for this review; it is not a serving-model attestation.

Disposition: **provisional scope is coherent, but implementation dispatch must remain held until PR-009 is accepted and two bounded interface questions are resolved.** No repository file was changed. The only output of this review is this scratch report.

## Input identity and review boundary

The reviewed repository is `/mnt/d/worktrees/plumbob/ushso-research-program-20260910`, branch `codex/research-program-integration-20260910`, at commit `9e00d4e09514e1dd30672e19a3cbef4171955b00`, tree `9c6aef6daa3e6dbd5b03217cf466d30364295ee7`. `git status --short --branch` reported a clean worktree tracking its remote branch.

I read `AGENTS.md`, `README.md`, `docs/ARCHITECTURE.md`, `docs/EVALUATION.md`, `docs/master-plan/2026-09-10/EXECUTION.md`, the PR-009/010/011 packets, the plan graph, the ingestion and service interfaces, relevant SQL migrations, strict ingestion schemas, current tests, WP4/WP5 verification boundaries, and `scripts/run-contract-suites.mjs`. The review was read-only: no test, server, database, Queue, Workflow, source request, credential, deployment, private holdout, or plan/repository mutation was performed.

The current base contains neither an accepted PR-009 implementation nor its required handoff: these paths are absent at this input:

```text
scripts/research-program/policy.json
scripts/research-program/operating-bounds.mjs
scripts/research-program/receipts/v1.0.0/evidence-receipt.schema.json
docs/research-program/handoffs/PR-009.json
verification/research-program/pr-009/
```

The retained PR-009 bootstrap decision is explicitly `implementation_dispatched: false`, with unmet PR-008 acceptance. Its decision SHA-256 is `7c5f3e32f53eb775f1ecce815d42b98fce69c2dd338b87860349ee7a6db67f76`; the independent scope review SHA-256 is `e10ec326fe9321ac48d3acb98b329571d129ce83ebe41da13c3b8db0de3330bd`. Those are scope evidence, not a PR-009 handoff or acceptance.

## Recommended bounded ownership

The packet’s four owned entries are directory-level entries plus one explicitly named test. The packet also says to create a new path only when it is named. The smallest implementation placement is therefore:

| Commit | Exact existing paths to extend | Responsibility and boundary |
| --- | --- | --- |
| C-010-1 | `packages/ingestion/src/scheduler.mjs`; `packages/ingestion/src/in-memory-control-plane.mjs`; `packages/ingestion/src/postgres-control-store.mjs`; `packages/ingestion/src/ports.mjs` only if the new store methods are made required | Define a collection-job identity and durably ensure it through the existing run/outbox/lease machinery. Keep schedule admission separate from collector execution. Store the additional spec internally in the existing job `identity_payload`; do not change released JSON contracts or SQL migrations. |
| C-010-2 | `packages/ingestion/src/harvest-workflow.mjs`; `services/harvest-worker/index.mjs` | Bridge the existing bounded collector through injected ports and the existing fresh-database/Queue seams. Keep network or other external work outside database transactions and commit capture/checkpoint state through a fenced, idempotent operation. Keep the checked-in `worker.mjs` defaults disabled. |
| C-010-3 | `tests/research-program/job-lifecycle.test.mjs` plus one newly named CLI path | Expose fixture-only dry-run/local execution and test selected/running/partial/complete status and resumable checkpoint locations. The packet does not currently name a CLI file, so the controller must name one before a new file is created. A narrow proposed name is `packages/ingestion/src/local-job-cli.mjs`, with the existing `packages/ingestion/package.json` script updated only to invoke that file. |

No change is needed in `services/scheduler-worker/index.mjs` if C-010-1 extends the existing scheduler/store transaction. Its current scheduled phases already isolate schedule, Workflow reconciliation, DLQ recovery, retention and outbox dispatch. `packages/ingestion/src/index.mjs` needs no change when existing modules are extended; it may be updated only if the controller explicitly chooses to export a named new CLI/adapter module.

The current packet does not name a new collector-adapter module. Extending `harvest-workflow.mjs` and the harvest service is the preferred bounded placement. If implementation review shows that a separate adapter file is necessary, the task binding must name that one file before editing. Do not create a second collection subsystem or widen ownership to `scripts/research/`, `packages/connectors/`, `db/migrations/`, `contracts/`, or the frozen verification packages.

## C-010-1 contract decision

The current database and queue contracts already provide a narrow internal representation:

* `ingest.jobs` already has `source_id`, a unique `(job_type, idempotency_key)`, leases/fences, attempt counters, outbox identity, and an arbitrary object-valued `identity_payload`.
* The database restricts `job_type` to `harvest_page`, `normalize_record`, `enrich_schema`, `access_check`, and `project_index`. The existing target classes include `collection`. The queue envelope also has a closed reference allowlist.
* The frozen `contracts/ingestion/v1.0.0/schemas/ingest-job.schema.json` has `additionalProperties: false` at the top level and under `identity`. It has no fields for a collection configuration hash, selected records, capture class, or budget reservation. It must not be edited for PR-010.

Use an internal collection specification carried by the existing job row, preferably as a bounded object in `identity_payload`, while retaining the physical `harvest_page` stage and `target_class: collection`. This avoids a new SQL enum, queue event type, public contract version, migration, or contract-suite route. The logical idempotency key must be calculated from canonical source ID, the exact configuration hash, normalized selected opaque record IDs, the PR-009 capture class, and the bounded reservation identity (and the scheduled job slot where the slot distinguishes jobs). Repeat delivery for the same canonical identity converges on one row/outbox event; a changed exact configuration hash produces a different logical job. Selection order must not change identity. No source body, query, credential, or private payload belongs in the job spec or queue references.

The new spec must consume PR-009’s settled capture-class vocabulary and budget fields. Existing `ingest.capture_references.classification` permits `catalog_metadata`, `documentation`, `schema_description`, and `access_observation_metadata`; PR-010 should not invent a second class vocabulary. A reservation is a bounded policy snapshot/identity in this change. Actual quota enforcement and broader retry scheduling remain downstream work (PR-012); no paid resource or production activation follows from the reservation.

There is one material contract blocker: the current scheduler cannot obtain the exact descriptor configuration hash. `packages/ingestion/src/scheduler.mjs` receives only `configuration_revision` from `leaseDueSources`. The SQL function `registry.lease_due_source_schedules` returns that integer and does not return `descriptor_sha256`. The scheduler role is granted SELECT on sources, endpoints, scopes and schedules, but not `registry.source_revisions`; that table is where the exact descriptor hash is stored. `ensureRunAndWorkflowOutbox` also resolves a plan by integer revision and does not add a descriptor hash.

Do not call a hash of `(source_id, endpoint_id, scope_ids, mode, revision)` the exact source configuration hash. Before C-010-1 implementation, the accepted PR-009 handoff must state the authoritative hash input and how the scheduled job receives it. If that requires changing the lease SQL function, a database grant/migration, or a new registry-to-scheduler port, that is an interface/ownership amendment outside this PR-010 packet. A controller may instead explicitly approve a differently named deterministic control-configuration identity, but that would not satisfy the packet’s phrase “exact configuration hash” unless the semantics are recorded.

## C-010-2 reusable behavior and adapter boundary

`packages/connectors/src/runner.mjs` is the strongest existing bounded collector seam and must remain read-only for PR-010. `DeterministicConnectorRunner` requires injected `httpClient` and durable `runRepository` ports, derives deterministic page keys/job IDs, skips committed pages, commits page captures, seals enumeration, and commits membership/checkpoint/downstream effects only after a complete seal. Its crash points cover before fetch, after fetch before page commit, after page commit before resume, after seal before checkpoint, and after the final checkpoint transaction. Its fixture harness supplies `FixtureTransport`, `MemoryRunRepository`, capture-reference/object stores and an origin governor.

The ingestion package already supplies the required database discipline: `createHarvestWorkflow` wraps each durable step in `step.do` plus `withFreshDatabaseClient`, and `createQueueConsumer` performs external processing outside the effect transaction before a fresh fenced commit. C-010-2 should bridge the runner to those seams, keep the collector’s injected HTTP/storage/clock ports explicit, and record `partial_unpublished` or a typed attempt outcome when a capture succeeds but the durable page/checkpoint commit is interrupted. Resume must use the persisted page identity/capture reference so the runner’s request key is replayed without a second source request.

The current ingestion port list does not expose runner methods such as `beginRun`, `commitPage`, `getResume`, `sealEnumeration`, or `commitMembershipAndCheckpoint`. The existing SQL has capture references, discoveries, run cursors, enumeration seals and checkpoints, but no separate committed-page table. Therefore the adapter must either persist the bounded page identity/resume reference through existing job/capture/cursor structures or receive a separately authorized storage interface. Adding a page table or migration is outside the packet. If new methods are added to `PORT_METHODS.controlStore`, update both the in-memory and PostgreSQL implementations and their existing package tests in the same C-010-2 boundary.

The older `scripts/research/update-cycle.mjs` (`runBoundedUpdate`), `refresh.mjs`, and `collect-*` scripts remain reusable research entry points but are outside PR-010 ownership and several perform direct filesystem work or default `fetch`. They may be supplied as fixture functions through an adapter, but their local checkpoint files cannot silently become the durable ingestion authority. The durable resume proof should use the injected runner/memory ports or an explicit wrapper with one authority for page identity and capture references. Nothing in this work changes the public Worker’s no-source-egress boundary.

## C-010-3 CLI and tests

The ingestion package has no `bin` entry or local job CLI. Its current scripts are only `test` and `verify`. The root already registers `tests/research-program/*.test.mjs` through `test:research-program` and includes that command in `npm test`; no root package-script edit or `run-contract-suites` alias is needed for the named test.

The proposed CLI path should be explicitly named in the dispatch binding (for example, `packages/ingestion/src/local-job-cli.mjs`). It should only compose injected fixture ports by default and report selected job IDs, exact config identity, selected-ID count/list subject to bounds, capture class, estimated limits, terminal status, and checkpoint location. It must never resolve a production binding, secret, network client, database, Queue, Workflow, or source URL by default. The fixture scenario should observe `selected -> running -> partial` after an injected interruption and then `complete` after resume; a crash or incomplete seal must never report success.

The required `tests/research-program/job-lifecycle.test.mjs` should cover at least:

1. duplicate schedule delivery for the same slot/config/selection creates one logical job and one outbox effect;
2. a changed exact configuration hash creates a distinct job identity;
3. selected opaque IDs are sorted/deduplicated for identity, while capture class and policy reservation remain bound to the job;
4. an injected interruption after a successful capture, before page commit, records a non-success durable outcome and resumes from the capture reference without a second source request;
5. a crash after page commit or after the final transaction is idempotent and cannot duplicate discovery/capture/checkpoint effects;
6. each attempt has one durable outcome, an uncompleted run is `partial_unpublished`/typed failure, and only a complete sealed run can succeed;
7. dry-run output shows selected jobs and limits, local fixture execution exposes all four statuses and a checkpoint location, and the default production composition remains disabled; and
8. strict `ingestion.v1.0.0` job/envelope records and their allowlisted references remain unchanged even when the internal collection spec contains the additional fields.

Use the fixture transport and memory ports for source-side behavior. A PostgreSQL network connection is not required for this offline test; existing package tests can cover SQL/query shape and both control-store implementations as appropriate.

## Required PR-009 handoff inputs

PR-010 should not consume the retained PR-009 bootstrap proposal as if it were a completed dependency. The accepted handoff must bind:

* exact PR-009 base/head/merge/dependency SHAs and the current task binding;
* `policy.json` version and SHA-256, the operating-bounds module version/API and SHA-256, and the strict receipt schema/README version and SHA-256;
* exact descriptor/source/endpoint/route identity rules, capture-class vocabulary, byte/row/timeout/redirect/retry bounds, retention semantics, and reservation meaning;
* the retained Census negative fixture with its exact manifest (`d4ea9e39f177bade0f19dcb9c9d88d8070ee71f5c9e54db115bdf47ff912bb0a`, 1901 bytes), compressed body (`df6a615ab36472bb4e7bbf47e77f9603192f236c05a7266f3726549c9b9d09d3`, 2351 bytes), receipt (`59db025a433a8af7508d7e70786c611b033d8d82da71e29c8d9d7368bc7f138c`, 585 bytes), and decoded body SHA-256/size (`c2f4687e09b80676de7f68dec92ebea395209616dbc6f895520e547c5f68c0f5`, 8531 bytes);
* explicit `activation: false`, no persistence/DB/Queue/Workflow side effects, no live source traffic, and no payload-rights inference; and
* a clear downstream boundary: PR-009 defines pure policy/receipt composition, PR-010 owns durable job/attempt/checkpoint wiring, and PR-011 owns the first connector content/access implementation and its verification successor.

Most importantly, the handoff must either carry the exact descriptor hash required by C-010-1 or identify the authorized interface that supplies it. It must not leave PR-010 to infer that value from an integer revision.

## Historical seals and PR-011/WP5 boundary

PR-010’s owned ingestion/service changes are inside the current WP4 implementation inventory but outside WP5’s connector inventory. WP4 v1.0.0 deliberately computes a moving source-bound fingerprint while the implementation is changing; at this base the 43-file implementation fingerprint is `8d065af84d1b99fc5c56ef4d432bbe3adfe5fa277533e2ec6478cfedce47e93c`. Its receipt README says a digest-bound receipt is only added after implementation/migration bytes freeze. PR-010 must leave the WP4 v1.0.0 package and historical artifacts intact, then generate fresh current WP4 evidence after its changes. No WP4 version successor is required merely because this moving inventory changes.

WP5 v1.0.0 is different: its fixed connector fingerprint is `df5fb94f4f3f3468ca2631a63768a4bf7711696657c88c4b7df57830e7031b99`, and its receipts require that exact digest. PR-010 must not touch `packages/connectors/` or `verification/wp5/v1.0.0/`, so it creates no WP5 successor. PR-011’s owned `packages/connectors/src/` changes are the first expected WP5 successor boundary. Before that first connector byte changes, assign an additive `verification/wp5/v1.1.0/` (or explicitly selected next immutable version) with its own tests, validator, fingerprint, ledger and activation state; preserve all v1.0.0 bytes and receipts.

`run-contract-suites.mjs` registers `wp4` and `wp5` as versioned verification suites, while the new PR-010 research-program test is reached through the root `test:research-program` glob. The contract runner does not discover arbitrary `tests/research-program` files and should not be widened casually for this PR.

PR-011 should receive from PR-010 the durable job identity/config-hash semantics, collector adapter port shape, capture-reference/checkpoint commit boundary, attempt outcome/partial status vocabulary, and fixture replay evidence. It should not receive a new public API field or an instruction to alter the frozen ingestion v1.0.0 schemas.

## Three-commit conclusion and unresolved questions

The three-commit shape remains bounded if C-010-1 uses existing job identity storage, C-010-2 uses existing workflow/Queue/fresh-database seams, and C-010-3 names one CLI path plus the already named test. The following are the only pre-edit blockers identified:

1. **Exact hash source:** where the scheduler obtains the authoritative descriptor/configuration SHA-256, given the current SQL return shape and scheduler role grants. A migration, grant, SQL-function change, or revision-derived substitute requires a controller decision and possibly a separate owner.
2. **New path names:** the packet names only directories for implementation and does not name a CLI or separate adapter file. The controller must either authorize extension of the existing files listed above or add exact new paths before their creation.

If either blocker expands into a released contract change, database migration, connector edit, or public activation, stop and split/renegotiate ownership. Otherwise C-010-1/2/3 remain a narrow implementation and test sequence after the accepted PR-009 handoff.

## File hashes at the reviewed input

These hashes are raw bytes from the immutable worktree at the input commit.

```text
AGENTS.md                                                         4c1789435fe34aac1d75ecfd6e9350412e5672b6b4b24867f78119d7e19f89e6
README.md                                                         e46f4c12a25ae9ed628002e6b0380feebdd4f9b60a23cefca41b66f3eaed8d6d
docs/ARCHITECTURE.md                                             f70fe0b4c35dfc5f4d64790f5eb0b4941a88c869586c4ddec63c86ebc87e0f70
docs/EVALUATION.md                                               4fe2c290c2adaea7a2b859e34c65997a478824a0a1722480f2873798c131d389
docs/master-plan/2026-09-10/plan.json                            423005db30d345dad038698def8e879c31e2c4dadf62b6ce650ec16b3917d6d0
docs/master-plan/2026-09-10/EXECUTION.md                         4118d4f46a7ebec45749676881c753529593842792a439cfb5e53e50bc1fdfc3
docs/master-plan/2026-09-10/prs/PR-009.md                         e9e0a0bdaca44fb2c67db75213ddd9c557e65a585bb14dfc7caf716954cba04d
docs/master-plan/2026-09-10/prs/PR-010.md                         25b007e781058b3fad2e4acb9af29a6ab99c3c48af5812bbb19529b313bee097
docs/master-plan/2026-09-10/prs/PR-011.md                         d7a68918daacbe5063d6b1c3c158792cbe2b715dbcf17c7029a8e32b8ffa482c
packages/ingestion/src/scheduler.mjs                             62155eefa91e4678477839c309b084afb9557f273bfe5281236fbc0b9c44dbeb
packages/ingestion/src/harvest-workflow.mjs                       db4431256cbf4139bfec7dc3e91742ecb72e198dee294d8f6f3ae08dbb98d266
packages/ingestion/src/ports.mjs                                  3f832c244528602ac5dbfa7769b5906ff72610859ecd2ab5ca440c5b9739394c
packages/ingestion/src/in-memory-control-plane.mjs                 bbdb163c998411b4c518d69e086a091925f2836ff32446cd0a06751b9a20d9dd
packages/ingestion/src/postgres-control-store.mjs                 00cd03bf6e1b81ceb1eb15073370fa6c7cff022cca2bbfc306483a7b8c5918c1
packages/ingestion/src/queue-consumer.mjs                          edeb6e052bf5dd0de181c24e108a96272f6ca7cf5da3dda05ec5c83ab9b2711d
packages/ingestion/package.json                                   52f6f2d8cd754575b098933b98bc253adfb8602bfe2cb61997d70db620802501
packages/connectors/src/runner.mjs                                50af43de5732a562fc506cae854c634998ca43b6d283b270d542d7891c171bf6
packages/connectors/src/testing/fixtures.mjs                       a97fb601b72c507ba33309e3cca45e18e595b814566e855814214ab76ce62668
packages/connectors/src/testing/memory-ports.mjs                   33843172e8f9e0d2fb5258b2d5a13167b3794ee73c713f721cf4d00928f7ad93
services/scheduler-worker/index.mjs                               ae445ee6be8366c13d701394968739c4c1ab4b267ee9eb6fd488b61da7a2586b
services/harvest-worker/index.mjs                                 38222bcd96419731f94ab7b48200c003c41fb0a49cced965cfaedf070e8435cf
contracts/ingestion/v1.0.0/schemas/ingest-job.schema.json          e7db23b96b4d7d393ae59a95d878a74c46ae718e127ddb12e1e1a2617935fb02
db/migrations/0001_registry_sources_endpoints_scopes.sql           7cd5d8cf2fbdb5a87d9344ad5218329c3d793b093ba674ffd00c4660c491a1f6
db/migrations/0002_ingest_runs_jobs_captures.sql                   d503c3c2283d4c1edc34ae8688a8586197ca55af950575fdc0f49c6b83c26c97
db/migrations/0003_ops_outbox_processed_events_dead_letters.sql    89e5957af56d41ea2e75be3531e1151cd530c2fc4476e9801556be30b0f8d922
scripts/run-contract-suites.mjs                                  3a13c51986e1cd90b530465d4e8fc30cc3763a86189d06930c4dbf6f65c5e261
verification/wp4/v1.0.0/tools/common.mjs                         acfb067c85f9a5a9251aaf79e7a202f5fba9d0955ec345e7604077de97161c03
verification/wp5/v1.0.0/tools/common.mjs                         3a8c6c619271600daf16d98377c7ca0ab1c39728c7bd3aa31d48d7ba1b916e39
verification/wp5/v1.0.0/evidence-ledger.json                      74fd2fd92ddcbd85841e7b81c4ad6ae08c420bdfd9d37feda93059dba0bab2e5
verification/wp5/v1.0.0/receipts/activation-status.json            439b258fc261f8e537ccaf72a8c07efe08c03d239a73e07591b0fb41e813c9cc
verification/wp5/v1.0.0/receipts/delivery-wave-fixtures.json       8d68a1b1ddf138e7e44d7c0b24bf9c51fbce6a6f6bab3d60e6e10a6e8479cd35
```

## Executed read-only command stream

The following decisive commands were run from the reviewed worktree; all exited 0 except the intentional existence probe for the absent PR-009 handoff, which exited 1. Commands were limited to local reads, hashes, and deterministic fingerprint calculation.

```text
git rev-parse HEAD
git rev-parse HEAD^{tree}
git status --short --branch
find packages/ingestion packages/connectors/src services tests/research-program verification/wp4/v1.0.0 verification/wp5/v1.0.0 -maxdepth 2 -type f -printf '%p %s bytes\n'
nl -ba docs/master-plan/2026-09-10/prs/PR-009.md | sed -n '1,280p'
nl -ba docs/master-plan/2026-09-10/prs/PR-010.md | sed -n '1,260p'
nl -ba docs/master-plan/2026-09-10/prs/PR-011.md | sed -n '1,260p'
rg -n -C 8 '\"PR-009\"|\"PR-010\"|\"PR-011\"|job-lifecycle|operating-bounds' docs/master-plan/2026-09-10/plan.json
sha256sum <reviewed plans, implementation paths, schemas, migrations and verification files listed above>
gzip -cd verification/research-program/bootstrap/pr009-scope-20260911/pr009-native-scope-followup.md.gz
cat verification/research-program/bootstrap/pr009-scope-20260911/decision.json
cat verification/research-program/bootstrap/pr009-scope-independent-review-12e8876/decision.json
node --input-type=module -e "import('./verification/wp4/v1.0.0/tools/common.mjs').then(async m => { const v = await m.implementationFingerprint(); console.log(JSON.stringify({fingerprint:v.fingerprint, file_count:v.files.length})); })"
node --input-type=module -e "import('./verification/wp5/v1.0.0/tools/common.mjs').then(async m => console.log(JSON.stringify({fingerprint:await m.connectorFingerprint()})))"
sha256sum verification/research-program/bootstrap/pr009-scope-20260911/census-negative/manifest.json verification/research-program/bootstrap/pr009-scope-20260911/census-negative/sample-census-acs.html.gz verification/research-program/bootstrap/pr009-scope-20260911/census-negative/sample-census-acs.receipt.json
gzip -cd verification/research-program/bootstrap/pr009-scope-20260911/census-negative/sample-census-acs.html.gz | sha256sum
gzip -cd verification/research-program/bootstrap/pr009-scope-20260911/census-negative/sample-census-acs.html.gz | wc -c
test -e docs/research-program/handoffs/PR-009.json
```

The full command outputs remain reproducible from the immutable worktree and the locatable bootstrap files named above. No test result is claimed by this scope review; the packet’s planned focused check remains `node --test tests/research-program/job-lifecycle.test.mjs`, followed by the existing affected package/WP4 evidence checks at the implementation and integration gates.
