from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
R=Path.cwd();S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910');task='ushso-pr008-package-review-20260911';previous='072241ed12f2c0b04deb833eee857ca43920b9d3';head='911aff5588ea59b12b81b58f1d5e07ce09a987d3';tree='382ed8b6ed5536531ccf620379f9ceb8252c3f78';base='a00630c712e3a4e64354a77d268cb168fa3f528a'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==previous and not git('status','--porcelain')
changes=git('diff','--name-only',previous,head).splitlines()
assert all(p.startswith('verification/research-program/pr-008/') or p=='docs/research-program/handoffs/PR-008.json' for p in changes)
subprocess.run(['git','merge','--ff-only',head],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
packet_raw=(S/'pr008-integration-correction-dispatch.json').read_bytes();assert sha(packet_raw)=='5dcaf75074cce4bdc96ebcfbba45180eb24ac1b0f6bb68e84542842dd4477f55';packet=json.loads(packet_raw)
all_paths=git('diff','--name-only',base,head).splitlines()
assert all(any(p==o or o.endswith('/') and p.startswith(o) for o in packet['owned_paths']) for p in all_paths)
prior_receipt=S/'pr008-package-independent-review-072241e/receipt.json';assert sha(prior_receipt.read_bytes())=='2e09fafdb7ecfdab50b9c1bc8dc0bcdea859a273ae4498a8c095b97c04f47265'
audit=json.loads((S/'pr008-lock-review-072241e.json').read_text())
for pin in audit['source_bindings']:
    b=(R/pin['path']).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
out=S/'pr008-final-package-handoff-911aff5';assert not out.exists();out.mkdir();commands=[]
node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
for label,args in [('handoff',[node,'scripts/research-program/check-handoff.mjs','docs/research-program/handoffs/PR-008.json']),('variable-identity',[node,'--test','tests/research-program/variable-identity.test.mjs'])]:
    t=time.monotonic();at=datetime.now(timezone.utc).isoformat();p=subprocess.run(args,capture_output=True,timeout=120);streams={}
    for k,b in [('stdout',p.stdout),('stderr',p.stderr)]:
        n=label+'.'+k+'.log';(out/n).write_bytes(b);streams[k]={'path':n,'bytes':len(b),'sha256':sha(b)}
    commands.append({'label':label,'argv':args,'started_at':at,'duration_seconds':time.monotonic()-t,'exit_code':p.returncode,'streams':streams});print(json.dumps({'label':label,'exit_code':p.returncode}),flush=True)
hp=R/'docs/research-program/handoffs/PR-008.json';h=json.loads(hp.read_text());errors=[]
for a in h['artifacts']:
    p=(R/a['path']).resolve()
    assert p.is_relative_to(R.resolve()),a['path']
    b=p.read_bytes()
    if len(b)!=a['bytes'] or sha(b)!=a['sha256']:errors.append(a['path'])
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
ok=not errors and all(c['exit_code']==0 for c in commands)
receipt={'format':'ushso.pr008-final-package-handoff-review.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'reviewer':'Astra/root','implementation_author':'native /root/pr008_variable_scope_review','head':head,'tree':tree,'original_base':base,'original_dependency':packet['dependency_merge_shas'],'amendment_packet_sha256':sha(packet_raw),'metadata_only_changes_since_independent_package_review':changes,'previous_package_review':{'head':previous,'receipt':str(prior_receipt),'sha256':sha(prior_receipt.read_bytes()),'replayed_commands':6,'semantic_cases':34},'package_source_bindings_match':True,'handoff_sha256':sha(hp.read_bytes()),'artifact_bindings_checked':len(h['artifacts']),'artifact_errors':errors,'commands':commands,'status':'PASS' if ok else 'FAIL','worktree_clean':True,'combined_acceptance':False,'release_qualified':False,'requirements_accepted':[]}
p=out/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':sha(p.read_bytes()),'status':receipt['status'],'artifact_bindings_checked':len(h['artifacts'])}),flush=True)
raise SystemExit(0 if ok else 1)
