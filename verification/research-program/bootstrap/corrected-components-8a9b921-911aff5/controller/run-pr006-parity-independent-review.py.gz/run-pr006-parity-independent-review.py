from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
R=Path.cwd();S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910');head='8a9b921fa4be059624606116ed5ad33c238bb9ab';tree='bce0e5b5542e76690f48226eff023a7b4ac55fd3';prior='7e5819515b2f625d63de82efdd13571af096fbf6';base='c58787297fc543b3fdd31736e1c96ed1af29ffd8';task='ushso-pr006-parity-review-20260911';out=S/'pr006-parity-independent-review-8a9b921'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
subprocess.run(['/home/plumbob/.local/bin/worktree-bootstrap','verify',task,'--repo',str(R),'--require-writer'],check=True,stdout=subprocess.DEVNULL)
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
packet_raw=(S/'pr006-integration-correction-dispatch.json').read_bytes();assert sha(packet_raw)=='55dfc62981a96ba0000942ce293632ca24380f72a11059121175c2bac6905f60';packet=json.loads(packet_raw)
paths=git('diff','--name-only',base,head).splitlines()
assert all(any(p==o or o.endswith('/') and p.startswith(o) for o in packet['owned_paths']) for p in paths)
correction_paths=git('diff','--name-only',prior,head).splitlines()
assert [p for p in correction_paths if not p.startswith('verification/research-program/pr-006/') and p!='docs/research-program/handoffs/PR-006.json']==['tests/subject-shortcircuit.test.mjs']
frozen=['tests/fixtures/direct-base-control.mjs','tests/fixtures/direct-base-input.json','packages/retrieval/schemas/discovery-result.schema.json','packages/retrieval/fixtures/retrieval-core-before-lexical-index.txt','evaluation/research-program/cohorts.json','evaluation/research-program/tasks.json','docs/research-program/acceptance.md']
assert not git('diff','--name-only',base,head,'--',*frozen)
handoff_path=R/'docs/research-program/handoffs/PR-006.json';handoff_raw=handoff_path.read_bytes();assert sha(handoff_raw)=='8eda59a2284d022e220ff4f5a77640c145e39c9e726eb4833292bbad8c9201b2';handoff=json.loads(handoff_raw)
for a in handoff['artifacts']:
    b=(R/a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'],a['path']
assert not out.exists();out.mkdir();commands=[];node='/home/plumbob/.nvm/versions/node/v24.14.0/bin/node'
for label,args in [('subject-shortcircuit',[node,'--test','tests/subject-shortcircuit.test.mjs']),('direct-base',[node,'--test','tests/direct-base-regression.test.mjs']),('lexical',[node,'--test','packages/retrieval/tests/lexical-index.test.mjs']),('controller-engine',[node,str(S/'pr006-controller-facet-cases.mjs'),str(R)]),('handoff',[node,'scripts/research-program/check-handoff.mjs','docs/research-program/handoffs/PR-006.json'])]:
    at=datetime.now(timezone.utc).isoformat();t=time.monotonic();p=subprocess.run(args,capture_output=True,timeout=120);streams={}
    for k,b in [('stdout',p.stdout),('stderr',p.stderr)]:
        n=label+'.'+k+'.log';(out/n).write_bytes(b);streams[k]={'path':n,'bytes':len(b),'sha256':sha(b)}
    commands.append({'label':label,'argv':args,'started_at':at,'duration_seconds':time.monotonic()-t,'exit_code':p.returncode,'streams':streams});print(json.dumps({'label':label,'exit_code':p.returncode}),flush=True)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
ok=all(c['exit_code']==0 for c in commands)
receipt={'format':'ushso.pr006-parity-independent-review.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'reviewer':'Astra/root','implementation_author':'native /root/pr006_facet_contract_decision','head':head,'tree':tree,'original_base':base,'prior_independently_reviewed_head':prior,'scope_packet_sha256':sha(packet_raw),'correction_paths':correction_paths,'handoff_sha256':sha(handoff_raw),'artifact_bindings_checked':len(handoff['artifacts']),'artifact_errors':[],'source_review':['The helper clones each response and deletes only facets.sections[*].options[*].label before complete JSON.stringify equality. It preserves all other array/object ordering and values.','All four fixture scenarios and all four sorts remain. Public labels are literal independent maps; missing labels cannot pass. A changed pagination.total_matches remains unequal after normalization.','No product code or frontend bytes changed since the previous independent Chrome/UI/engine review at 7e58195; those prior results are retained as prior-head evidence. This execution newly replays the engine and corrected comparisons on the final head.'],'frozen_paths_unchanged':frozen,'commands':commands,'status':'PASS' if ok else 'FAIL','independent_integration_acceptance':'pending combined gate and hosted CI','current_approval_issued':False,'requirements_accepted':[],'worktree_clean':True}
p=out/'receipt.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':sha(p.read_bytes()),'status':receipt['status'],'artifact_bindings_checked':len(handoff['artifacts'])}),flush=True)
raise SystemExit(0 if ok else 1)
