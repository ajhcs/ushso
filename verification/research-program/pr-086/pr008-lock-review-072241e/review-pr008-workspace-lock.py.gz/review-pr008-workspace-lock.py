from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,sys

R=Path('/mnt/d/worktrees/plumbob/ushso-research-program-20260910')
S=Path('/mnt/d/tmp/plumbob/ushso-research-program-20260910')
B='a90071e261bee496fad1e3b1f98b07e0504a0fdd'
head=sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}',head)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def raw(commit,p):return git('show',commit+':'+p)
subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',B,head],check=True)
old_raw=raw(B,'package-lock.json');new_raw=raw(head,'package-lock.json')
assert len(old_raw)==134511 and sha(old_raw)=='37e4a9ec1fba9ab254aa7a596e1a0e3f73919cf5358717dc6e06e0478be6b20c'
before=json.loads(old_raw);after=json.loads(new_raw)
pkg_path='contracts/machine-toolkit/v1.2.0'
manifest_raw=raw(head,pkg_path+'/package.json');manifest=json.loads(manifest_raw)
assert manifest['private'] is True and manifest['version']=='1.2.0' and manifest['type']=='module'
assert manifest['dependencies']=={'ajv':'8.20.0'}
assert manifest['engines']['node'] in ['>=22.15','>=22.15.0']
assert manifest['scripts']['test']=='node --test tests/*.test.mjs'
assert manifest['scripts']['validate']=='node tools/verify.mjs'
assert re.fullmatch('@ushso/[a-z0-9.-]+',manifest['name'])
link='node_modules/'+manifest['name']
added=sorted(set(after['packages'])-set(before['packages']))
removed=sorted(set(before['packages'])-set(after['packages']))
changed=sorted(p for p in before['packages'] if p in after['packages'] and before['packages'][p]!=after['packages'][p])
root_delta=sorted(k for k in set(before)|set(after) if k!='packages' and before.get(k)!=after.get(k))
assert added==sorted([pkg_path,link]),added
assert not removed and not changed and not root_delta,{'removed':removed,'changed':changed,'root_delta':root_delta}
assert after['packages'][link]=={'resolved':pkg_path,'link':True}
entry=after['packages'][pkg_path]
assert entry['version']==manifest['version']
assert entry['dependencies']==manifest['dependencies']
assert entry['engines']==manifest['engines']
assert set(entry)<=set(['name','version','dependencies','engines','license'])
if 'name' in entry:assert entry['name']==manifest['name']
if 'license' in entry:assert entry['license']==manifest['license']
assert raw(head,'package.json')==raw(B,'package.json')
schema=pkg_path+'/schemas/variable-identity.schema.json'
assert raw(head,schema)==raw(B,schema)
assert sha(raw(head,schema))=='e6427730b3ad04653c3be13720bd9d7903d51ca7a331b7539493c039d5021c2c'
frozen=['contracts/machine-toolkit/v1.0.0','contracts/machine-toolkit/v1.1.0','scripts/run-contract-suites.mjs','scripts/verify-wp11-attestation.mjs','tests/wp11-attestation.test.mjs','packages/identity/src','packages/identity/schemas','evaluation/research-program/cohorts.json','evaluation/research-program/tasks.json','docs/research-program/acceptance.md']
assert not git('diff','--name-only',B,head,'--',*frozen).strip()
bindings=[]
for p in ['package-lock.json',pkg_path+'/package.json',pkg_path+'/README.md',pkg_path+'/tools/verify.mjs',pkg_path+'/tests/variable-identity.test.mjs',schema]:
    b=raw(head,p);bindings.append({'path':p,'bytes':len(b),'sha256':sha(b)})
result={'format':'ushso.pr008-workspace-lock-independent-structural-review.v1','recorded_at':datetime.now(timezone.utc).isoformat(),'reviewer':'Astra/root','scope':'Exact committed lock-object delta and immutable package boundaries; execution evidence is separate.','base_commit':B,'source_commit':head,'source_tree':git('rev-parse',head+'^{tree}').decode().strip(),'previous_lock':{'path':'package-lock.json','bytes':len(old_raw),'sha256':sha(old_raw)},'reviewed_lock':{'path':'package-lock.json','bytes':len(new_raw),'sha256':sha(new_raw)},'allowed_added_entries':{p:after['packages'][p] for p in added},'unchanged_preexisting_entries':len(before['packages']),'removed_entries':removed,'changed_preexisting_entries':changed,'changed_top_level_keys':root_delta,'source_bindings':bindings,'frozen_paths_unchanged':frozen,'status':'PASS','package_execution':'pending independent replay','current_approval_issued':False,'historical_approval_transferred':False,'combined_acceptance':False,'release_qualified':False}
out=S/('pr008-lock-review-'+head[:7]+'.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'status':'PASS','reviewed_lock':result['reviewed_lock'],'added_entries':added}),flush=True)
